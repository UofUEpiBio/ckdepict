#' Generate baseline intercept, baseline slope, long-term treatment slope, 
#'        true eGFR, and observed eGFR for each individual
#' @param Group                The group code for the individual.
#' @param trt.ind              A \code{list} with treatment status (treated = 1, untreated = 0) 
#'                             at each observational time points for two groups 
#'                             (\code{ConTxStatus} and \code{ExpTxStatus}).
#' @param max.obs.time         A \code{string} of the observational time points for the study.
#' @inheritParams SimulateCKD
#'
#' @details
#' Model for slope
#' \enumerate{
#'    \item{
#'    Condiser two different models for the slope distribution: a) Normal Mixture, 
#'    b) generalized log gamma.
#'    }
#'    \item{
#'    Normal mixture slope model:
#'      \enumerate{
#'         \item{
#'         Define two groups of patients, called "general patients" and "fast progressors", 
#'         with \code{Pr[fast.progressors] = p.fast.progressors.}
#'         }
#'         \item{
#'         Generate bivariate normally distributed intercepts and slopes for the general patients 
#'         and the fast progressors, and assume a common correlation of \code{corr.slope.int}
#'         between the intercept and the slope for both groups patients. Additional input 
#'         parameters for this step are: \code{mean.int}, \code{sd.int}, \code{mean.slope.general},
#'         \code{sd.slope.general}, \code{mean.slope.fast}, and \code{sd.slope.fast}.
#'         }
#'      }
#'    } 
#'    \item{
#'    Generalized log gamma model:
#'      \enumerate{
#'         \item{
#          #!        
#'         }
#'         \item{
#'         #!       
#'         }
#'      }
#'    }
#' }
#'
#' Model for Intercept
#' \enumerate{
#'    \item{
#'    Assume normal distribution on baseline eGFR with \code{mean.int} and \code{sd.int}. 
#'    Then truncate the baseline eGFR distribution by eliminationg observations with eGFR 
#'    outside of the interval [\code{int.low}, \code{int.up}].
#'    }
#'    \item{
#'    The truncation steip can be thought of as imposing entry criteria based on a restricted 
#'    baseline eGFR range. When desired, we can approximate a uniform distribution on baseline
#'    eGFR by taking the standard deviation of the simulated intercept (\code{sd.int}) to be 
#'    large compared to \code{int.up} - \code{int.low}.
#'    }
#' }
#'
#' Model for Long term effect 
#' \enumerate{
#'    \item{
#'    Allow seperate options for proportional and additive treatment effects 
#'    }
#'    \item{
#'    Proportional effect model:
#'       \enumerate{
#'          \item{
#'          If the slope without treatment (\code{BaseSlope}) is greater and equal to 0, then 
#'          \code{LongTermTxSlope} = \code{BaseSlope}. 
#'          }
#'          \item{
#'          If \code{BaseSlope} is negative, then
#'          \code{LongTermTxSlope} = \code{BaseSlope} * \code{long.term.effect}.
#'          }
#'       }
#'    }
#'    \item{
#'    Additive effect model:
#'       \enumerate{
#'          \item{
#'          The slope with treatment (\code{LongTermTxSlope}) equals to \
#'          \code{BaseSlope}+ code{long.term.effect}.
#'          }
#'       }
#'    }
#' }
#'
#' @param time.drop.trt Time at which treatment is dropped for this patient.
#' @return 
#'  A \code{list} with \code{Base}, \code{TrueEGFR}, \code{ObservedEGFR}
#' , and \code{ResidualZ} for the individual
#' @export


PatientInfo  <- 
  function(   Group
            , time.drop.trt = Inf
            , trt.ind
            , max.obs.time
            , corr.slope.int
            , slope.model 
            , mean.int
            , sd.int  
            , int.low
            , int.up
            , p.fast.progressors = 0
            , mean.slope.fast = 0
            , sd.slope.fast = 1
            , mean.slope.general = 0
            , sd.slope.general = 1
            , int.uniform.lower = NA_real_ #new parameter added on 4/3/2025 by Jian
            , int.uniform.upper = NA_real_ #new parameter added on 4/3/2025 by Jian
            , sd.log.gamma = NULL #new parameter added on 4/3/2025 by Jian
            , mean.log.gamma = NULL 
            # , log.gamma.loc #not needed anymore
            # , log.gamma.scale #not needed anymore
            , log.gamma.shape = 1
            , intglg.b0 = 0  #Jian repurposed this parameter. May need to give a new name. Now it is the intercept of the linear function that relates the intercept to the mean slope instead of location parameter, it is parameterized such that 
            # it is the mean of the slope when the intercept is equal to its mean (mean.int or (int.uniform.lower+int.uniform.upper)/2 depends on its distribution)
            , intglg.b1 = 0  ##Jian repurposed this parameter. May need to give a new name. Now it is the slope of the linear function that relates the intercept to the mean slope instead of location parameter
            , add.long.term.effect 
            , pro.long.term.effect 
            , acute.model = "ratio"
            , acute.A0
            , acute.SigA
            , acute.ratio
            , auto.residual
            , var.residual.a0
            , var.residual.a1
            , var.residual.POM = 1
            , t.df.residual = Inf
            , wt.residual
            , ...) {
    dots <- list(...)
    if (is.null(mean.log.gamma) && !is.null(dots$log.gamma.loc)) {
      mean.log.gamma <- dots$log.gamma.loc + dots$log.gamma.scale * digamma(log.gamma.shape)
    }
    if (is.null(sd.log.gamma) && !is.null(dots$log.gamma.scale)) {
      sd.log.gamma <- abs(dots$log.gamma.scale) * sqrt(trigamma(log.gamma.shape))
    }
    if (is.null(mean.log.gamma)) mean.log.gamma <- 0
    if (is.null(sd.log.gamma)) sd.log.gamma <- 1
    if (missing(acute.model)) acute.model <- "ratio"
    trt.ind [["ExpTxStatus"]]=trt.ind [["ExpTxStatus"]]*(max.obs.time<time.drop.trt) #jian added to allow patient to drop trt
    repeat {
      info <- PatientInfoMayOutbound(  Group = Group
                                       , trt.ind = trt.ind
                                       , max.obs.time = max.obs.time
                                       , corr.slope.int = corr.slope.int
                                       , mean.int = mean.int
                                       , sd.int = sd.int
                                       , slope.model = slope.model   
                                       , p.fast.progressors = p.fast.progressors 
                                       , mean.slope.fast = mean.slope.fast
                                       , sd.slope.fast = sd.slope.fast
                                       , mean.slope.general = mean.slope.general
                                       , sd.slope.general = sd.slope.general
                                       , int.uniform.lower = int.uniform.lower#new parameter added on 4/3/2025 by Jian
                                       , int.uniform.upper = int.uniform.upper #new parameter added on 4/3/2025 by Jian
                                       , sd.log.gamma = sd.log.gamma #new parameter added on 4/3/2025 by Jian
                                       , mean.log.gamma = mean.log.gamma
                                       # , log.gamma.loc #not needed anymore
                                       # , log.gamma.scale #not needed anymore
                                       , log.gamma.shape = log.gamma.shape
                                       , intglg.b0 = intglg.b0 #Jian repurposed this parameter. May need to give a new name. Now it is the intercept of the linear function that relates the intercept to the mean slope instead of location parameter, it is parameterized such that 
                                       # it is the mean of the slope when the intercept is equal to its mean (mean.int or (int.uniform.lower+int.uniform.upper)/2 depends on its distribution)
                                       , intglg.b1 =intglg.b1 ##Jian repurposed this parameter. May need to give a new name. Now it is the slope of the linear function that relates the intercept to the mean slope instead of location parameter
                                       , add.long.term.effect = add.long.term.effect
                                       , pro.long.term.effect = pro.long.term.effect
                                       , acute.model = acute.model
                                       , acute.A0 = acute.A0
                                       , acute.SigA = acute.SigA
                                       , acute.ratio = acute.ratio
                                       , auto.residual = auto.residual
                                       , var.residual.a0 = var.residual.a0
                                       , var.residual.a1 = var.residual.a1
                                       , var.residual.POM = var.residual.POM
                                       , t.df.residual= t.df.residual
                                       , wt.residual = wt.residual
      )
      if ((info[["ObservedEGFR"]][1] <= int.up) & (info[["ObservedEGFR"]][1] >= int.low)) break
    }
    info
  }




#' Generate baseline intercept, baseline slope, long-term treatment slope, 
#'        true eGFR, and observed eGFR for each individual
#'
#' @param ...                  Discard.
#' @inheritParams PatientInfo
#' @return 
#'  A \code{list} with \code{PersonID}, \code{Group}, \code{Base}
#' , \code{TrueEGFR}, \code{ObservedEGFR}, and \code{ResidualZ} for the individual  
#' @keywords internal
PatientInfoMayOutbound  <- 
function(  Group
        , trt.ind
        , max.obs.time
        , corr.slope.int
        , mean.int
        , sd.int
        , slope.model   
        , p.fast.progressors = 0
        , mean.slope.fast = 0
        , sd.slope.fast = 1
        , mean.slope.general = 0
        , sd.slope.general = 1
        , int.uniform.lower = NA_real_ #new parameter added on 4/3/2025 by Jian
        , int.uniform.upper = NA_real_ #new parameter added on 4/3/2025 by Jian
        , sd.log.gamma = NULL #new parameter added on 4/3/2025 by Jian
        , mean.log.gamma = NULL 
        # , log.gamma.loc #not needed anymore
        # , log.gamma.scale #not needed anymore
        , log.gamma.shape = 1
        , intglg.b0 = 0  #Jian repurposed this parameter. May need to give a new name. Now it is the intercept of the linear function that relates the intercept to the mean slope instead of location parameter, it is parameterized such that 
        # it is the mean of the slope when the intercept is equal to its mean (mean.int or (int.uniform.lower+int.uniform.upper)/2 depends on its distribution)
        , intglg.b1 = 0  ##Jian repurposed this parameter. May need to give a new name. Now it is the slope of the linear function that relates the intercept to the mean slope instead of location parameter
        , add.long.term.effect 
        , pro.long.term.effect 
        , acute.model = "ratio"
        , acute.A0
        , acute.SigA
        , acute.ratio
        , auto.residual
        , var.residual.a0
        , var.residual.a1
        , var.residual.POM = 1
        , t.df.residual
        , wt.residual
        , ...) {
  
  # base coefficient for each individual
  bvecs <- GenerateBaseCoef( slope.model=slope.model
                            ,corr.slope.int = corr.slope.int
                            , mean.int = mean.int
                            , sd.int = sd.int
                            , p.fast.progressors = p.fast.progressors 
                            , mean.slope.fast = mean.slope.fast
                            , sd.slope.fast = sd.slope.fast
                            , mean.slope.general = mean.slope.general
                            , sd.slope.general = sd.slope.general
                            , int.uniform.lower = int.uniform.lower #new parameter added on 4/3/2025 by Jian
                            , int.uniform.upper = int.uniform.upper #new parameter added on 4/3/2025 by Jian
                            , sd.log.gamma = sd.log.gamma #new parameter added on 4/3/2025 by Jian
                            , mean.log.gamma = mean.log.gamma 
                            # , log.gamma.loc #not needed anymore
                            # , log.gamma.scale #not needed anymore
                            , log.gamma.shape = log.gamma.shape
                            , intglg.b0 =  intglg.b0#Jian repurposed this parameter. May need to give a new name. Now it is the intercept of the linear function that relates the intercept to the mean slope instead of location parameter, it is parameterized such that 
                            # it is the mean of the slope when the intercept is equal to its mean (mean.int or (int.uniform.lower+int.uniform.upper)/2 depends on its distribution)
                            , intglg.b1 =intglg.b1 ##Jian repurposed this parameter. May need to give a new name. Now it is the slope of the linear function that relates the intercept to the mean slope instead of location parameter
                            , add.long.term.effect = add.long.term.effect
                            , pro.long.term.effect = pro.long.term.effect
                           )
  # true eGFR for each individual
  tegfr <- FindOnePersonTeGFR(Group = Group
                             , bvecs = bvecs
                             , trt = trt.ind
                             , obs.time = max.obs.time
                             , acute.model = acute.model
                             , acute.A0 = acute.A0
                             , acute.SigA = acute.SigA
                             , acute.ratio = acute.ratio
                             )
  
  # observed eGFR for each individual
  egfr <- FindOnePersonEGFR(  teGFR1 = tegfr
                           , Group = Group
                           , bvecs = bvecs
                           , auto.residual =  auto.residual
                           , var.residual.a0 = var.residual.a0
                           , var.residual.a1 = var.residual.a1
                           , var.residual.POM = var.residual.POM
                           , t.df.residual = t.df.residual
                           , wt.residual = wt.residual
                           )
  egfr
}



PatientInfo1 <- PatientInfo
