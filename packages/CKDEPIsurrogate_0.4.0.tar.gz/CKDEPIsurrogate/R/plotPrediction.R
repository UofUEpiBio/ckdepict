# Density-plot helpers and methods.
#
# The plotting functions use base R and are called with plot() on the result of
# ProbBen(), PredInt(), or POS(). Keeping the graphics code here leaves the
# statistical functions short and easy to read.

.predictionDensity <- function(x, n = 512L) {
  if (!is.numeric(x) || length(x) < 2L || any(!is.finite(x))) {
    stop("Predictive draws must contain at least two finite values", call. = FALSE)
  }

  # density() needs variation. Add a negligible display-only spread for the
  # deterministic special case; the underlying returned draws are not changed.
  if (diff(range(x)) == 0) {
    smallSpread <- max(abs(x[1]), 1) * 1e-6
    x <- c(x[1] - smallSpread, x, x[1] + smallSpread)
  }

  stats::density(x, n = n)
}

.shadeDensity <- function(myDensity, lower = -Inf, upper = Inf, col) {
  use <- myDensity$x >= lower & myDensity$x <= upper

  if (sum(use) < 2L) {
    return(invisible(FALSE))
  }

  myX <- myDensity$x[use]
  myY <- myDensity$y[use]
  graphics::polygon(
    x = c(myX[1], myX, myX[length(myX)]),
    y = c(0, myY, 0),
    col = col,
    border = NA
  )
  invisible(TRUE)
}

.plotColors <- function() {
  list(
    benefit = grDevices::adjustcolor("#0072B2", alpha.f = 0.38),
    noBenefit = grDevices::adjustcolor("#D55E00", alpha.f = 0.32),
    interval = grDevices::adjustcolor("#009E73", alpha.f = 0.38),
    line = "#333333"
  )
}

#' Plot a probability-of-benefit result
#'
#' @param x Result returned by [ProbBen()].
#' @param main Plot title.
#' @param xlab Horizontal-axis label.
#' @param ylab Vertical-axis label.
#' @param digits Number of probability digits shown in the legend.
#' @param ... Additional arguments passed to [graphics::plot()].
#' @export
plot.CKDEPIProbBen <- function(
    x,
    main = "Posterior predictive clinical effect",
    xlab = expression(theta),
    ylab = "Density",
    digits = 3,
    ...) {
  myDensity <- .predictionDensity(x$thetaDraws)
  myColors <- .plotColors()

  graphics::plot(
    myDensity,
    type = "n",
    main = main,
    xlab = xlab,
    ylab = ylab,
    ...
  )
  .shadeDensity(myDensity, upper = x$k, col = myColors$noBenefit)
  .shadeDensity(myDensity, lower = x$k, col = myColors$benefit)
  graphics::lines(myDensity, col = myColors$line, lwd = 1.5)
  graphics::abline(v = x$k, col = myColors$line, lty = 2, lwd = 1.5)

  graphics::legend(
    "topright",
    legend = c(
      paste0(
        "Pr(theta > k) = ",
        formatC(x$probabilityGreaterThanK, digits = digits, format = "f")
      ),
      paste0(
        "Pr(theta <= k) = ",
        formatC(
          x$probabilityLessThanOrEqualToK,
          digits = digits,
          format = "f"
        )
      ),
      paste0("k = ", format(x$k, digits = digits + 1))
    ),
    fill = c(myColors$benefit, myColors$noBenefit, NA),
    border = c(NA, NA, NA),
    lty = c(NA, NA, 2),
    col = c(NA, NA, myColors$line),
    bty = "n"
  )

  invisible(x)
}

#' Plot a prediction-interval result
#'
#' @param x Result returned by [PredInt()].
#' @param main Plot title.
#' @param xlab Horizontal-axis label.
#' @param ylab Vertical-axis label.
#' @param digits Number of interval digits shown in the legend.
#' @param ... Additional arguments passed to [graphics::plot()].
#' @export
plot.CKDEPIPredInt <- function(
    x,
    main = "Posterior prediction interval",
    xlab = expression(theta),
    ylab = "Density",
    digits = 3,
    ...) {
  myDensity <- .predictionDensity(x$thetaDraws)
  myColors <- .plotColors()
  lower <- unname(x$predictionInterval["lower"])
  upper <- unname(x$predictionInterval["upper"])

  graphics::plot(
    myDensity,
    type = "n",
    main = main,
    xlab = xlab,
    ylab = ylab,
    ...
  )
  .shadeDensity(myDensity, col = myColors$noBenefit)
  .shadeDensity(myDensity, lower = lower, upper = upper, col = myColors$interval)
  graphics::lines(myDensity, col = myColors$line, lwd = 1.5)
  graphics::abline(
    v = c(lower, upper),
    col = myColors$line,
    lty = 2,
    lwd = 1.5
  )

  intervalText <- paste0(
    formatC(100 * x$level, digits = 1, format = "f"),
    "% interval: [",
    formatC(lower, digits = digits, format = "f"),
    ", ",
    formatC(upper, digits = digits, format = "f"),
    "]"
  )
  graphics::legend(
    "topright",
    legend = c(intervalText, "Outside interval"),
    fill = c(myColors$interval, myColors$noBenefit),
    border = NA,
    bty = "n"
  )

  invisible(x)
}

.futureEstimateDensity <- function(
    thetaDraws,
    SE.theta,
    criticalEffect,
    n = 512L) {
  thetaRange <- stats::quantile(
    thetaDraws,
    probs = c(0.001, 0.999),
    names = FALSE,
    type = 7
  )
  lower <- min(thetaRange[1] - 4 * SE.theta, criticalEffect - 4 * SE.theta)
  upper <- max(thetaRange[2] + 4 * SE.theta, criticalEffect + 4 * SE.theta)
  myX <- seq(lower, upper, length.out = n)

  # The final estimate is a mixture of Normal(theta[i], SE.theta^2)
  # distributions. Evaluate the mixture directly to avoid plot-only simulation.
  myY <- vapply(
    myX,
    function(myValue) {
      mean(stats::dnorm(myValue, mean = thetaDraws, sd = SE.theta))
    },
    numeric(1)
  )

  list(x = myX, y = myY)
}

#' Plot a probability-of-success result
#'
#' @param x Result returned by [POS()].
#' @param main Plot title.
#' @param xlab Horizontal-axis label.
#' @param ylab Vertical-axis label.
#' @param digits Number of probability digits shown in the legend.
#' @param ... Additional arguments passed to [graphics::plot()].
#' @export
plot.CKDEPIPOS <- function(
    x,
    main = "Predictive phase 3 treatment-effect estimate",
    xlab = expression(hat(theta)),
    ylab = "Predictive density",
    digits = 3,
    ...) {
  criticalEffect <- stats::qnorm(1 - x$alpha / 2) * x$SE.theta
  myDensity <- .futureEstimateDensity(
    x$thetaDraws,
    x$SE.theta,
    criticalEffect
  )
  myColors <- .plotColors()

  graphics::plot(
    myDensity$x,
    myDensity$y,
    type = "n",
    main = main,
    xlab = xlab,
    ylab = ylab,
    ...
  )
  .shadeDensity(myDensity, upper = criticalEffect, col = myColors$noBenefit)
  .shadeDensity(myDensity, lower = criticalEffect, col = myColors$benefit)
  graphics::lines(myDensity$x, myDensity$y, col = myColors$line, lwd = 1.5)
  graphics::abline(
    v = criticalEffect,
    col = myColors$line,
    lty = 2,
    lwd = 1.5
  )

  graphics::legend(
    "topright",
    legend = c(
      paste0(
        "Probability of success = ",
        formatC(x$probabilityOfSuccess, digits = digits, format = "f")
      ),
      paste0(
        "Probability of no success = ",
        formatC(1 - x$probabilityOfSuccess, digits = digits, format = "f")
      ),
      paste0(
        "Rejection boundary = ",
        formatC(criticalEffect, digits = digits, format = "f")
      )
    ),
    fill = c(myColors$benefit, myColors$noBenefit, NA),
    border = c(NA, NA, NA),
    lty = c(NA, NA, 2),
    col = c(NA, NA, myColors$line),
    bty = "n"
  )

  invisible(x)
}
