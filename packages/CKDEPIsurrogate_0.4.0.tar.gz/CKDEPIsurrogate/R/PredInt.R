#' Prediction interval for the true clinical treatment effect
#'
#' @param fn.csv CSV file path or data frame containing columns `alpha`, `beta`,
#'   and `sigSqClinonSur`.
#' @param gamma.s Estimated treatment effect on the surrogate endpoint.
#' @param SE.gamma Standard error of `gamma.s`.
#' @param level Probability covered by the two-sided prediction interval.
#' @param seed Optional nonnegative integer used to reproduce the simulation.
#'
#' @return A list containing the predictive draws and prediction interval.
#' @export
PredInt <- function(
    fn.csv,
    gamma.s,
    SE.gamma,
    level = 0.95,
    seed = NULL) {
  .checkProbability(level, "level")

  prediction <- .simulateTheta(
    fn.csv = fn.csv,
    gamma.s = gamma.s,
    SE.gamma = SE.gamma,
    seed = seed
  )

  tailProbability <- (1 - level) / 2
  myInterval <- stats::quantile(
    prediction$thetaDraws,
    probs = c(tailProbability, 1 - tailProbability),
    names = FALSE,
    type = 7
  )
  names(myInterval) <- c("lower", "upper")

  result <- list(
    thetaDraws = prediction$thetaDraws,
    predictionInterval = myInterval,
    level = level,
    gamma.s = gamma.s,
    SE.gamma = SE.gamma,
    nDraws = prediction$nDraws
  )

  class(result) <- c("CKDEPIPredInt", "CKDEPIprediction")
  result
}
