#' Mixed Effects Weighted Slope Analysis for CKD simulation
#' 
#' @param eGFRRecords          A \code{data.frame} include all patients eGFR record.
#' @param mixed.slope.model    Two different mixed effects weighted slope analyses;
#'                             (a) Single slope model ('one')
#'                             (b) Two slopes linear mixed model ('two').
#'                             \code{mixed.slope.model} = c('one', 'two') for running two models.
#' @param mixed.truncate.time  Only keep eGFR Records with observed time smaller than 
#'                             trancation time.
#' @param mixed.total.time     The total study time (a number or a vector) for patients in slope 
#'                             analysis. The default setting is \code{NA} which will get the chronic 
#'                             slope and acute slope but will not
#'                             calculate the mixed slope for two slopes model analysis.
#' @param mixed.knot.point     The time point that acute effect adding in the study.
#' @param mixed.inc.group      Include a main effect of \code{Group} in analysis. 
#'                             Default is \code{FALSE}.
#' @param ...                  Discarded.
#'
#' @details 
#' One slope model analysis
#' \enumerate{
#'  \item eGFR = intercept + time + group + time*group
#'  \item random = time by subject = person_id
#' }
#' Two slopes model analysis
#' \enumerate{
#'  \item eGFR = intercept + time_low + time_high + group + time_low *group + time_high *griyo
#'  \item random = time by subject = person_id
#'  \item time_low = min(time - time(acute_effect), 0) 
#'        and time_high = max(time - time(acute_effect), 0)
#'  \item chronic slope is the coefficient for time_high *group
#'  \item acute slope is the coefficient for time_low*group
#'  \item total slope = t1 * acute slope + (1-t1) * chronic slope 
#'        where t1 = [time(acute_effect)/total.time]
#' }
#'
#' @return  A \code{data.frame} which include slope difference between two treatment groups 
#' @importFrom stringr str_extract
#' @importFrom stringr regex
#' @export
MixedSlopeAnalysis <- 
  function(  eGFRRecords
           , mixed.slope.model = c("one: Single slope model", "two: Two slopes linear mixed model")
           , mixed.truncate.time = NA
           , mixed.total.time = NA
           , mixed.knot.point
           , mixed.inc.group = FALSE
           , ...) {
      mixed.slope.model  <- as.character(mixed.slope.model)
      mixed.slope.model  <- str_extract(match.arg(mixed.slope.model, several.ok = TRUE)
                                      , regex('^.*?(?=:)'))
      stopifnot(length(mixed.slope.model) >= 1)
      pg <- data.frame( Trunc.Time = mixed.truncate.time
                      , Total.Time = mixed.total.time 
                      , Knot.Point = mixed.knot.point 
                      , Inc.Group  = mixed.inc.group )
      
      fixSpecClass(mdply( pg
                        , RunMSOneSetting
                        , eGFRRecords
                        , Slope.Model = mixed.slope.model))
                                        
}

#' Find single, acute, chronic, and mixed slope in 1-slope and 2-slope linear 
#'        spline model
#' @param eGFRRecords     The eGFR Records.
#' @param Slope.Model     Two different mixed effects weighted slope analyses;
#'                        (a) Single slope model ('one')
#'                        (b) Two slopes linear mixed model ('two').
#'                        \code{mixed.slope.model} = c('one', 'two') for running two models.
#' @param Trunc.Time      Only keep eGFR Records with observed time smaller than 
#'                        trancation time.
#' @param Total.Time      The total study time for patients in slope analysis.
#' @param Knot.Point      The time point that acute effect adding in the study.
#' @param Inc.Group       Include a main effect of \code{Group} in analysis. 
#'                        Default is \code{FALSE}.
#' @return A \code{data.frame} with chronic slope, acute slope and mixed slope at 
#'         \code{Total.Time} and associate 
#'         standard deviation.
#' @keywords internal    
RunMSOneSetting <- function(Trunc.Time, Total.Time, Knot.Point, Inc.Group
                             , eGFRRecords
                             , Slope.Model){
  stopifnot(is.logical(Inc.Group))
  
  egfr.record.temp <- if (any(names(eGFRRecords) == "RepeatMeasure")) {
    if (is.na(Trunc.Time)) {
      eGFRRecords[eGFRRecords$RepeatMeasure == 0, names(eGFRRecords) != "RepeatMeasure"]
    } else {
      eGFRRecords[eGFRRecords$RepeatMeasure == 0 & eGFRRecords$Time <= Trunc.Time
                  , names(eGFRRecords) != "RepeatMeasure"]
    }
  } else {
    if (is.na(Trunc.Time)) {
      eGFRRecords
    } else {
      eGFRRecords[eGFRRecords$Time <= Trunc.Time, ]
    }
  }
  
  one.slope <- if ("one" %in% Slope.Model) {
    MixedSlopeAnalysis1(egfr.record.temp, Inc.Group)
  } else .edf
  
  two.slope <- if ("two" %in% Slope.Model) {
    MixedSlopeAnalysis2(egfr.record.temp, Total.Time, Knot.Point, Inc.Group)
  } else .edf
  
  SPEC <- MixSParams(Trunc.Time, Total.Time, Knot.Point, Inc.Group )
  unrowname(data.frame( SPEC, Single.Slope = one.slope, two.slope))
}
#' Find single slope in 1-slope model
#' @param egfr.record.temp     The eGFR Records.
#' @param Inc.Group            Include a main effect of \code{Group} in analysis. 
#'                             Default is \code{FALSE}.
#' @return A \code{data.frame} with single slope and associate 
#'         standard deviation.
#' @keywords internal
MixedSlopeAnalysis1 <- function(egfr.record.temp, Inc.Group){
            one.slope <- if (Inc.Group) {
              m <- summary(lmer(ObservedEGFR ~ Group * Time + (1 + Time | PersonID)
                             , data = egfr.record.temp))
              m@coefs[names = 'Group:Time', ]
            } else {
              m <-summary(lmer(ObservedEGFR ~ Time + I(Group * Time) + (1 + Time |PersonID )
                             , data = egfr.record.temp))
              m@coefs[names = 'I(Group * Time)', ]
            }
            
            data.frame( Value = one.slope[[1]]
                      , SE    = one.slope[[2]])
}
#' Find acute, chronic, and total slope in 2-slope linear spline model
#' @param egfr.record.temp     The eGFR Records.
#' @param Total.Time           The total study time for patients in slope analysis.
#' @param Knot.Point           The time point that acute effect adding in the study.
#' @param Inc.Group            Include a main effect of \code{Group} in analysis. 
#'                             Default is \code{FALSE}.
#' @return A \code{data.frame} with chronic slope, acute slope and mixed slope at 
#'         \code{Total.Time} and associate 
#'         standard deviation.
#' @keywords internal
MixedSlopeAnalysis2 <- function(egfr.record.temp, Total.Time, Knot.Point, Inc.Group){
    stopifnot( Knot.Point >=0
             , Knot.Point <= Total.Time)
    egfr.record.temp$TimeLo <- pmin(egfr.record.temp$Time - Knot.Point, 0)
    egfr.record.temp$TimeHi <- pmax(egfr.record.temp$Time - Knot.Point, 0)
    
    two.slope <- if (Inc.Group) {
        m <- summary(lmer(ObservedEGFR ~ Group * TimeLo  + Group * TimeHi + (1 + Time | PersonID)
                     , data = egfr.record.temp))
        m@coefs[names = c('Group:TimeHi', 'Group:TimeLo'), ]
    } else {
        m <- summary(lmer(ObservedEGFR ~ 
            TimeLo + TimeHi + I(Group * TimeLo) + I(Group * TimeHi) + (1 + Time |PersonID )
                     , data = egfr.record.temp))
        m@coefs[names = c("I(Group * TimeHi)", "I(Group * TimeLo)"), ]
    }
    
    chronic.temp <- two.slope[1,]
    acute.temp   <- two.slope[2,]
    
    chronic.slope <- data.frame(Value = chronic.temp[[1]], SE = chronic.temp[[2]])  
    acute.slope   <- data.frame(Value = acute.temp[[1]]  , SE = acute.temp[[2]])
    
    mixed.slope <- if (!is.na(Total.Time)) {
        stopifnot (Total.Time > Knot.Point)
        FindMixedSlope(Total.Time, Knot.Point, acute.slope, chronic.slope)
    }else .edf
    
    data.frame( Chronic.Slope=chronic.slope
              , Acute.Slope=acute.slope
              , Total.Slope=mixed.slope)
}

#' Find total slope in 2-slope linear spline model
#' 
#' @param total.time           The total study time for patients in slope analysis.
#' @param knot.point           The time point that acute effect adding in the study.
#' @param acute.slope          The acute slope in the study
#' @param chronic.slope        The chronic slope in the study
#' @return A \code{data.frame} with total slope at \code{total.time} and associate 
#'         standard deviation.
#' @keywords internal
FindMixedSlope <- function(total.time, knot.point, acute.slope, chronic.slope) {
  stopifnot(length(acute.slope) == length(chronic.slope))
  acute.wt       <- knot.point / total.time
  chronic.wt     <- 1 - acute.wt
  total.slope    <- acute.wt * acute.slope$Value + chronic.wt * chronic.slope$Value
  total.slope.se <- sqrt((acute.wt * acute.slope$SE)^2 + (chronic.wt*chronic.slope$SE)^2)
  data.frame(Value   = total.slope, SE   = total.slope.se)
}


#' Unweighted Slope Analysis for CKD simulation
#' 
#' @param eGFRRecords          A \code{data.frame} include all patients eGFR record.
#' @param unwt.slope.model     Two different unweighted analysis of mean slopes;
#'                             (a) Single slope model ('one')
#'                             (b) Two slopes linear spline model ('two').
#'                             \code{unwt.slope.model} = c('one', 'two') for running two models.
#' @param unwt.truncate.time   Only keep eGFR Records with observed time smaller than 
#'                             trancation time.
#' @param unwt.min.followup    The minimum follow-up time for a patient to be included in 
#'                             the unweighted analysis.
#' @param unwt.total.time      The total study time (a number or a vector) for patients in slope analysis.
#'                             The default setting is NA which will get the chronic slope but will not 
#'                             calculate the total slope for two spline slopes model analysis.
#' @param unwt.knot.point      The time point that acute effect adding in the study.
#' @param ...                  Discarded.
#'
#' @details 
#' One slope model analysis
#' \enumerate{
#'  \item For each person, eGFR = intercept + time
#' }
#' Two slopes model analysis
#' \enumerate{
#'  \item For each person, 
#'        eGFR = intercept + time_low + time_high 
#'  \item time_low = min(time - time(acute_effect), 0) 
#'        and time_high = max(time - time(acute_effect), 0)
#'  \item chronic slope is the coefficient for time_high *group
#'  \item acute slope is the coefficient for time_low*group
#'  \item total slope = t1 * acute slope + (1-t1) * chronic slope 
#'        where t1 = [time(acute_effect)/unweight.total.time]
#' }
#'
#' @return  A dataset which include unweighted slope difference between 
#'          treated group and untreated group
#' @importFrom stringr str_extract
#' @importFrom stringr regex
#' @export
UnweightedSlopeAnalysis <- 
  function(  eGFRRecords
           , unwt.slope.model= c("one: Single slope model", "two: Two slopes linear spline model")
           , unwt.truncate.time = NA
           , unwt.min.followup = 0
           , unwt.total.time = NA
           , unwt.knot.point = NA
           , ...) {
  unwt.slope.model  <- as.character(unwt.slope.model)
  unwt.slope.model  <- str_extract(match.arg(unwt.slope.model, several.ok = TRUE)
                                   , regex('^.*?(?=:)'))
  
  stopifnot(length(unwt.slope.model) >= 1)
  
  pg <- data.frame( Trunc.Time     = unwt.truncate.time
                    , Total.Time   = unwt.total.time 
                    , Knot.Point   = unwt.knot.point 
                    , Min.FU.Time  = unwt.min.followup )
  fixSpecClass(mdply( pg
                      , RunUnwtSOneSetting
                      , eGFRRecords
                      , Slope.Model = unwt.slope.model))
  
}


#' Find single, acute, chronic, and mixed slope in 1-slope and 2-slope linear 
#'        spline model for unweighted slope model
#' @param eGFRRecords     The eGFR Records.
#' @param Slope.Model     Two different mixed effects weighted slope analyses;
#'                        (a) Single slope model ('one')
#'                        (b) Two slopes linear model ('two').
#'                        \code{unwt.slope.model} = c('one', 'two') for running two models.
#' @param Trunc.Time      Only keep eGFR Records with observed time smaller than 
#'                        trancation time.
#' @param Total.Time      The total study time for patients in slope analysis.
#' @param Knot.Point      The time point that acute effect adding in the study.
#' @param Min.FU.Time     The minimum follow-up time for a patient to be included in 
#'                        the unweighted analysis.
#' @return A \code{data.frame} with chronic slope, acute slope and mixed slope at 
#'         \code{Total.Time} and associate 
#'         standard deviation.
#' @keywords internal    
RunUnwtSOneSetting <- function(Trunc.Time, Total.Time, Knot.Point, Min.FU.Time
                            , eGFRRecords
                            , Slope.Model){

  
  egfr.record.temp <- if (any(names(eGFRRecords) == "RepeatMeasure")) {
    if (is.na(Trunc.Time)) {
      eGFRRecords[eGFRRecords$RepeatMeasure == 0, names(eGFRRecords) != "RepeatMeasure"]
    } else {
      eGFRRecords[eGFRRecords$RepeatMeasure == 0 & eGFRRecords$Time <= Trunc.Time
                  , names(eGFRRecords) != "RepeatMeasure"]
    }
  } else {
    if (is.na(Trunc.Time)) {
      eGFRRecords
    } else {
      eGFRRecords[eGFRRecords$Time <= Trunc.Time, ]
    }
  }
  
  pt.max.time <- tapply(egfr.record.temp$Time, egfr.record.temp$PersonID, max)
  pt.max.time <- data.frame(PersonID = row.names(pt.max.time), MaxTime = pt.max.time)
  pt.max.time <- subset(pt.max.time, pt.max.time$MaxTime >= Min.FU.Time)
  egfr.record.temp <- subset(egfr.record.temp
                             , egfr.record.temp$PersonID %in% pt.max.time$PersonID)
  unique.pt        <- unrowname(unique(egfr.record.temp[, c("PersonID", "Group")]))
  one.slope <- if ("one" %in% Slope.Model) {
    UnweightedSlopeAnalysis1(egfr.record.temp, unique.pt)
  } else .edf
  
  two.slope <- if ("two" %in% Slope.Model) {
    UnweightedSlopeAnalysis2(egfr.record.temp, unique.pt, Total.Time, Knot.Point)
  } else .edf
  
  SPEC <- UnwgtParams(Trunc.Time, Total.Time, Knot.Point, Min.FU.Time)
  unrowname(data.frame( SPEC, Single.Slope = one.slope, two.slope))
}

#' Find single slope in 1-slope model for unweighted slope model
#' @param egfr.record.temp     The eGFR Records.
#' @param unique.pt            The unique patient and group information.
#' @return A \code{data.frame} with one single slope and associate 
#'         standard deviation.
#' @importFrom stats coef
#' @keywords internal
UnweightedSlopeAnalysis1 <- function(egfr.record.temp, unique.pt){
  one.slope      <-  by(egfr.record.temp, egfr.record.temp$PersonID
                       , function(x) lm(ObservedEGFR ~ Time, data=x))
   one.slope.data <- data.frame(unique.pt, 
                                Unwt.1Slope = sapply(one.slope, coef)[row.names='Time',])
   TTest("Unwt.1Slope", test.data = one.slope.data)
}

#' Findacute, chronic, and mixed slope in 2-slope linear 
#'        spline model for unweighted slope model
#' @param egfr.record.temp  The eGFR Records.
#' @param unique.pt         The unique patient and group information.
#' @param Total.Time        The total study time for patients in slope analysis.
#' @param Knot.Point        The time point that acute effect adding in the study.
#' @return A \code{data.frame} with chronic slope, acute slope and mixed slope at 
#'         \code{Total.Time} and associate standard deviation.
#' @keywords internal
UnweightedSlopeAnalysis2 <- function(egfr.record.temp, unique.pt, Total.Time, Knot.Point)
{
    stopifnot(Knot.Point >=0)
    
    egfr.record.temp$TimeLo <- pmin(egfr.record.temp$Time - Knot.Point, 0)
    egfr.record.temp$TimeHi <- pmax(egfr.record.temp$Time - Knot.Point, 0)
    two.slope               <- by(egfr.record.temp, egfr.record.temp$PersonID
                                  , function(x) lm(ObservedEGFR ~ TimeLo + TimeHi, data=x))
    two.slope.data <- data.frame(  unique.pt
                                   , Unwt.2Slope.Acute   = sapply(two.slope, coef)[row.names='TimeLo',]
                                   , Unwt.2Slope.Chronic = sapply(two.slope, coef)[row.names='TimeHi',])
    chronic.slope <- TTest("Unwt.2Slope.Chronic", test.data = two.slope.data)
    acute.slope   <- TTest("Unwt.2Slope.Acute", test.data = two.slope.data)
    mixed.slope <- if (!is.na(Total.Time)) {
        stopifnot(Knot.Point <= Total.Time)
        acute.wt       <- Knot.Point / Total.Time
        chronic.wt     <- 1 - acute.wt
        two.slope.data$Unwt.2Slope.Total <- acute.wt * two.slope.data$Unwt.2Slope.Acute + 
                                          chronic.wt * two.slope.data$Unwt.2Slope.Chronic
        TTest("Unwt.2Slope.Total", test.data = two.slope.data)
    } else .edf
    
    data.frame( Chronic.Slope = chronic.slope
                , Acute.Slope = acute.slope
                , Total.Slope = mixed.slope) 
}

#' Find slope difference and associate standard error for unweighted slope analysis
#' @param test.column   The name of column want to test the difference.
#' @param test.data     The dataset being used.
#' @return A \code{data.frame} with slope name, slope difference and standard deviation
#' @keywords internal
TTest <- function(test.column, test.data) {
  ttest       <- t.test(test.data[, test.column] ~ test.data[, "Group"])
  slope.diff  <- ttest$estimate[2]- ttest$estimate[1]
  slope.se    <- (ttest$conf.int[2]- ttest$conf.int[1])/(2*qnorm(0.975))
  unrowname(data.frame(Value = slope.diff, SE = slope.se))
}
