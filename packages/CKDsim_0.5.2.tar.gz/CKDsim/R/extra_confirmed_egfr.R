#' Generate extra measured eGFR for the patients if the repeat.measure is TRUE.
#'
#' @param egfr.record.temp   A \code{data.frame} for patients observed eGFR value
#' @param repeat.measure     A repeat measurment to confirm eGFR event for
#'                           time-to-event analysis and fixed time analysis. The default setting 
#'                           is FALSE.
#' @param var.residual.a0    Coefficient for variance of residuals.
#' @param var.residual.a1    Coefficient for variance of residuals.
#' @param var.residual.POM   Power applied to true eGFR in the residual variance model.
#' @param t.df.residual      Innovations are generaged by student T distribution with degree of 
#'                           freedom (df.residual).
#' @param wt.residual        Weighted in Gaussian processes for residuals.     
#'
#' @details
#' Adding extra measurement to egfr record for patients require extra measurement 
#' for time-to-event analysis and fixed time analysis 
#' 
#' @return    A \code{data.frame} for egfr.record with original eGFR measurements and 
#'            extra measurements (if \code{repeat.measure} is \code{TRUE}).
#' @keywords internal
IncRepEGFRRecord <- function(  egfr.record.temp
                             , repeat.measure = FALSE
                             , var.residual.a0
                             , var.residual.a1
                             , var.residual.POM = 1
                             , t.df.residual = Inf
                             , wt.residual) {
  {  # parameter checking 
  stopifnot(inherits(egfr.record.temp, 'data.frame'))
  stopifnot(c("PersonID", "Group", "Time", "TxStatus", "TrueEGFR", "ObservedEGFR") 
            %in% names(egfr.record.temp))
  }  # end parameter checking
  
  if (repeat.measure == TRUE) {
    need.extra.egfr <- egfr.record.temp[!duplicated(egfr.record.temp[, c("PersonID", "Time")]
                                                    , fromLast = TRUE) 
                                        , ]           
    colname.extra.egfr <- c("PersonID","Group","Time","TxStatus","ObservedEGFR","RepeatMeasure")
    
    var.residual  <- pmax(0, var.residual.a0 + (var.residual.a1 * need.extra.egfr[["TrueEGFR"]]^var.residual.POM))
    residual.w    <- rt(n = nrow(need.extra.egfr), df = t.df.residual)
    
    if(is.finite(t.df.residual))
      residual.w <- residual.w * sqrt((t.df.residual - 2) / t.df.residual)
    
    residual.temp <- (wt.residual * need.extra.egfr[["ResidualZ"]]) + 
                     (sqrt(1 - (wt.residual ^ 2)) * residual.w)

    residual      <- c(residual.temp) * sqrt(var.residual)
    need.extra.egfr$ObservedEGFR <- need.extra.egfr[["TrueEGFR"]] + residual
    need.extra.egfr$RepeatMeasure  = 1
    egfr.record.temp$RepeatMeasure = 0
    
    egfr.record <- rbind(egfr.record.temp, need.extra.egfr)
    egfr.record <- egfr.record[
          order(egfr.record$PersonID, egfr.record$Time, egfr.record$RepeatMeasure)
          , c("PersonID","Group","Time","TxStatus","ObservedEGFR","RepeatMeasure")]
  } else {
    egfr.record <- egfr.record.temp[order(egfr.record.temp$PersonID, egfr.record.temp$Time)
                                    , names(egfr.record.temp) %in% 
                                      c("PersonID", "Group", "Time", "TxStatus", "ObservedEGFR")]
  }
  egfr.record
}
