#' Define all times for patients
#'
#' @param base.simple.info     A dataframe with patients' (by rows) baseline slope 
#'                             treated slope, group, and intercept information.
#' @param trt.ind              A list with logical for two groups if treated.
#' @param teGFR                A teGFR list for patients (by objects). 
#' @param eGFR                 A eGFR list for patients (by objects).
#' @param accrual              Accrual period for study (yr).
#' @param followup             Additional follow up period for study (yr).
#' @param esrd.threshold.low   Upper bound for ESRD be triggered
#' @param esrd.threshold.up    Lower bound for ESRD be triggered
#' @param lambda.fu            Loss to follow up hazard rate(per year).
#' @param lambda.b0            Death hazard rate = \code{lambda.b0} + \code{lambda.b2} * teGFR 
#'                             + \code{lambda.b3} * slope (per year) in control group
#' @param lambda.b1            Death hazard rate = \code{lambda.b1} + \code{lambda.b2} * teGFR 
#'                             + \code{lambda.b3} * slope (per year) in control group
#' @param lambda.b2            Coefficient for Death hazard rate. The default value is 0.
#' @param lambda.b3            Coefficient for Death hazard rate. The default value is 0.
#' @param max.obs.time         A maximun set for possible eGFR measured time points in entire study.
#' 
#' @details
#' Define entering time, censoring time, death time, time to ESRD, and loss to 
#' follow-up time for each patients. 
#' Trigger for time to ESRD is uniform  distributed between \code{esrd.threshold.low} 
#' and \code{esrd.threshold.up}.
#' The dead hazard rate can be changing depending on teGFR. 
#' 
#' @return 
#' A \code{\link{data.frame}} with columns \code{EnterStudyTime}, \code{AdminCen}, 
#' \code{LossFU}, \code{ESRD}, \code{Death}.  One row per patient.
#' 
#' @keywords internal
DefineTimeFrame <- 
function(  base.simple.info
        , trt.ind, max.obs.time
        , teGFR, eGFR
        , accrual
        , followup
        , esrd.model
        , esrd.threshold.low
        , esrd.threshold.up
        , lambda.c0
        , lambda.c1
        , esrd.weibull.shape = 1
        , mean.log.gamma = 0
        , esrd.lambda.b0 = 0
        , esrd.lambda.b1 = 0
        , esrd.lambda.b2 = 0
        , lambda.fu
        , lambda.b0
        , lambda.b1
        , lambda.b2 = 0
        , lambda.b3 = 0) {
  stopifnot(inherits(trt.ind, 'list')
            , inherits(teGFR, 'list')
            , inherits(eGFR, 'list')
            , inherits(base.simple.info, 'data.frame')
            , inherits(max.obs.time, 'numeric'))
  stopifnot(all(dim(teGFR) == dim(eGFR)))
  stopifnot(length(trt.ind) == 2)
  stopifnot(c('Group', 'BaseSlope', 'LongTermTxSlope') %in% colnames(base.simple.info))
  
  num.patients <- nrow(base.simple.info)
  enter.time   <- runif(num.patients, min = 0, max = accrual)
  censor.time  <- followup + accrual - enter.time
  loss.fu.time <- rexp(num.patients, rate = lambda.fu)
  
  if (esrd.model== "threshold"){
    esrd.trigger <- runif(num.patients, min = esrd.threshold.low
                          , max = esrd.threshold.up)
    esrd.time    <- mapply(FindESRDTime, teGFR, eGFR, esrd.trigger
                           , MoreArgs = list(max.obs.time = max.obs.time))
  }else if (esrd.model== "piecewise.exponential"){
    esrd.trigger=  esrd.threshold.low    #on 11/17/2025 Tom decided that for this model, when the observed eGFR is below a threshold, ESRD should happens immediately.
    esrd.time    <- mapply(GenerateESRD.piecewise.exponential, teGFR,eGFR,esrd.trigger
                           , lambda.c0 = lambda.c0
                           , lambda.c1 = lambda.c1
                           , MoreArgs = list(max.obs.time = max.obs.time))
  }else if (esrd.model== "Weibull"){
    esrd.trigger <- rep(NA_real_, num.patients)
    baseline.diff <- base.simple.info$BaseIntercept - mean(base.simple.info$BaseIntercept)
    control.mean.slope <- mean(base.simple.info$BaseSlope[base.simple.info$Group == 0])
    slope.diff <- base.simple.info$BaseSlope - control.mean.slope
    esrd.time <- mapply(GenerateESRD.weibull
                         , ESRD.weibull.shape = esrd.weibull.shape
                         , Mean.ESRD.time = exp(esrd.lambda.b0)
                         , Baseline.eGFR.diff.from.mean = baseline.diff
                         , slope.diff.from.control.mean = slope.diff
                         , MoreArgs = list(beta.b1 = esrd.lambda.b1
                                         , beta.b2 = esrd.lambda.b2))
  }else if (esrd.model== "lognormal"){
    esrd.trigger <- rep(NA_real_, num.patients)
    baseline.diff <- base.simple.info$BaseIntercept - mean(base.simple.info$BaseIntercept)
    control.mean.slope <- mean(base.simple.info$BaseSlope[base.simple.info$Group == 0])
    slope.diff <- base.simple.info$BaseSlope - control.mean.slope
    esrd.time <- mapply(GenerateESRD.lognormal
                         , ESRD.lognormal.sigma = esrd.weibull.shape
                         , Mean.ESRD.time = exp(esrd.lambda.b0)
                         , Baseline.eGFR.diff.from.mean = baseline.diff
                         , slope.diff.from.control.mean = slope.diff
                         , MoreArgs = list(beta.b1 = esrd.lambda.b1
                                         , beta.b2 = esrd.lambda.b2))
  } else { stop("Error: Please choose a valid ESRD model") }

  dead.time    <- mapply(GenerateDeath
                         , teGFR
                         , base.simple.info$Group
                         , base.simple.info$BaseSlope
                         , base.simple.info$LongTermTxSlope
                         , MoreArgs = list(trt = trt.ind
                                          , max.obs.time = max.obs.time
                                          , lambda.b0 = lambda.b0
                                          , lambda.b1 = lambda.b1
                                          , lambda.b2 = lambda.b2
                                          , lambda.b3 = lambda.b3))

  
  data.frame(EnterStudyTime = enter.time, AdminCen = censor.time
             , LossFU = ifelse(loss.fu.time < censor.time, loss.fu.time, NA)
             , ESRD   = ifelse(esrd.time    < censor.time, esrd.time   , NA)
             , Death  = ifelse(dead.time    < censor.time, dead.time   , NA)
             , esrd.trigger=esrd.trigger
             )
}


#' Finds the ESRD time for an individual patient.
#' 
#' @param teGFR1         A numeric vector for an individual's true eGFR value.
#' @param eGFR1          A numeric vector for an individual's eGFR value.
#' @param esrd.trigger   The ESRD trigger for the person.
#' @param max.obs.time   A maximun set of observational time points for an individual.
#' 
#' @return A ESRD time value for an individual.
#' @keywords internal
FindESRDTime <- function(teGFR1, eGFR1, esrd.trigger, max.obs.time) {
    stopifnot(inherits(teGFR1, 'numeric')
              , inherits(eGFR1, 'numeric')
              , length(esrd.trigger) == 1
              , length(teGFR1) == length(eGFR1)
              , length(teGFR1) == length(max.obs.time))
    
    esrd.time.tegfr <- 
    ifelse(head(teGFR1, - 1) > esrd.trigger & tail(teGFR1, - 1) < esrd.trigger
           , diff(max.obs.time) * head(esrd.trigger - teGFR1, - 1) / diff(teGFR1)
             + head(max.obs.time, - 1)
           , ifelse(head(teGFR1, - 1) == esrd.trigger, head(max.obs.time, - 1), Inf))

    esrd.time.egfr <- 
    ifelse ((head(eGFR1, - 1) > esrd.trigger) & (tail(eGFR1, - 1) <= esrd.trigger)
        , tail(max.obs.time, - 1)
        , Inf)
    
    #return(min(esrd.time.tegfr, esrd.time.egfr)) ##On 10/17/2017, Jian made this modification so ESRD is only triggered by that the true eGFR to be lower than threshold
    return(min(esrd.time.tegfr, Inf))
}

#' Finds the ESRD time for an individual patient by generating mechanism option 2:hazard=lambda.c0 + lambda.c1 * teGFR
#' Jian added this option on 4/25/2025
#' @param teGFR1           A numeric vector for an individual's true eGFR value.
#' @param eGFR1          A numeric vector for an individual's eGFR value.
#' @param esrd.trigger   The ESRD trigger for the person.
#' @param max.obs.time     A maximun set of observational time points for an individual.
#' @param lambda.c0        ESRD hazard rate = lambda.c0 + lambda.c1 * teGFR  
#'                         
#' @param lambda.c1        ESRD hazard rate = lambda.c0 + lambda.c1 * teGFR 

#' @return A ESRD time value for an individual.
#' @keywords internal

GenerateESRD.piecewise.exponential<- function(teGFR1,eGFR1,esrd.trigger, max.obs.time, lambda.c0, lambda.c1
                              , ...) {
  stopifnot(length(teGFR1) == length(max.obs.time))
  
  t.diff <- diff(max.obs.time)
  lambda <- exp(lambda.c0 + lambda.c1* teGFR1) #hazard rate depends on teGFR at each time point
  #When observed eGFR>30, set lambda as 0. when observed eGFR <esrd.trigger, set lambda as 1000000
  lambda[eGFR1>30]=0
  lambda[eGFR1<=esrd.trigger]=1000000
  
  lambda=head(lambda,-1)
  
  ESRD.length <- mapply(function(lambda) ifelse(lambda > 0, rexp(1, lambda), Inf)
                        , lambda)
  
  if(any(ESRD.length <= t.diff)) {
    index <- match(1, ESRD.length <= t.diff)
    return(max.obs.time[index] + ESRD.length[index])
  } else {return(Inf)}
}



#' Finds the ESRD time for an individual patient by generating mechanism option 3:Weibull distribution, mean=m*exp(beta.b1*Baseline.eGFR.diff.from.mean + beta.b2 * slope.diff.from.control.mean) 
#' Jian added this option on 4/25/2025
#' @param ESRD.weibull.shape           A number.
#' @param Mean.ESRD.time               A number. Mean ESRD when baseline eGFR is at mean and slope is at the mean of untreated .
#' @param Baseline.eGFR.diff.from.mean A number. The difference between the baseline eGFR of the patient and the mean.
#' @param slope.diff.from.control.mean A Number. The difference between the slope of the patient and the mean slope of control arm.
#' @param beta.b1        Baseline eGFR effect in mean=m*exp(beta.b1*Baseline.eGFR.diff.from.mean + beta.b2 * slope.diff.from.control.mean)
#'                         
#' @param beta.b2        Slope effect in mean=m*exp(beta.b1*Baseline.eGFR.diff.from.mean + beta.b2 * slope.diff.from.control.mean)

#' @return A ESRD time value for an individual.
#' @keywords internal

GenerateESRD.weibull <- function(ESRD.weibull.shape, Mean.ESRD.time, Baseline.eGFR.diff.from.mean, slope.diff.from.control.mean,beta.b1,beta.b2
                              , ...) {
  k=ESRD.weibull.shape
  lambda=Mean.ESRD.time/gamma(1+1/k)
  ESRD.time0=rweibull(n=1,shape=k,scale=lambda)
  ESRD.time=ESRD.time0*exp(beta.b1*Baseline.eGFR.diff.from.mean + beta.b2 * slope.diff.from.control.mean)
  return(ESRD.time)
 
}



#' Finds the ESRD time for an individual patient by generating mechanism option 4:log normal distribution, mean=m*exp(beta.b1*Baseline.eGFR.diff.from.mean + beta.b2 * slope.diff.from.control.mean) 
#' Jian added this option on 4/25/2025
#' @param ESRD.lognormal.sigma           A number.
#' @param Mean.ESRD.time               A number. Mean ESRD when baseline eGFR is at mean and slope is at the mean of untreated .
#' @param Baseline.eGFR.diff.from.mean A number. The difference between the baseline eGFR of the patient and the mean.
#' @param slope.diff.from.control.mean A Number. The difference between the slope of the patient and the mean slope of control arm.
#' @param beta.b1        Baseline eGFR effect in mean=m*exp(beta.b1*Baseline.eGFR.diff.from.mean + beta.b2 * slope.diff.from.control.mean)
#'                         
#' @param beta.b2        Slope effect in mean=m*exp(beta.b1*Baseline.eGFR.diff.from.mean + beta.b2 * slope.diff.from.control.mean)

#' @return A ESRD time value for an individual.
#' @keywords internal

GenerateESRD.lognormal <- function(ESRD.lognormal.sigma, Mean.ESRD.time, Baseline.eGFR.diff.from.mean, slope.diff.from.control.mean,beta.b1,beta.b2
                                 , ...) {
  mu=log(Mean.ESRD.time)-ESRD.lognormal.sigma^2/2
  ESRD.time0=rlnorm(n=1,meanlog = mu, sdlog=ESRD.lognormal.sigma )
  ESRD.time=ESRD.time0*exp(beta.b1*Baseline.eGFR.diff.from.mean + beta.b2 * slope.diff.from.control.mean)
  return(ESRD.time)
  
}

#' Finds the death time for an individual patient.
#' 
#' @param teGFR1           A numeric vector for an individual's true eGFR value.
#' @param max.obs.time     A maximun set of observational time points for an individual.
#' @param lambda.b0        Death hazard rate = 
#'                         lambda.b0 + lambda.b2 * teGFR + lambda.b3 * min(slope, 0)
#'                         (per year) in control group
#' @param lambda.b1        Death hazard rate = 
#'                         lambda.b1 + lambda.b2 * teGFR + lambda.b3 * min(slope, 0) 
#'                         (per year) for death in treatment group.
#' @param lambda.b2        Coefficient for Death hazard rate. The default value is 0.
#' @param lambda.b3        Coefficient for Death hazard rate. The default value is 0.
#' 
#' @return A Death time value for an individual.
#' @keywords internal
GenerateDeath <- function(teGFR1, Group, BaseSlope, LongTermTxSlope
                          , trt, max.obs.time, lambda.b0, lambda.b1
                          , lambda.b2, lambda.b3, ...) {
  stopifnot(length(BaseSlope) == 1
            , length(LongTermTxSlope) == 1
            , length(Group) == 1
            , length(teGFR1) == length(max.obs.time))
  
  tx.one.person  <- if(Group == 0) tail(trt[[1]], - 1) else tail(trt[[2]], - 1)
  
  t.diff <- diff(max.obs.time)
  lambda <- ifelse(tx.one.person == 0
                   , lambda.b0 + (lambda.b2 * head(teGFR1, - 1)) + (lambda.b3 * min(BaseSlope, 0))
                   , lambda.b1 + (lambda.b2 * head(teGFR1, - 1)) + (lambda.b3 * min(LongTermTxSlope,0)))
  death.length <- mapply(function(lambda) ifelse(lambda > 0, rexp(1, lambda), Inf)
                         , lambda)
  
  if(any(death.length <= t.diff)) {
    index <- match(1, death.length <= t.diff)
    return(max.obs.time[index] + death.length[index])
  } else {return(Inf)}
}
