#' Find eGFR at each observational points for the patient in study
#'
#' @param teGFR1             The teGFR value followed by time for the patient. 
#' @param Group              The group number for the individual.
#' @param bvecs              The baseline slope, baseline intercept, 
#'                           and long-term treatment slope for the individual.
#' @param auto.residual      Autocorrelation of the residuals for neighboring visiting.
#' @inheritParams PatientInfoMayOutbound
#' @inheritParams FindOnePersonTeGFR
#' @param ...                Ignored
#'
#' @return
#' A \code{string} of eGFR value for one patient.
#' @keywords internal
FindOnePersonEGFR <- 
function( teGFR1
        , Group
        , bvecs
        , auto.residual
        , var.residual.a0
        , var.residual.a1
        , var.residual.POM
        , t.df.residual
        , wt.residual
        , ...) {
  
  var.residual   <- pmax(0, var.residual.a0 + var.residual.a1 * teGFR1^var.residual.POM)
  length.z       <- length(unique(teGFR1))
  length.w       <- length(teGFR1)
  length.diff    <- length.w - length.z
  ### biology effect
  if(auto.residual==1){
    residual.z <- rep(rnorm(1), length.z)
  } else {
    if(auto.residual == 0) {
      residual.z <- rnorm(length.z)
    } else {
      residual.z <- arima.sim(n = length.z, list(ar = auto.residual)
                              , sd = sqrt(1 - (auto.residual ^ 2)))
    }
  }
  
  ### random effect;
  residual.w     <- rt(n = length.w, df = t.df.residual)
  if(is.finite(t.df.residual))
    residual.w <- residual.w * sqrt((t.df.residual - 2) / t.df.residual)
    
  residual.base  <- wt.residual * residual.z[   1] +
                    (sqrt(1 - (wt.residual ^ 2)) * residual.w[    1 : (1 + length.diff) ])
  residual.fu    <- wt.residual * residual.z[ - 1] +
                    (sqrt(1 - (wt.residual ^ 2)) * residual.w[ - (1 : (1 + length.diff))])
  residual       <- c(residual.base, residual.fu) * sqrt(var.residual)

  ObservedEGFR   <- as.numeric(teGFR1 + residual)
  ObservedEGFR[ObservedEGFR<0]   <- 0 #truncate observed eGFR at 0. 11/21/2025
  ResidualZ      <- as.numeric(c(rep(residual.z[1], (1 + length.diff)), residual.z[ - 1]))
  residual.bio   <- wt.residual * ResidualZ * sqrt(var.residual)
  TrueEGFRBio    <- teGFR1 + residual.bio
  list(Base = bvecs
      , TrueEGFR = teGFR1
      , ObservedEGFR = ObservedEGFR
      , ResidualZ = ResidualZ
      , ResidualW = residual.w
      , Residual = residual
      , TrueEGFRBio = TrueEGFRBio
      )
}
