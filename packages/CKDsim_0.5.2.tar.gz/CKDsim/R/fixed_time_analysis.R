#' Fixed time analysis
#' 
#' @param eGFRRecords          A \code{data.frame} include all patients eGFR record.
#' @param BaseFile             A \code{data.frame} include all the time information for the patients.
#' @param fixed.time           The time to compare the eGFR value with baseline eGFR for 
#'                             fixed time analysis.
#' @param ft.death             Death be included in the composite outcome for fixed time analysis.
#'                             Default setting is \code{TRUE}
#' @param ft.confirmation      Confirmation for EGFR if generated with confirmation. Default is 
#'                             \code{FALSE}.
#' @param ft.drop.percent      A designated percent reduction in eGFR from average baseline value
#'                             for fixed time analysis. \code{ft.drop.percent} can be a number or 
#'                             a vector c(30, 40, 50), the default value is NA
#' @param ft.drop.value        A designated absolute reduction (in ml/min/1.73m2) in eGFR from 
#'                             average baseline value for fixed time analysis. \code{ft.drop.value}
#'                              can be a number or a vector like c(10, 20, 30). Default value is NA. 
#' @param ft.drop.to           A designated eGFR level (in ml/min/1.73m2) for fixed time analysis. 
#'                             \code{ft.drop.to} can be a number or a vector c(20, 15, 10). Default 
#'                             value is NULL.
#' @param ...                  Discarded.
#'
#' \enumerate{
#'    \item{
#'     For the fixed time analysis, if extracted time points (fixed.time or baseline measurement)
#'     have multiple measurements, we will take the average eGFR as benchmark, and compare the 
#'     eGFR difference between fixed time to baseline.
#'    }
#'    \item{
#'    We allow a repeat eGFR measurement which by setting the additonal 
#'    time for repeat measurement \code{add.confirm}.
#'    }
#'    \item{
#'    If the user specifies more than one of the \code{drop.percent}, \code{drop.value}
#'    and \code{drop.to}, we explore a sequence of thresholds combinations from 
#'    the supplied vectors or factors. For each thresholds combination, 
#'    an "event" is declased for the dichotomous outcome if any of the threshold are reached.
#'    }
#' }
#' 
#' @return  A dataset which include proportion difference between treated group and untreated group 
#' (P0-P1), and standard error for P0-P1. If the cell counts from freqency table is less than 5, the 
#' warning message shows "Fixed time analysis may be inproper for your small size study".
#' @export
FixedTimeAnalysis <- function(eGFRRecords, BaseFile
                              , ft.death        = TRUE
                              , fixed.time
                              , ft.confirmation = FALSE
                              , ft.drop.percent = NA_real_
                              , ft.drop.value   = NA_real_
                              , ft.drop.to      = NA_real_
                              , ...) {
  {#parameter checking
  stopifnot(length(fixed.time) >= 1)
  stopifnot(is.logical(ft.death))
  stopifnot(isValidBaseFile(BaseFile))
  }# end checking
  
    des.combination <- data.frame( IncDeath  = ft.death
                                 , FixedTime = fixed.time
                                 , Confirmed = ft.confirmation
                                 , DropPct   = ft.drop.percent
                                 , DropValue = ft.drop.value
                                 , DropTo    = ft.drop.to)
  
    baseline.egfr <- BaselineEGFR(eGFRRecords)
    fixSpecClass(mdply( des.combination, RunFTOneSetting
                      , eGFRRecords, BaseFile, baseline.egfr)
                )
}

#' Run one set parameter for Fixed Time analysis.
#' @param FixedTime   The time to compare the eGFR value with baseline eGFR for 
#'                    fixed time analysis.
#' @param DropPct     A designated percent reduction in eGFR from the average baseline 
#'                    value for fixed time analysis. \code{ft.drop.percent} 
#'                    default value is NA.
#' @param DropValue   A designated absolute reduction (in ml/min/1.73m2) in eGFR from  
#'                    average baseline value for fixed time analysis. 
#'                    \code{ft.drop.value} default value is NA.
#' @param DropTo      A designated eGFR level (in ml/min/1.73m2) for fixed time analysis. 
#'                    \code{ft.drop.to} default value is NULL.
#' @param IncDeath    Death be included in the composite outcome for fixed time 
#'                    analysis.
#' @param Confirmed   Confirmation for EGFR if generated with confirmation.  
#' @param eGFRRecords   A \code{data.frame} include all patients eGFR record.
#' @param BaseFile      A \code{data.frame} include all the time information for 
#'                      the patients.
#' @param baseline.egfr The baseline eGFR value per patient.
#' @keywords internal
RunFTOneSetting <- function(IncDeath, FixedTime, Confirmed
                            , DropPct, DropValue, DropTo
                            , eGFRRecords, BaseFile, baseline.egfr){
  
  egfr.record <- if ("RepeatMeasure" %in% names(eGFRRecords)) {
    if (Confirmed == T) {
      eGFRRecords
    } else {
      eGFRRecords[eGFRRecords$RepeatMeasure == 0, names(eGFRRecords) != "RepeatMeasure"]
    }
  } else {eGFRRecords}
  
  egfr.average     <- AverageEGFR(egfr.record, time.point = FixedTime)
  
  designated.egfr  <- DesignatedEgfr(baseline.egfr$PersonID, baseline.egfr$BaselineEGFR
                                     , DropPct, DropValue, DropTo)
  
  egfr.w.designate <- merge.data.frame(egfr.average, designated.egfr, all.x = TRUE)
  egfr.w.designate$FTEvent <- 
                    ifelse(egfr.w.designate$AverageEGFR <= egfr.w.designate$DesignatedeGFR, 1, 0)
  
  ft.event         <- egfr.w.designate[, c("PersonID", "FTEvent")]
  
  study.time  <- pmin(BaseFile$AdminCen, BaseFile$LossFU, BaseFile$ESRD, BaseFile$Death, na.rm = T)
  pos.e.time   <- if (IncDeath == TRUE) {
    pmin(BaseFile$ESRD, BaseFile$Death, na.rm = TRUE)
  } else {BaseFile$ESRD}
  
  censor.at.ft <- ifelse(study.time > FixedTime, 0, ifelse(study.time == pos.e.time, 1, NA))
  censor.at.ft <- data.frame(PersonID = BaseFile$PersonID
                             , Group = BaseFile$Group
                             , Censor = censor.at.ft)
  
  ft.data      <- merge(censor.at.ft, ft.event, all = T)
  ft.data$Event<- ifelse(ft.data$Censor == 1, 1, ifelse(is.na(ft.data$Censor), NA, ft.data$FTEvent))
  
  freq.table   <- with(ft.data, table(Group, Event)) 
  p0        <- freq.table[1, 2] / sum(freq.table[1, ])
  p1        <- freq.table[2, 2] / sum(freq.table[2, ])
  prop.diff <- p1 - p0
  prop.se   <- sqrt((p0 * (1 - p0) / sum(freq.table[1, ])) +
    (p1 * (1 - p1) / sum(freq.table[2, ])))
  
  SPEC <- FTParams(  IncDeath
                   , FixedTime
                   , Confirmed=ifelse(("RepeatMeasure" %in% names(egfr.record)), T, F)
                   , DropPct
                   , DropValue
                   , DropTo)
  data.frame(SPEC, Prop.Diff.Value = prop.diff, Prop.Diff.SE = prop.se)
}

#' Find average eGFR for patients
#'
#' Find average eGFR for the measured eGFR and addtional measured eGFR for patients.
#' 
#' @param egfr.record         Patients eGFR records including \code{PersonID}, \code{Group}
#'                            , \code{Time} and \code{ObservedEGFR}
#' @param time.point          The time point for averaging the measurements.
#'
#' @return    A \code{data.frame} for patients' (by rolws) average eGFR
#' @keywords internal
AverageEGFR <- function(egfr.record, time.point) {
  stopifnot(inherits(egfr.record, 'data.frame'))
  #Find average eGFR
  kept.egfr            <- egfr.record[egfr.record$Time %in% time.point, ]
  average.egfr         <- tapply(kept.egfr$ObservedEGFR, kept.egfr$PersonID, mean)
  data.frame(PersonID = row.names(average.egfr), AverageEGFR = average.egfr)
}
