################################################################################
# Copyright 2012 University of Utah Study Design and Biostatistics Center
# This file constitutes portions of ongoing research and collaboration.
# Distributed under the GPL >= 2.0 License.
#
# PROJECT INFO
# Principal Investigator: Tome Greene
# Project Name:  FDA CKDsim simulation
# SDBC Consultant: Andrew Redd, Jenny Teng, Tom Greene
# File Author: Andrew Redd
# Date: 11/12/2012
#
# Description of File:
# Tests for the Simulation to verify successfull runs.
# 
# last updated: 11/12/2012
################################################################################
library(testthat)
library(CKDsim)

context("SimulateCKD")
test_that("SimulateCKD runs", {
sim <- 
SimulateCKD( data.title = 'test' 
           , n                  = 500
           , accrual            = 1
           , followup           = 4
           , freq               = 0.5
           , add.base.measure   = 0
           , early.measure      = 0.3
           , corr.slope.int     = 0.03       
           , mean.int           = 42.5   
           , sd.int             = 17.5              
           , int.low            = 20   
           , int.up             = 65      
           , slope.model        = "glg"
               , p.fast.progressors = 0.3   
               , mean.slope.fast    = - 7  , sd.slope.fast      = 3        
               , mean.slope.general = - 1  , sd.slope.general   = 3
           
           , log.gamma.loc       = c(-2.5)
           , log.gamma.scale     = 3.5
           , log.gamma.shape     = 3
           
           , intglg.b0           = 0
           , intglg.b1           = 1
           
           , add.long.term.effect= 0
           , pro.long.term.effect= 1
           
           , acute.model         = "ratio"
           , acute.A0            = 0
           , acute.SigA          = 1
           , acute.ratio         = 0
           
           , var.residual.a0     = 0 
           , var.residual.a1     = 0.67
           , t.df.residual       = 12
           
           , wt.residual         = 0.6
           , auto.residual       = 0.5
           
           , esrd.threshold.low  = 7 
           , esrd.threshold.up   = 11 
           
           , lambda.fu           = 0.03
           , lambda.b0           = 0.02
           , lambda.b1           = 0.02
           , lambda.b2           = 0
           , lambda.b3           = 0
           
           , p.missing           = 0.075
           , repeat.measure      = TRUE
)
expect_is(sim, 'list')

})
