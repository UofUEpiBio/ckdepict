# Package requires: "CKDsim", "harvestr", "plyr"
stopifnot(require(CKDsim))
stopifnot(require(harvestr))
stopifnot(require(plyr))
library(parallel)
library(doParallel)
registerDoParallel(8)

var(unlist(farm(gather(100), mean(rnorm(1e7)), .parallel=T)))

# Setting parameters for simulation
{p.base <- list(
  data.title         = "LargeData"
, n                  = 500
, accrual            = 2
, followup           = 4
, add.base.measure   = 0
, early.measure      = 0.3
, freq               = 0.5
, corr.slope.int     = 0.03       
, mean.int           = 40   
, sd.int             = 20              
, int.low            = 20   
, int.up             = 60      
, slope.model        = "glg"          
, p.fast.progressors = 0.3   
, mean.slope.fast    = - 7
, sd.slope.fast      = 3        
, mean.slope.general = - 1   
, sd.slope.general   = 3
, log.gamma.loc      = - 3
, log.gamma.scale    = 1.5
, log.gamma.shape    = 1.4
, effect.model       = "pro"
, long.term.effect   = 0.7
, acute.effect       = - 2
, auto.residual      = 0.5
, var.residual.a0    = 5 
, var.residual.a1    = 0.6
, t.df.residual      = 10
, wt.residual        = 0.5
, esrd.threshold.low = 7 
, esrd.threshold.up  = 12 
, lambda.fu          = 0.03
, lambda.b0          = 0.1 
, lambda.b1          = 0.1 
, lambda.b2          = - 0.001
, lambda.b3          = - 0.005
, p.missing          = 0.05
, repeat.measure     = TRUE
)}


# Number of simulation
N <- 8

#Simulate datasets
datasets <- farm(gather(N, seed=20120802), do.call(SimulateCKD, p.base), .parallel=T)

# Time-to-event Analysis
tte.analysis <- harvest(datasets, splat(TimeToEventAnalysis)
                        , tte.death = TRUE                  #scaler
                        , tte.truncate.time = 5             #parallel    
                        , tte.confirmation = FALSE          #parallel
                        , tte.drop.percent = c(50, 30)      #parallel
                        , tte.drop.value = 15               #parallel
                        , tte.drop.to = NA                  #parallel
                        , .parallel=T)

# Fixed Time Analysis
ft.analysis <- harvest(datasets, splat(FixedTimeAnalysis)
                       , ft.death = TRUE                         #scaler
                       , fixed.time = c(1, 2)                    #parallel
                       , ft.confirmation = FALSE                 #parallel
                       , ft.drop.percent = c(20, 30)             #parallel
                       , ft.drop.value = c(10, 15)               #parallel
                       , ft.drop.to = NA                         #parallel
                       , .parallel=T)

# Mixed Slope Analysis
mixed.analysis <- harvest(datasets, splat(MixedSlopeAnalysis)
                          , mixed.slope.model = c("one", "two")   #scaler
                          , mixed.truncate.time = NA              #parallel 
                          , mixed.total.time = c(4, 6)            #parallel
                          , mixed.knot.point = c(0.3333)          #parallel
                          , mixed.inc.group = F                   #parallel
                          , .parallel=T)

# Unweighted Slope Analysis
unwt.analysis <- harvest(datasets, splat(UnweightedSlopeAnalysis)
                         , unwt.slope.model = c("one", "two")     #scaler
                         , unwt.truncate.time = NA                #parallel
                         , unwt.min.followup = 1                  #parallel
                         , unwt.total.time = c(6)                 #parallel
                         , unwt.knot.point = 0.3333               #parallel
                         , .parallel=T)

# Summary Table for each analysis
####### Summary for time to event analysis ############
tte.summary <- SummaryAnalysis(tte.analysis
                               , ValueName = 'Log.HR.Value'
                               , SEName    = 'Log.HR.SE'
                               , Nsim      = 500              #scaler
                               , Npower = c(150,300,500,1000) #parallel
                               , alpha  = c(0.05)             #parallel
                               , se.select = "SE"             #parallel
)

####### Summary for fixed time analysis ############
ft.summary <- SummaryAnalysis(ft.analysis
                              , ValueName = 'Prop.Diff.Value'
                              , SEName    = 'Prop.Diff.SE'
                              , Nsim      = 500              #scaler
                              , Npower = c(150,300,500,1000) #parallel
                              , alpha  = c(0.05)             #parallel
                              , se.select = "SE"             #parallel
)

####### Summary for mixed slope analysis by slope type ############
mixed.1slope.summary <- SummaryAnalysis(mixed.analysis
                                        , ValueName = 'Single.Slope.Value'
                                        , SEName    = 'Single.Slope.SE'
                                        , Nsim      = 500              #scaler
                                        , Npower = c(150,300,500,1000) #parallel
                                        , alpha  = c(0.05)             #parallel
                                        , se.select = "SE"             #parallel
)


mixed.chronic.summary <- SummaryAnalysis(mixed.analysis
                                         , ValueName = 'Chronic.Slope.Value'
                                         , SEName    = 'Chronic.Slope.SE'
                                         , Nsim      = 500              #scaler
                                         , Npower = c(150,300,500,1000) #parallel
                                         , alpha  = c(0.05)             #parallel
                                         , se.select = "SE"             #parallel
)

mixed.acute.summary <- SummaryAnalysis(mixed.analysis
                                       , ValueName = 'Acute.Slope.Value'
                                       , SEName    = 'Acute.Slope.SE'
                                       , Nsim      = 500              #scaler
                                       , Npower = c(150,300,500,1000) #parallel
                                       , alpha  = c(0.05)             #parallel
                                       , se.select = "SE"             #parallel
)

mixed.total.summary <- SummaryAnalysis(mixed.analysis
                                       , ValueName = 'Total.Slope.Value'
                                       , SEName    = 'Total.Slope.SE'
                                       , Nsim      = 500              #scaler
                                       , Npower = c(150,300,500,1000) #parallel
                                       , alpha  = c(0.05)             #parallel
                                       , se.select = "SE"             #parallel
)


####### Summary for unweighted slope analysis by slope type ############
unwt.1slope.summary <- SummaryAnalysis(unwt.analysis
                                       , ValueName = 'Single.Slope.Value'
                                       , SEName    = 'Single.Slope.SE'
                                       , Nsim      = 500              #scaler
                                       , Npower = c(150,300,500,1000) #parallel
                                       , alpha  = c(0.05)             #parallel
                                       , se.select = "SE"             #parallel
)


unwt.chronic.summary <- SummaryAnalysis(unwt.analysis
                                        , ValueName = 'Chronic.Slope.Value'
                                        , SEName    = 'Chronic.Slope.SE'
                                        , Nsim      = 500              #scaler
                                        , Npower = c(150,300,500,1000) #parallel
                                        , alpha  = c(0.05)             #parallel
                                        , se.select = "SE"             #parallel
)

unwt.acute.summary <- SummaryAnalysis(unwt.analysis
                                      , ValueName = 'Acute.Slope.Value'
                                      , SEName    = 'Acute.Slope.SE'
                                      , Nsim      = 500              #scaler
                                      , Npower = c(150,300,500,1000) #parallel
                                      , alpha  = c(0.05)             #parallel
                                      , se.select = "SE"             #parallel
)

unwt.total.summary <- SummaryAnalysis(unwt.analysis
                                      , ValueName = 'Total.Slope.Value'
                                      , SEName    = 'Total.Slope.SE'
                                      , Nsim      = 500              #scaler
                                      , Npower = c(150,300,500,1000) #parallel
                                      , alpha  = c(0.05)             #parallel
                                      , se.select = "SE"             #parallel
)

# Efficiency
### bind the summary tables that you are going to compare the efficiency
table <- rbind(tte.summary, ft.summary, unwt.1slope.summary, unwt.total.summary)

### run efficiency table
efficiency <- FindEfficiency(table
                             , select = c("SE", "SE", "SEM", "SEM")  #parallel
                             , Ref.Mean = c(0.09643558, 0.10010646)  #parallel
                             , Ref.SE   = c(0.05509711, 0.01985015)  #parallel
)
