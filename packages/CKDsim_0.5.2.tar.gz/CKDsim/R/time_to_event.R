#' Time to event analysis
#' 
#' @param eGFRRecords          A \code{data.frame} include all patients eGFR record.
#' @param BaseFile             A \code{data.frame} include all the time information for 
#'                             the patients.
#' @param tte.death            Death be included in the composite outcome for time-to-event 
#'                             analysis.
#' @param tte.truncate.time    The truncated time for the eGFR Record. 
#'                             Default setting is NA means keep all the record for time-to-event
#'                             analysis.
#' @param tte.confirmation     Confirmation for EGFR if generated with confirmation. Default is 
#'                             \code{FALSE}.
#' @param tte.drop.percent     A designated percent reduction in eGFR from the average baseline 
#'                             value for time-to-event analysis. \code{tte.drop.percent} 
#'                             default value is NA.
#' @param tte.drop.value       A designated absolute reduction (in ml/min/1.73m2) in eGFR from  
#'                             average baseline value for time-to-event analysis. 
#'                             \code{tte.drop.value} default value is NA.
#' @param tte.drop.to          A designated eGFR level (in ml/min/1.73m2) for time-to-event analysis. 
#'                             \code{tte.drop.to} default value is NA.
#' @param ...                  Discarded.
#'
#' \enumerate{
#'    \item{
#'    We assume an analysis of time to first occurrence of ESRD possibly in conjunction with 
#'    a designated change in eGFR and possibly also in conjunction with death \code{tte.death}.
#'    }
#'    \item{
#'    We allow a repeat measurement to confirm eGFR event which by setting the additonal 
#'    time for repeat measurement \code{add.confirm}.
#'    }
#'    \item{
#'    If the user specifies more than one of the \code{drop.percent}, \code{drop.value}
#'    and \code{drop.to}, we explore a sequence of thresholds combinations from 
#'    the supplied vectors or factors. For each combination, whichever threshold occurs 
#'    first will trigger the event.
#'    }
#' }
#' @return  A dataset which include log hazards rate, and stand error by defining different 
#'          criteria. 
#' @importFrom survival coxph
#' @importFrom survival Surv
#' @export
TimeToEventAnalysis <- function(eGFRRecords, BaseFile
                                , tte.death         = TRUE
                                , tte.truncate.time = NA_real_
                                , tte.confirmation  = FALSE
                                , tte.drop.percent  = NA_real_
                                , tte.drop.value    = NA_real_
                                , tte.drop.to       = NA_real_
                                , ...) {
    {#Parameter Checking
    stopifnot(is.logical(tte.death))
    stopifnot(isValidBaseFile(BaseFile))
    } # End parameter checking
  
    des.combination <- data.frame( IncDeath     = tte.death
                                 , Trunc.Time   = tte.truncate.time
                                 , Confirmed    = tte.confirmation
                                 , DropPct      = tte.drop.percent
                                 , DropValue    = tte.drop.value
                                 , DropTo       = tte.drop.to)
    baseline.egfr <- BaselineEGFR(eGFRRecords) 
    
    fixSpecClass(mdply( des.combination, RunTTEOneSetting
                      , eGFRRecords, BaseFile, baseline.egfr)
                )
}


#' Run one set parameter for Time to event analysis.
#' @param IncDeath     Death be included in the composite outcome for time-to-event 
#'                     analysis.
#' @param Trunc.Time   The truncated time for the eGFR Record. Default setting is NA.
#' @param Confirmed    Confirmation for EGFR if generated with confirmation.
#' @param DropPct      A designated percent reduction in eGFR from the average baseline 
#'                     value for time-to-event analysis. \code{tte.drop.percent} 
#'                     default value is NA.
#' @param DropValue    A designated absolute reduction (in ml/min/1.73m2) in eGFR from  
#'                     average baseline value for time-to-event analysis. 
#'                     \code{tte.drop.value} default value is NA.
#' @param DropTo       A designated eGFR level (in ml/min/1.73m2) for time-to-event analysis. 
#'                     \code{tte.drop.to} default value is NULL.
#' @param eGFRRecords          A \code{data.frame} include all patients eGFR record.
#' @param BaseFile             A \code{data.frame} include all the time information for 
#'                             the patients.
#' @param baseline.egfr       The baseline eGFR value per patient.
#' @keywords internal                                                       
RunTTEOneSetting <- function(IncDeath, Trunc.Time, Confirmed
                             , DropPct, DropValue, DropTo
                             , eGFRRecords, BaseFile
                             , baseline.egfr){
  
  stopifnot(is.logical(Confirmed))
  
  egfr.record <- if ("RepeatMeasure" %in% names(eGFRRecords)) {
    if (Confirmed == T) {
        eGFRRecords
    } else {
        eGFRRecords[eGFRRecords$RepeatMeasure == 0, names(eGFRRecords) != "RepeatMeasure"]
    }
  } else {      
      eGFRRecords
  } 
  
  designated.egfr <- DesignatedEgfr(baseline.egfr$PersonID, baseline.egfr$BaselineEGFR
                                    , DropPct, DropValue, DropTo)
  
  egfr.w.designate <- merge.data.frame(egfr.record, designated.egfr, all.x = TRUE)
  
  meet.tte.egfr    <- subset(egfr.w.designate
                             , (egfr.w.designate$Time > 0 & 
                               egfr.w.designate$ObservedEGFR <= egfr.w.designate$DesignatedeGFR))
  
  tte.record       <- data.frame(tapply(meet.tte.egfr$Time
                                        , meet.tte.egfr$PersonID
                                        , FindEventTime
                                        , repeat.measure = 
                                            ifelse("RepeatMeasure" %in% names(meet.tte.egfr)
                                                   , TRUE, FALSE)))
  
  if (nrow(tte.record) != 0) {
    tte.record     <- data.frame(row.names(tte.record), tte.record[, 1])
  } else {
    tte.record     <- data.frame(NA, NA)
  }
  colnames(tte.record) <- c("PersonID", "DesignatedEventTime")
  tte.record <- na.omit(tte.record)
  
  logHR           <- DefineTteHR(tte.record, BaseFile, IncDeath, Trunc.Time)
  SPEC <-  TTEParams(  IncDeath
                     , Trunc.Time
                     , Confirmed=ifelse(("RepeatMeasure" %in% names(egfr.record)), T, F)
                     , DropPct
                     , DropValue
                     , DropTo)  #BindNonNAPar(pattern="NA", Par)
  unrowname(data.frame(SPEC, "Log.HR.Value" = logHR[[1]], "Log.HR.SE" = logHR[[2]], 
                       EventCt_Ctrl = logHR[[3]], EventCt_Trt = logHR[[4]]))
}

#' Find maximum designated eGFR for each indvidual
#' @param PersonID         The id number for the individual
#' @param BaselineEGFR     The baseline average eGFR value for each individual
#' @param DropPct          A designated percent reduction in eGFR from the average baseline value 
#'                         for time-to-event analysis.
#' @param DropValue        A designated absolute reduction (in ml/min/1.73m2) in eGFR from average 
#'                         baseline value for time-to-event analysis.
#' @param DropTo           A designated eGFR level (in ml/min/1.73m2) for time-to-event analysis. 
#' @param ...              Discarded.
#'  
#' Find maximum designated eGFR for each indvidual
#' 
#' @return A \code{data.frame} with \code{PersonID} and \code{DesignatedeGFR}
#' @keywords internal
DesignatedEgfr <- function(PersonID, BaselineEGFR, DropPct = NA, DropValue = NA
                           , DropTo = NA, ...) {
  delta.pct.reduction <- BaselineEGFR * ((100 - DropPct) / 100)
  delta.abs.reduction <- BaselineEGFR - DropValue
  max.designated.egfr <- pmax(delta.pct.reduction, delta.abs.reduction, DropTo, 0, na.rm = T)
  data.frame(PersonID, DesignatedeGFR = max.designated.egfr)
}

#' Find the minmun time which meet time-to-event criteria
#' @param time             Times for a individual which value meet time-to-event 
#'                         designated eGFR value.
#' @param repeat.measure   If the repeat measurments for confirming eGFR event for
#'                         time-to-event analysis and fixed time analysis exist.
#' @return           A \code{numeric} \code{Time} for an individual
#' @keywords internal
FindEventTime <- function(time, repeat.measure) {
  if (repeat.measure == FALSE) return(min(time, na.rm = T))
  if (repeat.measure == TRUE) {
    time      <- sort(time)
    time.diff <- diff(time)
    if(any(time.diff <= .Machine$double.eps * 16)) {
      index <- match(1, time.diff <= .Machine$double.eps * 16)
      return(time[index + 1])
    } else {return(NA)}}
}

#' title Calculate log hazard ratio and standard error for one designated level
#' @param des.time.id   A \code{data.frame} that provide information for patients
#'                      meet one designated level.
#' @param BaseFile      A \code{data.frame} include all the time information for the patients.
#' @param tte.death     Death be included in the composite outcome for time-to-event analysis.
#' @param Trunc.Time    The truncation time for the data.
#' @return  A \code{numeric} number for \code{LogHazardRatio} and \code{AssociateSE}.
#' @keywords internal
DefineTteHR <- function(des.time.id, BaseFile, tte.death, Trunc.Time) {
  Trunc.Time <- min(Trunc.Time, Inf, na.rm = T)
  new.basefile <- merge(BaseFile, des.time.id, all = T)
  
  study.time   <- pmin(new.basefile$AdminCen, new.basefile$LossFU, new.basefile$ESRD
                       , new.basefile$Death, new.basefile$DesignatedEventTime, na.rm = T)
  
  pos.e.time   <- if (tte.death == TRUE) {
    pmin(new.basefile$ESRD, new.basefile$Death, new.basefile$DesignatedEventTime, na.rm = T)
  } else {pmin(new.basefile$ESRD, new.basefile$DesignatedEventTime, na.rm = T)}
  
  event        <- ifelse(study.time == ifelse(is.na(pos.e.time), Inf, pos.e.time), 1, 0)
  
  surv.data     <- data.frame(PersonID = new.basefile$PersonID
                              , Group = new.basefile$Group
                              , Time = pmin(study.time, Trunc.Time) 
                              , Event = ifelse(study.time <= Trunc.Time, event, 0))
  
  EventCt_0 <- sum(surv.data$Group == 0 & surv.data$Event == 1, na.rm = TRUE)
  EventCt_1 <- sum(surv.data$Group == 1 & surv.data$Event == 1, na.rm = TRUE)
  if (sum(surv.data$Event, na.rm = TRUE) == 0) {
    return(data.frame(Value = NA_real_, SE = NA_real_
                      , EventCt_Ctrl = EventCt_0
                      , EventCt_Trt = EventCt_1))
  }
  cox.log.hr <- tryCatch(
    summary(coxph(Surv(Time, Event) ~ Group, data = surv.data))$coef[, c("coef", "se(coef)")]
    , error = function(e) c(coef = NA_real_, `se(coef)` = NA_real_)
  )
  data.frame(Value = cox.log.hr[[1]], SE = cox.log.hr[[2]]
             , EventCt_Ctrl = EventCt_0
             , EventCt_Trt = EventCt_1)
}

#' Bind the characters which does not match the pattern
#' @param pattern   Character string containing a regular expression to be matched in the 
#'                  given character vector
#' @param x         The character vector where matches are sought.
#' 
#' Bind the characters which does not match the pattern
#' 
#' @return A character
#' @keywords internal
BindNonNAPar  <- function(pattern, x) {
  x <- sapply(x,"[", i = 1)
  i <- grep(pattern, x)
  notmatch <- if (length(i <- grep(pattern, x)) >=1) {x[-i]} else{x}
  out <- paste(notmatch, collapse=",")
}
