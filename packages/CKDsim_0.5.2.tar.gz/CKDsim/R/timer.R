#' formats proc_time as a "hh:mm:ss" time string
#' 
#' @param x number of seconds.
#' 
#' @seealso print.proc_time, proc.time
formatTime <- function(x){
    x <- as.numeric(x)
    h <- x %/% 3600L
    m <- (x %% 3600L) %/%60L
    s <- x %% 60L
    ifelse(is.na(x), NA, sprintf("%02d:%02d:%2.0f",h,m,s))
}
timeString <- function(x){
    if(length(x)<=1) return(formatTime(x))
    n <- names(x)
    paste(n, formatTime(x), sep='=', collapse=' / ')
}

#' Create a timer
#' 
#' @param .on the default proc.time value to use.
#' 
#' Creates a timer object that you can use to time different tasks.
#' 
#' @return
#' Creates an object with two methods
#' \enumerate{
#'  \item \code{$cummulative} for cummulative time since creation
#'  \item \code{$lap} for timing individual steps.
#' }
#' @examples
#' t <- timer()
#' Sys.sleep(1)
#' t$lap()
#' Sys.sleep(2)
#' t$lap()
#' t$cummulative()
#' t$cummsg()
#' @export
#' @importFrom dostats redirf
timer <- function(.on='elapsed'){
    creation.time <- 
        last.check    <- proc.time()
    cummulative <- function(){
        proc.time() - creation.time
    }
    lap <- function(){
        on.exit(last.check <<- proc.time())
        proc.time() - last.check
    }
    lapmsg <- function(msg='', on=.on, format="%1$s finished in %2$s.\n", use_cat=TRUE){
        time <- lap()[on]
        x <- gettextf(format, msg, timeString(time))
        (if(use_cat)cat else print)(x)
        invisible(time)
    }
    cummsg <- function(msg='', on=.on, format="%1$s has been running %2$s\n", use_cat=TRUE){
        time <- cummulative()[on]
        x <- gettextf(format, msg, timeString(time))
        (if(use_cat)cat else print)(x)
        invisible(time)
    }
    list( cummulative = cummulative
        , lap         = lap
        , lapmsg      = lapmsg
        , cummsg      = cummsg
        )
}
