# CKDEPIsurrogate 0.4.1

- Added `predictionMedian` to `PredInt()` as the posterior point estimate from
  the same predictive draws used for the equal-tailed prediction interval.
- Updated tests, documentation, and the clinician-facing vignette to report the
  posterior median with the prediction interval.
- Documented exponentiation of the median and interval when the clinical model
  is fitted on the log-hazard-ratio scale.

# CKDEPIsurrogate 0.4.0

- Removed the unused `theta.h` argument from `POS()` after Tom confirmed that
  it should not enter the calculation.
- Updated examples, tests, the README, and the vignette to use the simplified
  POS interface.

# CKDEPIsurrogate 0.3.0

- Added `GammaSensitivity()` and its plot method to evaluate probability of
  benefit, prediction intervals, and optional phase 3 POS across an explicit
  range of `gamma.s` values while holding `SE.gamma` constant.
- Registered the clinician-facing HTML so it opens with R's `vignette()`
  function after installation.
- Embedded all vignette figures directly in the HTML so they remain visible in
  the installed package.

# CKDEPIsurrogate 0.2.1

- Expanded the introductory vignette with a clinician-facing narrative,
  interpretation guidance, a function-selection table, and suggested reporting
  language.

# CKDEPIsurrogate 0.2.0

- Added `plot()` methods for `ProbBen()`, `PredInt()`, and `POS()` results.
- Added shaded density regions corresponding to the reported probabilities and
  prediction interval.
- Added a short introductory vignette with a complete example workflow.

# CKDEPIsurrogate 0.1.0

- Added `ProbBen()`, reporting both sides of the benefit threshold.
- Added `PredInt()` for equal-tailed posterior prediction intervals.
- Added `POS()` for an independent future phase 3 trial.
- Added input validation, reproducible simulation, documentation, and tests.
