#' Define each observational time points within the study period
#'
#' @param accrual           Accrual period for study (yr).
#' @param followup          Additional follow up period for study (yr).
#' @param add.base.measure  Number of additional baseline measurement.
#'                          \code{add.base.measure} is set to \code{0} if there is 
#'                          no additional baseline measurement.
#' @param early.measure     A single early measurement which must between 0 and first 
#'                          regularly schedule follow-up measurement:
#'                          \code{early.measure} is set to \code{NULL} if there is no additonal 
#'                          early measurement.
#' @param freq              Freqency for patients back to measure eGFR.
#' 
#' @details
#' Study design
#' \enumerate{
#'     \item Assume uniform accrual of patients over \code{accrual} years.
#'     \item Assume \code{followup} years of additional follow-up after the last accruaed patients.
#'     \item Assume a fixed measurement schedule with measurements every \code{freq} years.
#'     \item Allow (an) optional additional measurement(s) at a user specified the number of 
#'           additonal baseline measurement.
#'     \item Allow an optional additional early measurement at a user specified time point during 
#'           the time interval between 0 and the first regularly schedule follow-up measurement 
#'           at time \code{freq}.
#' }
#' 
#' @return 
#' A \code{string} of the observational time points for the study
#' @export
DefineMaxObsTime <- function(accrual, followup, freq, add.base.measure = 0, early.measure = NULL) {  
  sub.obs <- seq(from=freq, to=(followup + accrual), by=freq)  
  sort(c(rep(0, add.base.measure + 1), early.measure, sub.obs))
}
