# Package requires: "CKDsim", "harvestr", "plyr"
stopifnot(require(CKDsim))
stopifnot(require(harvestr))
stopifnot(require(plyr))
options(harvestr.time=T, harvestr.use.cache=T)

library(doParallel)
registerDoParallel(8)
parallel=F

# Setting parameters for simulation
p.base <- {list(
  data.title         = "LargeData"
, n                  = 500
, accrual            = 2
, followup           = 4
, add.base.measure   = 1
, early.measure      = 0.3
, freq               = 0.5
, corr.slope.int     = 0.03       
, mean.int           = 40   
, sd.int             = 20              
, int.low            = 20   
, int.up             = 60      
, slope.model        = "glg"          
, p.fast.progressors = 0.3   
, mean.slope.fast    = - 7
, sd.slope.fast      = 3        
, mean.slope.general = - 1   
, sd.slope.general   = 3
, log.gamma.mean      = - 3
, log.gamma.sd    = 3.5
, log.gamma.shape    = 1.4
, effect.model       = "pro"
, long.term.effect   = 0.7
, acute.effect       = - 2
, auto.residual      = 0.4
, var.residual.a0    = 5 
, var.residual.a1    = 0.5
, t.df.residual      = 12
, wt.residual        = 0.5
, esrd.threshold.low = 7 
, esrd.threshold.up  = 12 
, lambda.fu          = 0.03
, lambda.b0          = 0.02 
, lambda.b1          = 0.02
, lambda.b2          = - 0.0001
, lambda.b3          = - 0.0005
, p.missing          = 0.05
, repeat.measure     = TRUE
)}


# Number of simulation
N <- 1000

#Simulate datasets
datasets <- farm(gather(N, seed=20121023), do.call(SimulateCKD, p.base), .parallel=parallel)

# Time-to-event Analysis
tte.analysis <- harvest(datasets, splat(TimeToEventAnalysis)
                        , tte.death = TRUE
                        , tte.confirmation = TRUE
                        , tte.drop.percent = c(50, 40, 30, 20)
                        , tte.drop.value = NA
                        , tte.drop.to = NA
                        , .parallel=parallel)


# Mixed Slope Analysis
mixed.analysis <- harvest(datasets, splat(MixedSlopeAnalysis)
                          , mixed.slope.model = c("one", "two")
                          , mixed.total.time = 5
                          , mixed.knot.point = c(0.3333)
                          , mixed.inc.group = F
                          , .parallel=parallel)

# Unweighted Slope Analysis
unwt.analysis <- harvest(datasets, splat(UnweightedSlopeAnalysis)
                         , unwt.slope.model = c("one", "two")
                         , unwt.min.followup = 1
                         , unwt.total.time = c(5)
                         , unwt.knot.point = 0.3333   
                         , show.par = F
                         , .parallel=parallel)

# Summary Table for analysis
myanalysis <- list(  tte.analysis
#                     , ft.analysis
                   , mixed.analysis
                   , unwt.analysis
                  )

save(myanalysis, file="analyses.RData")

# summary.analysis <- ldply(myanalysis, SummaryAnalysis
#                          , Nsim   = 500
#                          , Npower = c(150,300,500,1000)
#                          , alpha  = c(0.05)
#                          , se.select = "SE")

# summary.analysis <- summary.analysis[order(summary.analysis$MethodSpecs, summary.analysis$Npower), ]

