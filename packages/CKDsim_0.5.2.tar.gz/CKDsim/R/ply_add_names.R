
add_names <- function(y, .names=names(y)) {
    y <- as.list(y)
    for(i in seq_along(y)){
        if(is.null(attr(y[[i]], 'name', exact=T)))
            attr(y[[i]], 'name') <- .names[i] 
    }
    y
}
