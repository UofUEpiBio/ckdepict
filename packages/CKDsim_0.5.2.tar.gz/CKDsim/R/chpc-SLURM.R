{##############################################################################
# chpc-SLURM.R
#
# Copyright 2012 University of Utah Study Design and Biostatistics Center
# This file constitutes portions of ongoing research and collaboration.
# NOT FOR EXTERNAL DISTRIBUTION
#
# PROJECT INFO
# Principal Investigator: Tome Greene
# Project Name:  FDA CKDsim simulation
# SDBC Consultant: Andrew Redd, Jenny Teng, Tom Greene
# File Author: Andrew Redd
# Date: 11/6/2012
#
# Description
# This houses files for use with a High Performacen Cluster Setup
# The functions will Automatically Spawn Jobs using Moab resource managers.
#
#
# last updated: 11/19/2012
}###############################################################################
SLURM_spawn <-
function( cmd
        , time.limit
        , array         = NULL
        , depend        = NULL
        , depend.array  = NULL
        , nodes         = 1
        , ppn           = NULL
        , email         = get_email()
        , email.when    = c('NONE', 'BEGIN', 'END', 'FAIL', 'REQUEUE', 'ALL')[6]
        , name          = "Rjob"
        , file.only     = FALSE
        , file.name     = paste0(name, '.job')
        , account       = getOption("HCP::account")
        , shell         = getOption("HPC::shell", Sys.getenv("SHELL"))
        ){
    email.when <- match.arg(email.when, several.ok=TRUE)
    args <- c( sprintf("-J %s", name)       # Name of the job
             , sprintf("-t %s", time.limit) # time
             , sprintf("--nodes=%d", nodes) # number of nodes needed
             , sprintf("-n %d", ppn)        # required processors per node.
             , if(!is.null(depend      )) sprintf("--dependency=afterok:%s", paste(depend, collapse=':'))
             , if(!is.null(depend.array)) sprintf("--dependency=afterok:%s", paste(depend.array, collapse=':'))
             , if(!is.null(email       )) sprintf("--mail-user=%s"         , email)
             , if(!is.null(email.when  )) sprintf("--mail-type=%s"         , paste(email.when, collapse=','))
             , if(!is.null(account     )) sprintf("--account=%s"           , account)
             )
    if(!is.null(array)){
        cmd  <- gsub("$ARRAYID_VAR", "$SLURM_ARRAY_TASK_ID", cmd)
        cmd  <- c("ARRAYID_VAR=$SLURM_ARRAY_TASK_ID", cmd)
        args <- c(args, sprintf("--array=%s", paste(array, collapse=',')))
    }
    {# add Arguments 
    cmd <- c( sprintf("#! %s", shell)
            , paste("# SBATCH", args)
            , cmd
            )
    }
    cat( cmd, file=file.name, sep='\n')
    system2("chmod", c("u+x", file.name))
    if(!file.only){
        if(Sys.which('sbatch') == '') {
            warning("Could not find `sbatch` command. "
                   ,"Writing SLURM job file `", file.name, "`.")
        } else {
            cat('sbatch', args, file.name, '\n', sep='\n    ')
            output <- system2('sbatch', c(args, file.name), stdout=TRUE)
            as.integer(gsub(" *Submitted batch job *", '', output))
        }
    }
}
SLURM_get_accounts <-
function(user=get_user()){
#' Get associated accounts on SLURM machine.
#' @param user the user for whom to get information.
    output <- system2('sacctmgr', c('-P', 'show', 'assoc', sprintf("user=%s", user)), stdout=TRUE)
    utils::read.table(textConnection(output), header=TRUE, sep="|")
}
