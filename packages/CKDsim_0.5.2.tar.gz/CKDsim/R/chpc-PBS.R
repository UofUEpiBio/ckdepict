{##############################################################################
# chpc-PBS.R
#
# Copyright 2012 University of Utah Study Design and Biostatistics Center
# This file constitutes portions of ongoing research and collaboration.
# NOT FOR EXTERNAL DISTRIBUTION
#
# PROJECT INFO
# Principal Investigator: Tome Greene
# Project Name:  FDA CKDsim simulation
# SDBC Consultant: Andrew Redd, Jenny Teng, Tom Greene
# File Author: Andrew Redd
# Date: 11/6/2012
#
# Description
# This houses files for use with a High Performacen Cluster Setup
# The functions will Automatically Spawn Jobs using Moab resource managers.
#
#
# last updated: 11/19/2012
}###############################################################################
#' Spawn a Torque/PBS job.
#' @param cmd the shell command to run.
#' @param time.limit the wall time limit for the job.
#' @param array full indices of array ids.
#' @param depend a job to depend on.
#' @param depend.array an array that this job is dependent on.
#' @param nodes number of nodes needed.
#' @param ppn processors per node.
#' @param email where to send updates.
#' @param email.when when to send an update.
#' @param name name of the job to track by.
#' @param file.only write the job file without submitting.
#' @param file.name file name to create.
#' @param account account to use for charging usage.
#' @param ... ignored, present for compatibility.
PBS_spawn <-
function( cmd                                       #' @param cmd the shell command to run.
        , time.limit                                #' @param time.limit the wall time limit for the job
        , array         = NULL                      #' @param array full indices of array ids.
        , depend        = NULL                      #' @param deppend a job to depend on.
        , depend.array  = NULL                      #' @param deppend.array an array that this job is dependent on.
        , nodes         = 1                         #' @param nodes number of nodes needed.
        , ppn           = NULL                      #' @param ppn processors per node.
        , email         = get_email()               #' @param email where to send updates.
        , email.when    = c('a', 'e', 'b', 'n')     #' @param email.when when to send an update.
        , name          = NULL                      #' @param name name of the job to track by, if empty will use the current date to form a name.
        , file.only     = !missing(file.name)       #' @param only print the job file but do not submit?
        , file.name     = paste0(name, ".job")      #' @param file.name file name to create.
        , account       = getOption("HCP::account") #' @param account account to use for charging usage.
        , ...){                                     #' @param ... ignored, but present for compatability.
    if(is.null(name)) name <- format(Sys.Date(), "CKDsim_job_%Y-%m-%d")
    args <- c( sprintf("-N %s", name)
             , sprintf(" -l nodes=%d%s,walltime=%s",nodes,format_ppn(ppn),time)
             , if(depend       != "") sprintf("-W depend=afterok:%s", depend       )
             , if(depend.array != "") sprintf("-W depend=afterokarray:%s", depend.array )
             , if(!is.null(email  ))  sprintf("-m ae -M %s", email)
             , if(!is.null(account))  sprintf("-A %s", account)
             , "-S /bin/bash "
             )
    if(!is.null(array)){
        cmd  <- gsub("$ARRAYID_VAR", "$PBS_ARRAYID", cmd)
        args <- c(args, sprintf("-t %s", paste(array, collapse=',')))
    }
    if(!file.only){
        if(Sys.which('qsub') != ""){
            return(system2('qsub', args, stdout=TRUE, input=cmd))
        } else warning("could not find job scheduler `qsub`!  writing job file instead.")
            warning("Could not find `sqsub` job scheduler. "
                   ,"Writing PBM job file `", file.name, "`.")
    }
    cat(paste("#PBS", args, '\n'), cmd, file=paste0(name, '.job'))
}
#' Get the jobs running on the server.
PBS_jobs <-
function(){
#~     STDOUT
#~        If an operand presented to the qstat utility is a batch job_identifier and the
#~        -f option is not specified, the qstat utility shall display the following items on a
#~        single line, in the stated order, with white space between each item, for each successfully processed operand:
#~         * The batch job_identifier
#~         * The batch job name
#~         * The Job_Owner attribute
#~         * The CPU time used by the batch job
#~         * The batch job state
#~         * The batch job location
output <- system2("qstat", '-f', stdout=TRUE)
output <- Filter(nchar, output)
job.rows <- cumsum(grepl("^Job Id:", output))
job.parts <- strsplit(gsub('^\\t+', '', output), '\\s*(=|(?<=Job Id):)\\s*', perl=TRUE)
job.entries <- lapply(job.parts, function(x){structure(x[-1], names=x[1])})
job.info <- lapply(split(job.entries, job.rows), function(x) {
    as.data.frame(as.list(unlist(x)), stringsAsFactors=FALSE)
})
job.info <- rbind.fill(job.info)
if('Job.Id'   %in% names(job.info)) job.info[['Job.Id'  ]] <- as.integer(job.info[['Job.Id']])
if('qtime'    %in% names(job.info)) job.info[['qtime'   ]] <- strptime(job.info[['qtime']], "%a %b %d %H:%M:%S")
if('ctime'    %in% names(job.info)) job.info[['ctime'   ]] <- strptime(job.info[['ctime']], "%a %b %d %H:%M:%S")
if('Priority' %in% names(job.info)) job.info[['Priority']] <- as.integer(job.info[['Priority']])
job.info
}
