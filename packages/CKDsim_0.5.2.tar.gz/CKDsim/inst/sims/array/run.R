################################################################################
# Copyright 2012 University of Utah Study Design and Biostatistics Center
# This file constitutes portions of ongoing research and collaboration.
# NOT FOR EXTERNAL DISTRIBUTION
#
# PROJECT INFO
# Principal Investigator: Tome Greene
# Project Name:  FDA CKDsim simulation
# SDBC Consultant: Andrew Redd, Jenny Teng, Tom Greene
# File Author: Andrew Redd
# Date: 11/6/2012
#
# Description of Analysis:
# This file is to be used with the run.job 
# 
# Steps for using this file:
# 
# 1. Edit the p.grid object to define the parameters for simulating data.
# 2. Add/Remove the analyses to perform.
# 3. Add the objects to save in the 'Save Results' section.
# 4. Save and Upload to CHPC.
# 5. Edit the run.job (instructions there).
# 
# last updated: 11/6/2012
################################################################################


{ ### SETUP: ### DO NOT EDIT ####
stopifnot(require(CKDsim))
stopifnot(require(harvestr))
stopifnot(require(plyr))
stopifnot(require(dostats))
stopifnot(require(stringr))
options(stringsAsFactors=FALSE)
library(doParallel)
registerDoParallel(detectCores())
options(harvestr.parallel=T)
# repeat code below, for all desired parameter combinations
setnum <- if(length(commandArgs(T)>=1)) as.numeric(commandArgs(T)[1]) else
          if(length(commandArgs(F)>=2)) {
             ca <- grep("^-", commandArgs(F), value=T, invert=T)
             print(ca)
             name = basename(tail(ca, 1))
             as.numeric(gsub(".*(\\d+).*", "\\1", name, perl=T))
          } else stop("cannot determine number")
setnum
# Number of simulation
N <- if(length(commandArgs(T))>=2) as.numeric(commandArgs(T)[2]) else 1000
}

###################################
###         Edit Below         ####
###################################

# Setting parameters for simulation
{p.grid <- mutate(expand.grid(
    log.gamma.mean     = c(-2.5, -4, -5.5)
  , acute.effect       = c(-3, -1.5, 0)
  , log.gamma.sd       = c(3.5)
  , n                  = 500
  , accrual            = 2
  , followup           = 4
  , add.base.measure   = 0
  , early.measure      = 0.3
  , freq               = 0.5
  , corr.slope.int     = 0.03       
  , mean.int           = 42.5   
  , sd.int             = 17.5              
  , int.low            = 20   
  , int.up             = 65      
  , p.fast.progressors = 0.3   
  , mean.slope.fast    = - 7
  , sd.slope.fast      = 3        
  , mean.slope.general = - 1   
  , sd.slope.general   = 3
  , log.gamma.shape    = 3
  , long.term.effect   = 0.7
  , auto.residual      = 0.5
  , var.residual.a0    = 0 
  , var.residual.a1    = 0.67
  , t.df.residual      = 12
  , wt.residual        = 0.6
  , esrd.threshold.low = 7 
  , esrd.threshold.up  = 11 
  , lambda.fu          = 0.03
  , lambda.b0          = 0.02
  , lambda.b1          = 0.02
  , lambda.b2          = 0
  , lambda.b3          = 0
  , p.missing          = 0.075
  , repeat.measure     = TRUE
  )
  , slope.model        = "glg"          
  , effect.model       = "pro"
  , data.title        = paste(log.gamma.mean, acute.effect, sep="/")
)}
p.base <- unclass(p.grid[setnum,])


{ #Simulate datasets
cat('creating datasets...')
datasets.ex1 <- farm(gather(N, seed=20120802), do.call(SimulateCKD, p.base)
                    , .parallel=getOption('harvestr.parallel', F))
cat('done.\n')
}

{# Time-to-event Analysis
cat('TTE 1...')
tte.analysis.part1 <- harvest(datasets.ex1, splat(TimeToEventAnalysis)
                        , tte.death = TRUE                     #scaler
                        , tte.truncate.time = 6                #parallel
                        , tte.confirmation = c(T,   T,  T,  T,  T,  F,  F,  F,  F,  F)  #parallel
                        , tte.drop.percent = c(57, 50, 40, 30, 20, 57, 50, 40, 30, 20)  #parallel
                        , tte.drop.value = NA                  #parallel
                        , tte.drop.to = NA                     #parallel
                        , .parallel=getOption('harvestr.parallel', F)
)
cat('done.\n')
}

{# Time-to-event Analysis
cat('TTE 2...')
tte.analysis.part2 <- harvest(datasets.ex1, splat(TimeToEventAnalysis)
                        , tte.death = TRUE                     #scaler
                        , tte.truncate.time = 4.5              #parallel
                        , tte.confirmation = c(T,   T,  T,  T,  T,  F,  F,  F,  F,  F)  #parallel
                        , tte.drop.percent = c(57, 50, 40, 30, 20, 57, 50, 40, 30, 20)  #parallel
                        , tte.drop.value = NA                  #parallel
                        , tte.drop.to = NA                     #parallel
                        , .parallel=getOption('harvestr.parallel', F)
)
cat('done.\n')
}

{# Time-to-event Analysis
cat('TTE 3...')
tte.analysis.part3 <- harvest(datasets.ex1, splat(TimeToEventAnalysis)
                        , tte.death = TRUE                     #scaler
                        , tte.truncate.time = 3                #parallel
                        , tte.confirmation = c(T,   T,  T,  T,  T,  F,  F,  F,  F,  F)  #parallel
                        , tte.drop.percent = c(57, 50, 40, 30, 20, 57, 50, 40, 30, 20)  #parallel
                        , tte.drop.value = NA                  #parallel
                        , tte.drop.to = NA                     #parallel
                        , .parallel=getOption('harvestr.parallel', F)
)
cat('done.\n')
}

{# Time-to-event Analysis
cat('TTE 4...')
tte.analysis.part4 <- harvest(datasets.ex1, splat(TimeToEventAnalysis)
                        , tte.death = TRUE                     #scaler
                        , tte.truncate.time = 6                #parallel
                        , tte.confirmation = c(T)              #parallel
                        , tte.drop.percent = c(99)             #parallel
                        , tte.drop.value = NA                  #parallel
                        , tte.drop.to = NA                     #parallel
                        , .parallel=getOption('harvestr.parallel', F)
)
cat('done.\n')
}

{# Summary Table for each analysis
####### Summary for time to event analysis ############
cat('Creating Summary 1...')
tte.summary.part1 <- SummaryAnalysis(tte.analysis.part1
                               , ValueName = 'Log.HR.Value'
                               , SEName    = 'Log.HR.SE'
                               , Nsim      = 500              #scaler
                               , Npower = c(250,500,1000)     #parallel
                               , alpha  = c(0.05)             #parallel
                               , se.select = "SE"             #parallel
                               , .parallel=getOption('harvestr.parallel', F)
)
cat('done.\n')
}

{# Summary Table for each analysis
####### Summary for time to event analysis ############
cat('Creating Summary 2...')
tte.summary.part2 <- SummaryAnalysis(tte.analysis.part2
                               , ValueName = 'Log.HR.Value'
                               , SEName    = 'Log.HR.SE'
                               , Nsim      = 500              #scaler
                               , Npower = c(250,500,1000)     #parallel
                               , alpha  = c(0.05)             #parallel
                               , se.select = "SE"             #parallel
                               , .parallel=getOption('harvestr.parallel', F)
)
cat('done.\n')
}

{# Summary Table for each analysis
####### Summary for time to event analysis ############
cat('Creating Summary 3...')
tte.summary.part3 <- SummaryAnalysis(tte.analysis.part3
                               , ValueName = 'Log.HR.Value'
                               , SEName    = 'Log.HR.SE'
                               , Nsim      = 500              #scaler
                               , Npower = c(250,500,1000)     #parallel
                               , alpha  = c(0.05)             #parallel
                               , se.select = "SE"             #parallel
                               , .parallel=getOption('harvestr.parallel', F)
)
cat('done.\n')
}

{# Summary Table for each analysis
####### Summary for time to event analysis ############
cat('Creating Summary 4...')
tte.summary.part4 <- SummaryAnalysis(tte.analysis.part4
                               , ValueName = 'Log.HR.Value'
                               , SEName    = 'Log.HR.SE'
                               , Nsim      = 500              #scaler
                               , Npower = c(250,500,1000)     #parallel
                               , alpha  = c(0.05)             #parallel
                               , se.select = "SE"             #parallel
                               , .parallel=getOption('harvestr.parallel', F)
)
cat('done.\n')
}

{ # Save Results
cat('Saving results...')
save( tte.summary.part1
    , tte.summary.part2
    , tte.summary.part3
    , tte.summary.part4
    , file=sprintf("%d.RData", setnum))
cat('done.\n')
}
