#' Probability of success in an independent future phase 3 trial
#'
#' @param fn.csv CSV file path or data frame containing columns `alpha`, `beta`,
#'   and `sigSqClinonSur`.
#' @param gamma.s Estimated surrogate treatment effect from a preliminary trial.
#' @param SE.gamma Standard error of `gamma.s`.
#' @param SE.theta Projected standard error of the estimated clinical treatment
#'   effect in the future phase 3 trial.
#' @param alpha Two-sided type I error level for the future hypothesis test.
#' @param seed Optional nonnegative integer used to reproduce the simulation.
#'
#' @return A list containing predictive draws and probability of success.
#' @export
POS <- function(
    fn.csv,
    gamma.s,
    SE.gamma,
    SE.theta,
    alpha = 0.05,
    seed = NULL) {
  .checkNumber(SE.theta, "SE.theta")
  if (SE.theta <= 0) {
    stop("SE.theta must be greater than 0", call. = FALSE)
  }
  .checkProbability(alpha, "alpha")

  prediction <- .simulateTheta(
    fn.csv = fn.csv,
    gamma.s = gamma.s,
    SE.gamma = SE.gamma,
    seed = seed
  )

  # The future trial uses a two-sided test, but success requires rejection in
  # the beneficial direction. Larger clinical treatment effects are beneficial.
  criticalValue <- stats::qnorm(1 - alpha / 2)
  conditionalPOS <- stats::pnorm(
    prediction$thetaDraws / SE.theta - criticalValue
  )

  result <- list(
    thetaDraws = prediction$thetaDraws,
    probabilityOfSuccess = mean(conditionalPOS),
    SE.theta = SE.theta,
    alpha = alpha,
    gamma.s = gamma.s,
    SE.gamma = SE.gamma,
    nDraws = prediction$nDraws
  )

  class(result) <- c("CKDEPIPOS", "CKDEPIprediction")
  result
}
