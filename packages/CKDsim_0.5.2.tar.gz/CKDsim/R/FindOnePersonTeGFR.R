#' Find true eGFR at each observational points for the patient in study
#'
#' @param bvecs            The baseline slope, baseline intercept, 
#'                         and long-term treatment slope for the patient.
#' @param trt              A \code{list} with treatment status (treated = 1, untreated = 0) 
#'                         at each observational time points for two groups 
#'                         (\code{ConTxStatus} and \code{ExpTxStatus}).
#' @param obs.time         A \code{string} of the observational time points for the study.
#' @param acute.model      Two different models for the acute effect: 
#' @inheritParams PatientInfoMayOutbound
#'
#' @return
#' A \code{string} of teGFR value for one patient.
#' @keywords internal
FindOnePersonTeGFR <- 
function( Group
        , bvecs
        , trt
        , obs.time
        , acute.model
        , acute.A0
        , acute.SigA
        , acute.ratio
        , ...) {
  
  tx.one.person  <- if(Group == 0) trt[[1]] else trt[[2]]
  stopifnot(length(tx.one.person) == length(obs.time))
  tx             <- tail(tx.one.person, - 1)
  tx.diff        <- diff(tx.one.person)
  time           <- tail(obs.time, - 1)
  time.diff      <- diff(obs.time)
  acute.50    <- rnorm(1, mean = acute.A0, sd = acute.SigA)
  
  slope <- ifelse(tx == 0, bvecs["BaseSlope"], bvecs["LongTermTxSlope"])
  start.value <- bvecs["BaseIntercept"]
  tegfr.temp  <- cumsum(c(start.value, (time.diff * slope)))
  {
  if ("ratio" %in% acute.model){
    acute.slope <- (1 - acute.ratio) * acute.50 / 35
    acute.effect <- if (acute.50 > 0) {
      pmax(acute.50 + acute.slope * (tegfr.temp - 50), 0)
    } else{
      if (acute.50 < 0) {
        pmin(acute.50 + acute.slope * (tegfr.temp - 50), 0)
      } else {
        0
      }
    }
  } else {
      if ("log" %in% acute.model)
      {
        acute.effect = (acute.50/1.20397) * (log(pmax(tegfr.temp, 15)) - log(15))
      } else {
        stop(sprintf("acute.model='%s' is not implimented.", acute.model))
      }
    } 
  }
  ifelse(tx.one.person == 0, tegfr.temp, tegfr.temp + acute.effect)
}

