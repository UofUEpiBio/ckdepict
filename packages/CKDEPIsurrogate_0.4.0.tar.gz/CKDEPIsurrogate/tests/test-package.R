library(CKDEPIsurrogate)

tol <- 1e-12

# Deterministic posterior draws make the expected predictions easy to verify.
fixedDraws <- data.frame(
  alpha = rep(0, 1000),
  beta = rep(1, 1000),
  sigSqClinonSur = rep(0, 1000)
)

benefit <- ProbBen(
  fixedDraws,
  gamma.s = 1,
  SE.gamma = 0,
  k = 0,
  seed = 11
)
stopifnot(all(benefit$thetaDraws == 1))
stopifnot(benefit$probabilityGreaterThanK == 1)
stopifnot(benefit$probabilityLessThanOrEqualToK == 0)
stopifnot(abs(
  benefit$probabilityGreaterThanK +
    benefit$probabilityLessThanOrEqualToK - 1
) < tol)

interval <- PredInt(
  fixedDraws,
  gamma.s = 1,
  SE.gamma = 0,
  level = 0.95,
  seed = 11
)
stopifnot(all(interval$predictionInterval == c(lower = 1, upper = 1)))

# Under a true null effect, a two-sided 5% test has 2.5% probability of crossing
# the rejection boundary in the beneficial direction.
nullPOS <- POS(
  fixedDraws,
  gamma.s = 0,
  SE.gamma = 0,
  SE.theta = 1,
  alpha = 0.05,
  seed = 11
)
stopifnot(abs(nullPOS$probabilityOfSuccess - 0.025) < tol)

# A supplied seed reproduces all predictive draws.
randomDraws <- data.frame(
  alpha = rep(0.1, 100),
  beta = rep(1.2, 100),
  sigSqClinonSur = rep(0.09, 100)
)
run1 <- ProbBen(randomDraws, 0.3, 0.1, k = 0, seed = 25)
run2 <- ProbBen(randomDraws, 0.3, 0.1, k = 0, seed = 25)
stopifnot(identical(run1$thetaDraws, run2$thetaDraws))

# CSV input gives the same result as data-frame input.
fn <- tempfile(fileext = ".csv")
utils::write.csv(randomDraws, fn, row.names = FALSE)
fromCSV <- ProbBen(fn, 0.3, 0.1, k = 0, seed = 25)
stopifnot(identical(run1$thetaDraws, fromCSV$thetaDraws))

# Input errors should be informative and occur before simulation results return.
badDraws <- randomDraws
badDraws$sigSqClinonSur[1] <- -1
stopifnot(inherits(
  try(ProbBen(badDraws, 0.3, 0.1), silent = TRUE),
  "try-error"
))
stopifnot(inherits(
  try(PredInt(randomDraws, 0.3, 0.1, level = 1), silent = TRUE),
  "try-error"
))
stopifnot(inherits(
  try(POS(randomDraws, 0.3, 0.1, SE.theta = 0), silent = TRUE),
  "try-error"
))

# GammaSensitivity uses the same random components across the supplied range.
# With deterministic identity-regression draws, every summary is known exactly.
gammaValues <- c(-1, 0, 1)
gammaRange <- GammaSensitivity(
  fixedDraws,
  gamma.s = gammaValues,
  SE.gamma = 0,
  k = 0,
  level = 0.95,
  SE.theta = 1,
  alpha = 0.05,
  seed = 11
)
stopifnot(identical(gammaRange$results$gamma.s, gammaValues))
stopifnot(all(gammaRange$results$meanClinicalEffect == gammaValues))
stopifnot(all(gammaRange$results$predictionLower == gammaValues))
stopifnot(all(gammaRange$results$predictionUpper == gammaValues))
stopifnot(all(gammaRange$results$probabilityGreaterThanK == c(0, 0, 1)))
stopifnot(all(
  abs(
    gammaRange$results$probabilityOfSuccess -
      stats::pnorm(gammaValues - stats::qnorm(0.975))
  ) < tol
))
stopifnot(inherits(
  try(
    GammaSensitivity(randomDraws, gamma.s = 0.3, SE.gamma = 0.1),
    silent = TRUE
  ),
  "try-error"
))

# Each result can be plotted to a standard base R graphics device.
plotFile <- tempfile(fileext = ".png")
grDevices::png(plotFile, width = 900, height = 600)
plot(run1)
plot(PredInt(randomDraws, 0.3, 0.1, seed = 25))
plot(POS(randomDraws, 0.3, 0.1, SE.theta = 0.2, seed = 25))
grDevices::dev.off()
stopifnot(file.exists(plotFile), file.info(plotFile)$size > 0)

rangePlotFile <- tempfile(fileext = ".png")
grDevices::png(rangePlotFile, width = 900, height = 1100)
plot(gammaRange)
grDevices::dev.off()
stopifnot(file.exists(rangePlotFile), file.info(rangePlotFile)$size > 0)

message("All CKDEPIsurrogate tests passed.")
