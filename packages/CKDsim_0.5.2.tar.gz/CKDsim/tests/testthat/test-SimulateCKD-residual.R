################################################################################
# Copyright 2012 University of Utah Study Design and Biostatistics Center
# This file constitutes portions of ongoing research and collaboration.
# Distributed under the GPL >= 2.0 License.
#
# PROJECT INFO
# Principal Investigator: Tome Greene
# Project Name:  FDA CKDsim simulation
# SDBC Consultant: Jian Ying, Andrew Redd, Jenny Teng, Tom Greene
# File Author: Jian Ying
# Date: 06/26/2026
#
# Description of File:
# Tests residual generation mechanism.
# 
# last updated: 06/26/2026
################################################################################

library(testthat)
library(CKDsim)

context("Residual generation")
simulate_for_residual <- function(...) {
  args <- modifyList(list(
    data.title = "residual test",
    n = 500,
    accrual = 0,
    followup = 2,
    freq = 1,
    add.base.measure = 0,
    early.measure = NULL,
    corr.slope.int = 0,
    slope.model = "nm",
    mean.int = 40,
    sd.int = 0.001,
    int.low = 20,
    int.up = 60,
    p.fast.progressors = 0,
    mean.slope.fast = -2,
    sd.slope.fast = 0.001,
    mean.slope.general = -2,
    sd.slope.general = 0.001,
    mean.log.gamma = -2,
    sd.log.gamma = 0.1,
    log.gamma.shape = 3,
    add.long.term.effect = 0,
    pro.long.term.effect = 1,
    acute.model = "ratio",
    acute.A0 = 0,
    acute.SigA = 0,
    acute.ratio = 0,
    var.residual.a0 = 4,
    var.residual.a1 = 0,
    var.residual.POM = 1,
    t.df.residual = Inf,
    wt.residual = 0,
    auto.residual = 0,
    esrd.model = "threshold",
    esrd.threshold.low = 1,
    esrd.threshold.up = 2,
    lambda.fu = 1e-12,
    lambda.b0 = 0,
    lambda.b1 = 0,
    lambda.b2 = 0,
    lambda.b3 = 0,
    p.missing = 0,
    repeat.measure = FALSE,
    rate.drop.trt = 0
  ), list(...))
  do.call(SimulateCKD, args)
}

find_egfr <- function(...) {
  args <- modifyList(list(
    teGFR1 = c(50, 40, 30),
    Group = 0,
    bvecs = c(BaseIntercept = 50, BaseSlope = -10, LongTermTxSlope = -10),
    auto.residual = 0,
    var.residual.a0 = 1.5,
    var.residual.a1 = 0.05,
    var.residual.POM = 2,
    t.df.residual = 12,
    wt.residual = 0.6
  ), list(...))
  do.call(CKDsim:::FindOnePersonEGFR, args)
}

test_that("residual equals weighted biological and measurement components with variance model", {
  te_gfr <- c(50, 40, 30)
  wt <- 0.6
  df <- 12
  a0 <- 1.5
  a1 <- 0.05
  pom <- 2
  variance <- pmax(0, a0 + a1 * te_gfr^pom)

  set.seed(701)
  expected_z <- rnorm(length(te_gfr))
  expected_w <- rt(length(te_gfr), df = df) * sqrt((df - 2) / df)
  expected_residual <- (wt * expected_z + sqrt(1 - wt^2) * expected_w) * sqrt(variance)

  set.seed(701)
  observed <- find_egfr(
    teGFR1 = te_gfr,
    auto.residual = 0,
    var.residual.a0 = a0,
    var.residual.a1 = a1,
    var.residual.POM = pom,
    t.df.residual = df,
    wt.residual = wt
  )

  expect_equal(observed$ResidualZ, expected_z, tolerance = 1e-12)
  expect_equal(observed$ResidualW, expected_w, tolerance = 1e-12)
  expect_equal(observed$Residual, expected_residual, tolerance = 1e-12)
  expect_equal(observed$ObservedEGFR, pmax(te_gfr + expected_residual, 0), tolerance = 1e-12)
})

test_that("additional baseline measurements share the same biological residual", {
  te_gfr <- c(40, 40, 38)
  wt <- 0.7
  variance <- pmax(0, 2 + 0.1 * te_gfr)

  set.seed(702)
  expected_z_unique <- rnorm(length(unique(te_gfr)))
  expected_w <- rt(length(te_gfr), df = Inf)
  expected_z <- c(expected_z_unique[1], expected_z_unique[1], expected_z_unique[2])
  expected_residual <- (wt * expected_z + sqrt(1 - wt^2) * expected_w) * sqrt(variance)

  set.seed(702)
  observed <- find_egfr(
    teGFR1 = te_gfr,
    auto.residual = 0,
    var.residual.a0 = 2,
    var.residual.a1 = 0.1,
    var.residual.POM = 1,
    t.df.residual = Inf,
    wt.residual = wt
  )

  expect_equal(observed$ResidualZ, expected_z, tolerance = 1e-12)
  expect_equal(observed$ResidualW, expected_w, tolerance = 1e-12)
  expect_equal(observed$Residual, expected_residual, tolerance = 1e-12)
})

test_that("auto.residual equal to one uses one biological residual for all visits", {
  te_gfr <- c(45, 40, 35, 30)
  wt <- 0.8
  variance <- pmax(0, 1 + 0.2 * te_gfr)

  set.seed(703)
  expected_z_unique <- rep(rnorm(1), length(unique(te_gfr)))
  expected_w <- rt(length(te_gfr), df = Inf)
  expected_residual <- (wt * expected_z_unique + sqrt(1 - wt^2) * expected_w) * sqrt(variance)

  set.seed(703)
  observed <- find_egfr(
    teGFR1 = te_gfr,
    auto.residual = 1,
    var.residual.a0 = 1,
    var.residual.a1 = 0.2,
    var.residual.POM = 1,
    t.df.residual = Inf,
    wt.residual = wt
  )

  expect_equal(observed$ResidualZ, expected_z_unique, tolerance = 1e-12)
  expect_equal(observed$Residual, expected_residual, tolerance = 1e-12)
  expect_equal(observed$TrueEGFRBio, te_gfr + wt * expected_z_unique * sqrt(variance), tolerance = 1e-12)
})

test_that("negative residual variances are floored at zero and observed eGFR is not negative", {
  zero_variance <- find_egfr(
    teGFR1 = c(25, 20),
    var.residual.a0 = -10,
    var.residual.a1 = -1,
    var.residual.POM = 1
  )
  expect_equal(zero_variance$Residual, c(0, 0), tolerance = 1e-12)
  expect_equal(zero_variance$ObservedEGFR, c(25, 20), tolerance = 1e-12)

  set.seed(704)
  rnorm(1)
  expected_w <- rt(1, df = Inf)
  expected_observed <- pmax(0.1 + expected_w * sqrt(100), 0)

  set.seed(704)
  floored <- find_egfr(
    teGFR1 = 0.1,
    auto.residual = 0,
    var.residual.a0 = 100,
    var.residual.a1 = 0,
    var.residual.POM = 1,
    t.df.residual = Inf,
    wt.residual = 0
  )
  expect_equal(floored$ObservedEGFR, expected_observed, tolerance = 1e-12)
  expect_true(floored$ObservedEGFR >= 0)
})

test_that("SimulateCKD observed eGFR equals linear true trajectory when residual variance is zero", {
  set.seed(705)
  sim <- SimulateCKD(
    data.title = "residual test",
    n = 4,
    accrual = 0,
    followup = 2,
    freq = 1,
    add.base.measure = 0,
    early.measure = NULL,
    corr.slope.int = 0,
    slope.model = "nm",
    mean.int = 40,
    sd.int = 0.001,
    int.low = 30,
    int.up = 50,
    p.fast.progressors = 0,
    mean.slope.fast = -2,
    sd.slope.fast = 0.001,
    mean.slope.general = -2,
    sd.slope.general = 0.001,
    mean.log.gamma = -2,
    sd.log.gamma = 0.1,
    log.gamma.shape = 3,
    add.long.term.effect = 0,
    pro.long.term.effect = 1,
    acute.model = "ratio",
    acute.A0 = 0,
    acute.SigA = 0,
    acute.ratio = 0,
    var.residual.a0 = 0,
    var.residual.a1 = 0,
    var.residual.POM = 1,
    t.df.residual = Inf,
    wt.residual = 0,
    auto.residual = 0,
    esrd.model = "threshold",
    esrd.threshold.low = 1,
    esrd.threshold.up = 2,
    lambda.fu = 1e-12,
    lambda.b0 = 0,
    lambda.b1 = 0,
    lambda.b2 = 0,
    lambda.b3 = 0,
    p.missing = 0,
    repeat.measure = FALSE,
    rate.drop.trt = 0
  )

  record_with_base <- merge(
    sim$eGFRRecords,
    sim$BaseFile[, c("PersonID", "BaseIntercept", "BaseSlope", "LongTermTxSlope")],
    by = "PersonID"
  )
  expected <- ifelse(
    record_with_base$TxStatus == 1,
    record_with_base$BaseIntercept + record_with_base$Time * record_with_base$LongTermTxSlope,
    record_with_base$BaseIntercept + record_with_base$Time * record_with_base$BaseSlope
  )

  expect_equal(record_with_base$ObservedEGFR, expected, tolerance = 1e-10)
})
test_that("SimulateCKD residuals have the requested marginal variance", {
  set.seed(706)
  sim <- simulate_for_residual(
    n = 4000,
    mean.int = 40,
    sd.int = 0.001,
    int.low = -1000,
    int.up = 1000,
    mean.slope.general = 0,
    sd.slope.general = 0.001,
    var.residual.a0 = 4,
    var.residual.a1 = 0,
    var.residual.POM = 1,
    t.df.residual = Inf,
    wt.residual = 0,
    auto.residual = 0,
    followup = 1,
    freq = 1
  )

  baseline <- merge(
    subset(sim$eGFRRecords, Time == 0 & RepeatMeasure == 0),
    sim$BaseFile[, c("PersonID", "BaseIntercept")],
    by = "PersonID"
  )
  residual <- baseline$ObservedEGFR - baseline$BaseIntercept

  expect_equal(mean(residual), 0, tolerance = 0.05)
  expect_equal(sd(residual), 2, tolerance = 0.05)
})

test_that("SimulateCKD residual SD follows the POM variance model", {
  set.seed(707)
  low <- simulate_for_residual(
    n = 2500,
    mean.int = 20,
    sd.int = 0.001,
    int.low = -1000,
    int.up = 1000,
    var.residual.a0 = 0,
    var.residual.a1 = 0.01,
    var.residual.POM = 2,
    wt.residual = 0,
    mean.slope.general = 0,
    sd.slope.general = 0.001,
    followup = 1,
    freq = 1
  )
  high <- simulate_for_residual(
    n = 2500,
    mean.int = 60,
    sd.int = 0.001,
    int.low = -1000,
    int.up = 1000,
    var.residual.a0 = 0,
    var.residual.a1 = 0.01,
    var.residual.POM = 2,
    wt.residual = 0,
    mean.slope.general = 0,
    sd.slope.general = 0.001,
    followup = 1,
    freq = 1
  )

  baseline_residual <- function(sim) {
    baseline <- merge(
      subset(sim$eGFRRecords, Time == 0 & RepeatMeasure == 0),
      sim$BaseFile[, c("PersonID", "BaseIntercept")],
      by = "PersonID"
    )
    baseline$ObservedEGFR - baseline$BaseIntercept
  }

  sd_ratio <- sd(baseline_residual(high)) / sd(baseline_residual(low))
  expect_equal(sd_ratio, 3, tolerance = 0.12)
})

test_that("SimulateCKD repeat measurements have residual correlation near wt.residual squared", {
  set.seed(708)
  wt <- 0.7
  sim <- simulate_for_residual(
    n = 4000,
    mean.int = 40,
    sd.int = 0.001,
    int.low = -1000,
    int.up = 1000,
    mean.slope.general = 0,
    sd.slope.general = 0.001,
    var.residual.a0 = 9,
    var.residual.a1 = 0,
    var.residual.POM = 1,
    t.df.residual = Inf,
    wt.residual = wt,
    auto.residual = 0,
    repeat.measure = TRUE,
    followup = 1,
    freq = 1
  )

  baseline <- merge(
    subset(sim$eGFRRecords, Time == 0),
    sim$BaseFile[, c("PersonID", "BaseIntercept")],
    by = "PersonID"
  )
  baseline$residual <- baseline$ObservedEGFR - baseline$BaseIntercept
  wide <- reshape(
    baseline[, c("PersonID", "RepeatMeasure", "residual")],
    idvar = "PersonID",
    timevar = "RepeatMeasure",
    direction = "wide"
  )

  expect_equal(cor(wide$residual.0, wide$residual.1), wt^2, tolerance = 0.04)
})

test_that("repeat-measure residual variance uses var.residual.POM", {
  egfr_record <- data.frame(
    PersonID = c(1, 2),
    Group = c(0, 0),
    Time = c(0, 0),
    TxStatus = c(0, 0),
    TrueEGFR = c(20, 60),
    ObservedEGFR = c(20, 60),
    ResidualZ = c(0, 0)
  )

  set.seed(802)
  expected_w <- rt(2, df = Inf)
  expected_repeat <- egfr_record$TrueEGFR + expected_w * sqrt(0.01 * egfr_record$TrueEGFR^2)

  set.seed(802)
  with_repeat <- CKDsim:::IncRepEGFRRecord(
    egfr_record,
    repeat.measure = TRUE,
    var.residual.a0 = 0,
    var.residual.a1 = 0.01,
    var.residual.POM = 2,
    t.df.residual = Inf,
    wt.residual = 0
  )
  repeated <- subset(with_repeat, RepeatMeasure == 1)

  expect_equal(repeated$ObservedEGFR, expected_repeat, tolerance = 1e-12)
})

test_that("invalid acute.model reports a clear error", {
  expect_error(
    CKDsim:::FindOnePersonTeGFR(
      Group = 0,
      bvecs = c(BaseIntercept = 40, BaseSlope = -2, LongTermTxSlope = -1),
      trt = list(c(0, 0), c(0, 1)),
      obs.time = c(0, 1),
      acute.model = "bad",
      acute.A0 = 0,
      acute.SigA = 0,
      acute.ratio = 0
    ),
    "acute.model='bad' is not implimented"
  )
})
