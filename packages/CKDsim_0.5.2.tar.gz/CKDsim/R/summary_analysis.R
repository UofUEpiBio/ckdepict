#' Summarized the analysis and using mean of estimators, standard deviation of 
#'        estimators, and modeled standard deviation to calculate the power.
#' @param AnalysisTable   A \code{list} of analysis results for each simulation that you are going 
#'                        to do the power calculations.
#' @param ValueName       The column name for the statistical value.
#' @param SEName          The column name for stadard deviation.
#' @param Nsim            Simulate \code{N} individuals per group.
#' @param Npower          Target sample size.
#' @param sig.level       Significance level (Type I error probability). Default setting is 0.05.
#' @param SE.select       Either use "SE" or "SEM" to calculate the power results and efficiency. 
#'                        The default setting is "SE".
#' @param ...             Discarded.
#' 
#' @return  A \code{data.frame} with \code{SPEC}, \code{MeanEST}, \code{SE}, 
#'          \code{SEM}, \code{Npower}, \code{sig.level}, \code{SE.select}, 
#'          \code{P_RejectH0_2side}, \code{P_RejectH0_InTrt}, and \code{P_RejectH0_InCtrl}.
#' @export
SummaryAnalysis <- function(AnalysisTable, ValueName, SEName, Nsim, Npower, sig.level = 0.05
                            , SE.select = c("SE"), ...) { 
  
  stopifnot(length(Nsim) == 1)
  n <- nrow(AnalysisTable[[1]])
  
  analysis.table <- do.call(rbind, AnalysisTable)
  analysis.table$temp.spec <- as.character(analysis.table$SPEC)
  analysis.table <- analysis.table[order(analysis.table$temp.spec), ]
  SPEC <- unique(analysis.table[, c("SPEC", "temp.spec")])
  
  SEMcalculation <- function(x) {
    sqrt(sum(x^2)/length(x))
  }
  
  MeanEST <- tapply(analysis.table[, ValueName], analysis.table[, "temp.spec"], mean)
  EST     <- data.frame(temp.spec = rownames(MeanEST), MeanEST)
  SE      <- tapply(analysis.table[, ValueName], analysis.table[, "temp.spec"], sd)
  SE      <- data.frame(temp.spec = rownames(SE), SE)
  SEM     <- tapply(analysis.table[, SEName], analysis.table[, "temp.spec"], SEMcalculation)    
  SEM     <- data.frame(temp.spec = rownames(SEM), SEM)
  EST.SE     <- merge(EST   , SE )
  EST.SE.SEM <- merge(EST.SE, SEM) 
  
  power.combination <- data.frame( Nsim   = Nsim
                                 , Npower = Npower
                                 , sig.level  = sig.level
                                 , SE.select = SE.select)
  
  PowerSE <- mdply(power.combination, RunMultiSpecLevel, EST.SE.SEM, SPEC)
  data.frame(ValueName, SEName, PowerSE)
}

#' Power analysis by different mean estimator and standard deviation.
#' 
#' @param Nsim        Simulate \code{N} individuals per group.
#' @param Npower      Target sample size.
#' @param sig.level   Significance level (Type I error probability).
#' @param EST.SE.SEM  A \code{data.frame} including \code{MeanEST}, \code{SE}
#'                    , \code{SEM}, ....
#' @param SE.select   Either "SE" or "SEM".
#' @param SPEC        The character SPEC and list SPEC
#' @param ...         Discarded
#' @importFrom stringr str_sub
#' @importFrom stringr regex
#' @keywords internal
RunMultiSpecLevel <- function( Nsim
                             , Npower
                             , sig.level
                             , SE.select = c('SE', 'SEM')
                             , EST.SE.SEM
                             , SPEC
                             , ...) {
  one.methodsepc.power <- mdply(EST.SE.SEM, RunOneESTLevel
                               , Nsim      = Nsim
                               , Npower    = Npower
                               , sig.level = sig.level
                               , SE.select = SE.select
                               )
  one.methodsepc.power <- merge(SPEC, one.methodsepc.power, all.x = T)
  one.methodsepc.power[, -which(names(one.methodsepc.power) %in% c("temp.spec"))]
}

#' Power analysis
#' @param temp.spec  The name for the analysis and the the spec setting.
#' @param MeanEST    Mean of the point estimators.
#' @param SE         Standard deviation of the point estimators across simulations.
#' @param SEM        Square root of average squared modeled SE for point estimators 
#'                   across simulation.
#' @param SE.select  Either "SE" or "SEM". The default setting is "SE".
#' @param ...        Discarded.
#' @return  A \code{data.frame} for power calculation
#' @keywords internal
RunOneESTLevel <- function(temp.spec, MeanEST, SE, SEM, Nsim, Npower, sig.level, SE.select, ...) {
  std.mean.SE  <- MeanEST / (SE  * sqrt(Nsim / Npower))
  std.mean.SEM <- MeanEST / (SEM * sqrt(Nsim / Npower))
  half.sig.level  <- sig.level / 2
  
  std.prob <- ifelse(SE.select == "SE", std.mean.SE, std.mean.SEM)

  Power             <- 1 - pnorm(qnorm(1 - half.sig.level) - std.prob ) + 
                           pnorm(qnorm(    half.sig.level) - std.prob )
  
  right.side        <- 1 - pnorm(qnorm(1 - half.sig.level) - std.prob )
  
  left.side         <-     pnorm(qnorm(    half.sig.level) - std.prob )
  
  Power.Trt         <- ifelse(regexpr("Time to Event", temp.spec) > 0, left.side
                              , ifelse(regexpr("Fixed Time", temp.spec) > 0, left.side
                                       , ifelse(regexpr("Slope", temp.spec) > 0, right.side, NA)))
  Power.Ctrl        <- ifelse(regexpr("Time to Event", temp.spec) > 0, right.side
                              , ifelse(regexpr("Fixed Time", temp.spec) > 0, right.side 
                                       , ifelse(regexpr("Slope", temp.spec) > 0, left.side, NA)))
  
  data.frame(Power, Power.Trt, Power.Ctrl)
}
