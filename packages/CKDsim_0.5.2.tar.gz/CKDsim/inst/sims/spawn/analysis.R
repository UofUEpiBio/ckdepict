#! /bin/env Rscript
{###############################################################################
# Copyright 2012 University of Utah Study Design and Biostatistics Center
# This file constitutes portions of ongoing research and collaboration.
# NOT FOR EXTERNAL DISTRIBUTION
#
# PROJECT INFO
# Principal Investigator: Tome Greene
# Project Name:  FDA CKDsim simulation
# SDBC Consultant: Andrew Redd, Jenny Teng, Tom Greene
# File Author: Andrew Redd
# Date: 11/6/2012
#
# Description of Analysis:
# This file is to be used with the run.job 
# 
# Steps for using this file:
# 
# 1. Edit the p.grid object to define the parameters for simulating data.
# 2. Add/Remove the analyses to perform.
# 3. Run with either
#     a. ./analysis.R  (You may need to run chmod 777 analysis.R)
#     b. Rscript analysis.R
# 
# last updated: 11/19/2012
}###############################################################################
suppressPackageStartupMessages({
library(CKDsim)
library(dostats)
library(plyr)
library(magrittr)
options( stringsAsFactors = FALSE 
       # , user   = 'me'       #! Specify who you are if needed.
       # , domain = 'utah.edu' #! Specify the domain if it cannot be inferred
       # , email  = sprintf("%s@utah.edu", Sys.info()['user'])  #! Specify email if needed
                    #^ default is user@domain, so if user and domain are specified correctly email does not need to be.
                    #^ this will be used for where updates are sent.
       # , "HPC::batch_system" = 'slurm' #! specify the batch submission system if needed.
       # , "HPC::account" = "account_to_use" #! the account to charge the usage.
       )

})
{ # Step 1. Define the Simulation Parameters
p.grid <- expand.grid(
    n                  = 500
  , accrual            = c(1, 2)
  , followup           =  4
  , freq               =  0.5
  , add.base.measure   =  0
  , early.measure      =  0.3
  , corr.slope.int     =  0.03       
  , mean.int           = 42.5   
  , sd.int             = 17.5              
  , int.low            = 20   
  , int.up             = 65      
  
  , slope.model        = "glg"          
  , p.fast.progressors =  0.3   
  , mean.slope.fast    = -7
  , sd.slope.fast      =  3        
  , mean.slope.general = -1   
  , sd.slope.general   =  3

  , log.gamma.loc      = c(-2.5)
  , log.gamma.shape    =  3
  , log.gamma.scale    = c(3.5)
  , intglg.b0          =  0
  , intglg.b1          =  0
#~   , add.long.term.effect = 0
#~   , pro.long.term.effect = 1

  , acute.model        = 'ratio'
#~   , acute.effect       = c(-3)
  , acute.A0           =  0
  , acute.SigA         =  1
#~   , acute.ratio        =  0

  , var.residual.a0    =  0 
  , var.residual.a1    =  0.67
  , t.df.residual      = 12
  , wt.residual        =  0.6
  , auto.residual      =  0.5

#~   , long.term.effect   =  0.7

  , esrd.threshold.low =  7 
  , esrd.threshold.up  = 11 

  , lambda.fu          =  0.03
  , lambda.b0          =  0.02
  , lambda.b1          =  0.02
  , lambda.b2          =  0
  , lambda.b3          =  0
  , p.missing          =  0.075
  , repeat.measure     = TRUE
  
#~   , effect.model       = "pro"
  , stringsAsFactors   = FALSE # DO NOT CHANGE
) %>% mutate( data.title        = paste(log.gamma.loc, sep="/") )
}# Step 1. Define the Simulation Parameters
{ # Step 2. Define the Analyses.
    tte.summary <- {wargs(SummaryAnalysis
                          , ValueName = 'Log.HR.Value'
                          , SEName    = 'Log.HR.SE'
                          , Nsim      = 500              #scaler
                          , Npower = c(500)     #parallel
                          , alpha  = c(0.05)             #parallel
                          , se.select = "SE"             #parallel
    )}
    tte.base <- {wargs(TimeToEventAnalysis
                       , tte.death = TRUE                     #scaler
                       , tte.confirmation = c(T,   T,  T,  T,  T,  F,  F,  F,  F,  F)  #parallel
                       , tte.drop.percent = c(57, 50, 40, 30, 20, 57, 50, 40, 30, 20)  #parallel
                       , tte.drop.value = NA                  #parallel
                       , tte.drop.to = NA                     #parallel
    )}
    
    # analysis must have these names.
    analyses = {list(
        tte.part1 = {list(analysis = wargs(tte.base, tte.truncate.time = 6 )
                         , summary = tte.summary
                         )},
        tte.part2 = {list(analysis = wargs(tte.base, tte.truncate.time = 4.5 )
                         , summary = tte.summary
                         )},
        tte.part3 = {list(analysis = wargs(tte.base, tte.truncate.time = 3 )
                         , summary = tte.summary
                         )},
        tte.part4 = {list( analysis = wargs( tte.base
                                           , tte.truncate.time = 6 
                                           , tte.confirmation = c(T)
                                           , tte.drop.percent = c(99)
                                           )
                         , summary = tte.summary
                         )}  
    )}
}# Step 2. Define the Analyses.
HPC_create_sim(p.grid, analyses, N=10, sim.time="01:00:00", tte.summary, tte.base)
