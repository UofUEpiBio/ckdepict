#' Find Slope at each observational points for the treated patient in study
#' @param time             A \code{string} of the time points for the slope.
#' @param initial.slope    The initial nontreated slope for the patient
#' @param alpha.tegfr  The quandratic coefficient for true eGFR.
#' @param pro.t0.lte       \code{pro.t0.lte} and \code{pro.t1.lte} are the 
#'                         hypothesized ratio of the slope with treatment to the slope without 
#'                         treatment for each individual patient with a negative slope. Thus, 
#'                         for example, \code{long.term.effect = 0.7} indicates a 30% 
#'                         reduction in the magnitude of each patient who would have a negative 
#'                         slope without treatment. \code{t0} and \code{t1} mean the different 
#'                         time points.
#' @param pro.coef.lte     The ratio of the slope with treatment to the slope without treatment
#'                         at time \code{t1}.
#' @param add.t0.lte       \code{add.t0.lte} and \code{add.t1.lte} are the hypothesized 
#'                         additive change in
#'                         the slope of each patient, in ml/min/1.73m2/yr. 
#'                         For example, \code{long.term.effect = 1} indicates that each 
#'                         treated patient's slope is shifted by 1 ml/min/1.73m2/yr in the 
#'                         less negative (or possitive) direction. 
#' @param add.coef.lte     The hypothesized additive change in the slope of each patient at 
#'                         time \code{t1}. The default setting is \code{0}.  
#' @keywords internal
FindTrtSlope <- 
function( time
        , initial.slope
        , alpha.tegfr
        , pro.t0.lte
        , pro.coef.lte
        , add.t0.lte
        , add.coef.lte
        ) {
  delta.pro.by.time <- ifelse(pro.coef.lte >= 0 , 
                              max(0, min(pro.t0.lte + pro.coef.lte * time, 1) *
                                (initial.slope + alpha.tegfr * time)),
                              max(0, max(pro.t0.lte + pro.coef.lte * time, 0) * 
                                (initial.slope + alpha.tegfr * time)))
  slope.delta.by.time <- delta.pro.by.time + add.t0.lte + (add.coef.lte * time)
  initial.slope + alpha.tegfr * time + slope.delta.by.time 
}

