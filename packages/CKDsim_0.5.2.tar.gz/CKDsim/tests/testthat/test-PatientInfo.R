library(CKDsim)
library(testthat)
library(plyr)
library(VGAM)
library(MSBVAR)

context("PatientInfo")
test_that("Testing for function PatientInfo",{
  set.seed(123)
  Group = c(rep(0, 100), rep(1, 100))
  all <- mlply(data.frame(Group), PatientInfo
               , trt.ind = list(c(0, 0, 0, 0, 0), c(0, 1, 1, 1, 1))
               , max.obs.time = c(0, 0.5, 1, 1.5, 2)
               , corr.slope.int = 0.03
               , mean.int = 40
               , sd.int = 20
               , int.up = 60
               , int.low = 20
               , slope.model = "glg"
               , log.gamma.loc = -3
               , log.gamma.scale = 1.5                        
               , log.gamma.shape = 1.4
               , add.long.term.effect = 0
               , pro.long.term.effect = 0.7
               , acute.A0 = -2
               , acute.SigA = 0
               , acute.ratio = 1
               , auto.residual = 0.5
               , var.residual.a0 = 5
               , var.residual.a1 = 0.6
               , t.df.residual = 10
               , wt.residual = 0.5)
  base.coef  <- ldply(sapply(all,"[", "Base"))
  tegfr      <- sapply(all,"[", "TrueEGFR")
  egfr       <- sapply(all,"[", "ObservedEGFR")
  # testing for proportional long term effect
  expect_identical(ifelse(base.coef$BaseSlope > 0
                          , base.coef$BaseSlope
                          , base.coef$BaseSlope * 0.7)
                   , base.coef$LongTermTxSlope)
  # testing for "glg" slope model
  random.slope <- rlgamma(100, location = -3, scale = 1.5, shape=1.4)                     
  expect_true(t.test(random.slope, base.coef$BaseSlope)$p.value > 0.05)
  # testing for interception
  egfr.1st.value <- sapply(egfr, "[", 1)
  expect_true(min(egfr.1st.value) >= 20 & max(egfr.1st.value) <= 60)
  expect_true(all(is.finite(base.coef$BaseIntercept)))
  
  all <- mlply(data.frame(Group), PatientInfo
               , trt.ind = list(c(0, 0, 0, 0, 0), c(0, 1, 1, 1, 1))
               , max.obs.time = c(0, 0.5, 1, 1.5, 2)
               , corr.slope.int = 0.03
               , mean.int = 40
               , sd.int = 20
               , int.up = 60
               , int.low = 20
               , slope.model = "nm"
               , p.fast.progressors = 0.3
               , mean.slope.fast = -7
               , sd.slope.fast = 3
               , mean.slope.general = -1
               , sd.slope.general = 3
               , add.long.term.effect = 0.7
               , pro.long.term.effect = 1
               , acute.A0 = -2
               , acute.SigA = 0
               , acute.ratio = 1
               , auto.residual = 0.5
               , var.residual.a0 = 5
               , var.residual.a1 = 0.6
               , t.df.residual = 10
               , wt.residual = 0.5)
  base.coef  <- ldply(sapply(all,"[", "Base"))
  tegfr      <- sapply(all,"[", "TrueEGFR")
  egfr       <- sapply(all,"[", "ObservedEGFR")
  # testing for normal mixture slope 
  random.slope <- c(rnorm(30, mean = -7, sd = 3), rnorm(70, mean = -1, sd = 3))                     
  expect_true(t.test(random.slope, base.coef$BaseSlope)$p.value > 0.05)
  # testing for additive long term effect
  expect_identical(base.coef$LongTermTxSlope, base.coef$BaseSlope + 0.7)
})
