library(CKDsim)
library(testthat)

context("DefineMaxObsTime")
test_that("Testing DefineMaxObsTime",{
  p.maxobstime <- list( accrual = 2
                        , followup = 1
                        , freq = 0.5
                        , add.base.measure = 2 
                        , early.measure = 0.3)
  o.maxobstime <- c(0, 0, 0, 0.3, 0.5, 1, 1.5, 2, 2.5, 3)
  max.obs.time <- do.call(DefineMaxObsTime, p.maxobstime)
  expect_identical(max.obs.time, o.maxobstime)
  expect_equal(max.obs.time[1], 0)
  expect_true(length(max.obs.time) >= 
    ((p.maxobstime$accrual + p.maxobstime$followup) / p.maxobstime$freq))
  expect_that(max.obs.time, is_a("numeric"))
  partial.maxobstime <- seq(0, (p.maxobstime$accrual + p.maxobstime$followup)
                             , by = p.maxobstime$freq)
  expect_equal(length(match(partial.maxobstime, o.maxobstime)), length(partial.maxobstime))
})
