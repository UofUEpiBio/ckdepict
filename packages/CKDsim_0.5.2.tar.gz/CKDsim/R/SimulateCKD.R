#' Generate patients eGFR records and  base file
#' 
#' Simulation of patients' eGFR record (\code{eGFRRecords}) including \code{Group}, treatment  
#' status (\code{TxStatus}), \code{Time}, \code{ObservedEGFR}, and \code{RepeatMeasure = 1 or 0} 
#' (if confirmed measurments applied) and base file (\code{BaseFile}) including \code{Group}, 
#' baseline intercept (\code{BaseIntercept}), slope in the absence of treatment (\code{BaseSlope}),
#' treatment slope in long term effect (\code{LongTermTxSlope}), \code{EnterStudyTime}, 
#' censoring time (\code{AdminCen}), 
#' loss follow-up time (\code{LossFU}), ESRD time (\code{ESRD}), and death time (\code{Death}).
#' 
#' @param data.title           The title for the data. The default is "Data".
#' @param n                    Number of patients in each of the two treatment groups.
#' @param accrual              Accrual period for study (yr).
#' @param followup             Additional follow up period for study and completion of accrual 
#'                             period (yr).
#' @param add.base.measure     Number of additional baseline measurement(s).
#'                             \code{add.base.measure} is set to \code{0} if there is 
#'                             no additional baseline measurement (integer valued).
#' @param early.measure        The time for a single early follow-up measurement which must between 
#'                             0 and the first regularly scheduled follow-up measurement:
#'                             \code{early.measure} is set to \code{NULL} if there is no additonal 
#'                             early measurement.
#' @param freq                 Freqency for regular follow-up eGFR measurements 
#'                             (specify fraction of 1 year. For example, \code{freq = 0.5} 
#'                             indicates measurements every 6 months).
#' @param mean.int             Baseline intercept mean (in ml/min/1.73m2).
#' @param sd.int               Intercept standard deviation (in ml/min/1.73m2).
#' @param int.low              Lower bound for observed baseline eGFR (in ml/min/1.73m2).
#' @param int.up               Upper bound for observed baseline eGFR (in ml/min/1.73m2).
#' @param slope.model          One of three models for the slope distribution: 
#'                             "nm" = Normal mixture : needs p.fase.progressors, mean.slope.fast
#'                             , sd.slope.fast, mean.slope.general, sd.slope.general; 
#'                             "glg" = generalized log gamma : needs log.gamma.loc, log.gamma.scale
#'                             , log.gamma.shape;
#'                             "intglg" = generate intercept to get glg slope: needs intglg.b0
#'                             , intglg.b1, log.gamma.scale, log.gamma.shape.
#' @param corr.slope.int       Correlation between intercept and slope.
#' @param p.fast.progressors   Proportion of fast progressive patients if \code{slope.model = "nm"}
#'                             (between 0 and 1).
#' @param mean.slope.fast      Mean slope (in ml/min/1.73m2/yr) for fast progressors if 
#'                             \code{slope.model = "nm"}.
#' @param sd.slope.fast        Standard deviation (in ml/min/1.73m2/yr) of slope for fast 
#'                             progressors if \code{slope.model = "nm"}.
#' @param mean.slope.general   Mean slope (in ml/min/1.73m2/yr) for general patient population if 
#'                             \code{slope.model = "nm"}.
#' @param sd.slope.general     Slope standard deviation (in ml/min/1.73m2/yr) for general patient 
#'                             population if \code{slope.model = "nm"}.
#' @param mean.log.gamma      The mean (in ml/min/1.73m2/yr) for 
#'                             generalized log gamma distributed slope 
#'                             if \code{slope.model = "glg"}.
#' @param sd.log.gamma        The (positive) real valued standard deviation (in ml/min/1.73m2/yr) 
#'                             for generalized log gamma distributed slope 
#'                             if \code{slope.model = "glg"}.
#' @param int.uniform.lower    Lower bound for uniform intercept model.
#' @param int.uniform.upper    Upper bound for uniform intercept model.
#' @param log.gamma.shape      The (positive) real valued shape parameter for generalized log gamma
#'                             distributed slope.
#' @param intglg.b0            The parameter to generate mean value for slope
#' @param intglg.b1            The parameter to generate mean value for slope
#' @param pro.long.term.effect  \code{pro.long.term.effect} is the 
#'                             hypothesized ratio of the slope with treatment to the slope without 
#'                             treatment for each individual patient with a negative slope. Thus, 
#'                             for example, \code{long.term.effect = 0.7} indicates a 30% 
#'                             reduction in the magnitude of each patient who would have a negative 
#'                             slope without treatment.
#'                             The default value is \code{1}.
#' @param add.long.term.effect \code{add.long.term.effect} is the hypothesized additive change in
#'                             the slope of each patient, in ml/min/1.73m2/yr. 
#'                             For example, \code{long.term.effect = 1} indicates that each 
#'                             treated patient's slope is shifted by 1 ml/min/1.73m2/yr in the 
#'                             less negative (or possitive) direction. 
#'                             The default setting is \code{0}.
#' @param acute.model          Two different models for the acute effect: 
#'                             (a) ratio (needs acute.A0, acute.SigA, acute.ratio)
#'                             (b) log (needs acute.A0, acute.SigA)
#' @param acute.A0             Mean acute effect of treatment on eGFR (in ml/min/1.73m2) 
#'                             when eGFR = 50. The acute 
#'                             effect is assumed to be fully manifest by the time of the first 
#'                             follow-up measurement.
#' @param acute.SigA           Standard deviation of the acute effect when eGFR = 50.
#' @param acute.ratio          Ratio of acute effect when eGFR = 15 vs. acute effect when eGFR = 50.
#'                             The default value is \code{0}.
#' @param var.residual.a0      Coefficient for variance of residuals (see details).
#' @param var.residual.a1      Coefficient for variance of residuals (see details).
#' @param var.residual.POM     Coefficient for variance of residuals (see details).
#' @param t.df.residual        Degrees of freedom assumed for T-distributed residuals. 
#'                             The default setting is \code{Inf}, which corresponds to normally 
#'                             distributed residuals. A lower degrees of freedom represents a 
#'                             higher proportion of outliers.
#' @param wt.residual          Weighted (between 0 and 1) for biological component of residuals.
#' @param auto.residual        Autocorrelation of the biological component of residuals between 
#'                             regularly scheduled visits.
#' @param esrd.model           one of the ESRD models: "threshold", "piecewise.exponential", "Weibull", or "lognormal".
#' @param esrd.threshold.low   Upper bound at which ESRD can be triggered if esrd.model= "Threshold".
#' @param esrd.threshold.up    Lower bound at which ESRD can be triggered if esrd.model= "Threshold".
#' @param lambda.c0            Baseline log hazard for piecewise exponential ESRD model.
#' @param lambda.c1            True eGFR effect for piecewise exponential ESRD model.
#' @param esrd.weibull.shape   Shape parameter if esrd.model= "Weibull"; sigma if esrd.model= "lognormal". 
#' @param esrd.lambda.b0       the mean(esrd.time)=esrd.lambda.b0+esrd.lambda.b1*eGFR.intercept+esrd.lambda.b2*eGFR.slope if esrd.model= "Weibull" or "lognormal".
#' @param esrd.lambda.b1       the mean(esrd.time)=esrd.lambda.b0+esrd.lambda.b1*eGFR.intercept+esrd.lambda.b2*eGFR.slope if esrd.model= "Weibull" or "lognormal".
#' @param esrd.lambda.b2       the mean(esrd.time)=esrd.lambda.b0+esrd.lambda.b1*eGFR.intercept+esrd.lambda.b2*eGFR.slope if esrd.model= "Weibull" or "lognormal".
#' @param lambda.fu            Loss to follow up hazard rate(per year).
#' @param lambda.b0            Death hazard rate = \code{lambda.b0} + \code{lambda.b2} * true eGFR 
#'                             + \code{lambda.b3} * slope (per year) in control group.
#' @param lambda.b1            Death hazard rate = \code{lambda.b1} + \code{lambda.b2} * true eGFR 
#'                             + \code{lambda.b3} * slope (per year) in treatment group.
#' @param lambda.b2            Coefficient for Death hazard rate. The default value is \code{0}.
#' @param lambda.b3            Coefficient for Death hazard rate. The default value is \code{0}.
#' @param p.missing            Probability that an individual follow-up eGFR measurement is 
#'                             missing. The default value is \code{0}.
#' @param repeat.measure       A repeat measurment to confirm eGFR event for
#'                             time-to-event analysis and for fixed time analysis. 
#'                             The default setting is \code{FALSE}.
#' @param rate.drop.trt        Rate of patient dropping treatment per year
#' @param ...                  ignored.        
#'
#' @details
#' \enumerate{
#'    \item Study design {
#'        \itemize{
#'           \item Uniform accrual is assumed over \code{accrual} years.
#'           \item \code{followup} years of additional follow-up are assumed after the end of 
#'           the accrual period. 
#'           \item A fixed measurement schedule is assumed with measurements every \code{freq} 
#'           years. 
#'           \item An integer number of additional baseline eGFR measurement with the same 
#'           marginal distribution as the original baseline eGFR can be specified using 
#'           \code{add.base.measure}. 
#'           \item An optional additional early follow-up measurement can be specified by
#'           \code{early.measure} at a time point prior to the first regularly scheduled 
#'           follow-up visit time stipulated by \code{freq}.
#'           \item Loss to follow-up is assumed to be exponential with rate \code{lambda.fu}.    
#'           \item eGFR measurements are assumed to be independently missing with binomial 
#'           probability \code{p.missing} for each follow-up measurement while patients remain 
#'           in the study. This component of missingness is assumed to be MCAR.
#'        }
#'    }
#'    
#'    \item Initial model for joint distribution of the intercept and slope in the absence of 
#'    treatment
#'        \itemize{
#'           \item Initial marginal distribution of slopes: Two different models for the marginal 
#'           slope distribution are supported: (a) A normal mixture model, and (b) A generalized log   
#'           gamma model, as determined by the parameter \code{slope.model}.
#'               \itemize{
#'                  \item Normal mixture slope model:
#'                          Define two groups of patients, called "general patients" and 
#'                          "fast progressors", with Pr[fast.progressors] = 
#'                          \code{p.fast.progressors}.
#'                          Normally distributed slopes are assumed for the general patients and 
#'                          for the fast progressors. Additional input parameters define the 
#'                          means and standard deviations of the slopes for the two groups:
#'                          \code{mean.int}, \code{sd.int}, \code{mean.slope.general},
#'                          \code{sd.slope.general}, \code{mean.slope.fast}, and 
#'                          \code{sd.slope.fast}.
#'                  \item Generalized log gamma slope model:
#'                          The generalized log gamma model is defined by three parameters:
#'                          \code{log.gamma.loc}, \code{log.gamma.scale}, and 
#'                          \code{log.gamma.shape}. 
#'                          The first two parameters designate the overall mean slope and the 
#'                          slope variance. The shape parameter can be used to induce negative 
#'                          skewness in the slope distribution.
#'               }
#'           
#'           \item Initial marginal distribution for intercept:
#'               \itemize{
#'                  \item The initial intercept distribution is assumed to be normally 
#'                  distributed with mean \code{mean.int} and standard deviation \code{sd.int}.
#'               }
#'           
#'           \item Initial slope and intercept joint distribution:
#'               \itemize{
#'                  \item{i}{If the slope distribution is assumed to be a normal mixture, then  
#'                  each component of the mixture is assumed to have a bivariate normal distribution 
#'                  with the intercept with correlation \code{corr.slope.int}.}
#'                  
#'                  \item{ii}{If the slope distribution is assumed to be generalized log gamma,  
#'                  then a normal random variable obtained as a 1-1 transformation of the 
#'                  generalized log gamma distributed slopes is assumed to follow a bivaraite normal 
#'                  distribution with the intercept, also with correlation \code{corr.slope.int}.}
#'               }
#'       }
#'    
#'    \item Model for Long term effect on the slope 
#'        \itemize{
#'            \item{Either a proportional effect model or an additive model can be stipulated,  
#'            using the parameter \code{effect.model}.}
#'            \item{Proportional effect model:
#'                \itemize{
#'                    \item {If the slope without treatment (\eqn{\beta_untreated}) is greater 
#'                    and equal
#'                    to \eqn{0}, then \eqn{\beta_treated = \beta_untreated}.}
#'                    \item {If \eqn{\beta_untreated} is negative, then 
#'                    \eqn{\beta_treated = \beta_untreated * } \code{long.term.effect}}.}}
#'            \item{Additive effect model:
#'                \itemize{
#'                    \item {The slope with treatment (\eqn{\beta_treated}) equals to 
#'                    \eqn{\beta_untreated +} \code{long.term.effect}.
#'                    }
#'                }}
#'        }
#'    
#'    \item Model for acute effect of treatment on eGFR 
#'          {An additive shift, controlled by the input parameter \code{acute.A0} and 
#'          \code{acute.SigA}, are 
#'          applied to all follow-up eGFR measurements (we assume full acute effect 
#'          occures by the time of the first follow-up measurement) in the treatment 
#'          group. The value of \code{acute.A0} and \code{acute.SigA} are expressed in ml/ml/1.73m2. 
#'          The
#'          "true eGFR" excluding random biological deviations from linearity and random 
#'          measurement error for the ith patient a t time \eqn{t} is computed as:
#'          \deqn{True eGFR_it = \alpha_i + t * \beta_(i, untreated)} 
#'          for patients in the control group.
#'          \deqn{True eGFR_it = \alpha_i + t * \beta_(i, treated)}
#'          for patients in the treatment group.}
#'    
#'    \item Model for residuals
#'          \itemize{
#'          \item The residual \eqn{\epsilon_it} for patient \eqn{i} at each time point \eqn{t}
#'                is defined as an appropriate transformation of 
#'                \code{wt.residual}\eqn{* Z_it + sqrt(1-}\code{wt.residual}\eqn{^2) * W_it},
#'                where \code{wt.residual} must be between 0 and 1, \eqn{Z_it} is a standard 
#'                normal component of the residual that represents short term biological 
#'                variation from the assumed underlying linear trajectory, such that the 
#'                \eqn{Z_it} follow an AR(1) process with autocorrelation \code{auto.residual},
#'                and the \eqn{W_it} are i.i.d standard normal random measurement errors.
#'          \item The variance of residuals \eqn{\epsilon_it} for patient i at each time 
#'                point as VAR(\eqn{\epsilon_it}) = \code{var.residual.a0} + 
#'                \code{var.residual.a1} * \eqn{True eGFR_it}^\code{var.residual.POM}.
#'          \item To account for heavy tailed residuals, the normally distributed autocorrelated 
#'                residuals constructed as above are transformed to follow a t-distribution with 
#'                \code{df.residual} degrees of freedom, mean \eqn{0}, variance 
#'                VAR(\eqn{\epsilon_it}) determined by previous bullet. 
#'          }
#'    
#'    \item Computation of measured eGFR values
#'          \itemize{
#'          \item The measured eGFR for patient \eqn{i} at time \eqn{t} is 
#'                \eqn{True eGFR_it + \epsilon_it}.
#'          \item Additional repeat eGFR measurements are generated if requested at baseline 
#'                (based on \code{add.base.measure}), and to confirm eGFR events 
#'                (see time to event analysis descriptions) in follow-up. The residuals at these
#'                visits are generated to follow the same marginal distributions and the same 
#'                joint distributions with residuals at other time points as the originally
#'                generated residuals at these visits. The normality distributed transformations
#'                of residuals at the same visit (either baseline, or at follow-up visit for
#'                confirmation) are assumed to have a correlation of \code{wt.residual}^2 with 
#'                each other. Note that to full separate the data generation and analysis steps, 
#'                repeat eGFR measurements are generated at each follow-up time point, so that 
#'                repeat measurement are available to be used (or not used) as designated by 
#'                any time to event or fixed time analysis strategy. 
#'          }
#'    
#'    \item Restriction of baseline eGFR range
#'          \itemize{
#'          \item {The baseline eGFR distribution by eliminating patients whose baseline eGFR 
#'          falls outside of the interval [\code{int.low}, \code{int.up}]. This exclusion is 
#'          applied based on the single original baseline eGFR measurement.}
#'          {\strong{Notes:} (1) The truncation steip in 2 can be thought of as imposing an 
#'          entry criteria based on a restricted baseline eGFR range.}
#'          }
#'    
#'    \item Model for initiation of ESRD and mortality rate
#'          \itemize{
#'          \item Model for initiation of ESRD based on eGFR level
#'                \itemize{
#'                \item Each patient is assumed to have a latent ESRD initiation eGFR value
#'                      defined as ESRD threshold. ESRD threshold is generated as a uniform
#'                      distribution on [\code{esrd.threshold.low}, \code{esrd.threshold.up}].
#'                \item ESRD is initiated by the patient at the first follow-up time t such that 
#'                        True eGFR is less than and equal to ESRD threshold. 
#'                }
#'           \item The mortality rate at time \eqn{t} is
#'                \itemize{
#'                \item Death hazard rate = \code{lambda.b0} + \code{lambda.b2} * true eGFR + 
#'                      \code{lambda.b3} * slope (per year) for death in untreated group.
#'                \item Death hazard rate = \code{lambda.b1} + \code{lambda.b2} * true eGFR + 
#'                      \code{lambda.b3} * slope (per year) for death in treatment group.
#'                }
#'          }
#' }
#'
#' @return
#' A \code{\link{list}} with \code{\link{data.frame}} \code{eGFRRecords}, 
#' and \code{BaseFile}.
#' 
#' @importFrom stringr str_sub
#' @importFrom stringr regex
#' @export
SimulateCKD <- 
  function( data.title = "Data"
            , n
            , accrual
            , followup
            , freq
            , add.base.measure = 0
            , early.measure = NULL
            , corr.slope.int
            , slope.model= c( "nm: Normal Mixture"
                              , "glg: Generalized Log Gamma"
                              , "normalglg: Normal distributed intercept and GLG distributed Slope whose mean depends on the intercept"
                              , "uniformglg: Uniforml distributed intercept and GLG distributed Slope whose mean depends on the intercept"
            )   
            , mean.int
            , sd.int
            , int.low
            , int.up
            , p.fast.progressors = 0
            , mean.slope.fast = 0
            , sd.slope.fast = 1
            , mean.slope.general = 0
            , sd.slope.general = 1
            , int.uniform.lower = int.low #new parameter added on 4/3/2025 by Jian
            , int.uniform.upper = int.up #new parameter added on 4/3/2025 by Jian
            , sd.log.gamma = NULL #new parameter added on 4/3/2025 by Jian
            # , log.gamma.loc #not needed anymore
            # , log.gamma.scale #not needed anymore
            , log.gamma.shape
            , intglg.b0 = 0  #Jian repurposed this parameter. May need to give a new name. Now it is the intercept of the linear function that relates the intercept to the mean slope instead of location parameter, it is parameterized such that 
            # it is the mean of the slope when the intercept is equal to its mean (mean.int or (int.uniform.lower+int.uniform.upper)/2 depends on its distribution)
            , intglg.b1 = 0   ##Jian repurposed this parameter. May need to give a new name. Now it is the slope of the linear function that relates the intercept to the mean slope instead of location parameter
            , add.long.term.effect  
            , pro.long.term.effect  
            , acute.model
            , acute.A0
            , acute.SigA
            , acute.ratio = 0
            , var.residual.a0
            , var.residual.a1
            , var.residual.POM=1
            , t.df.residual = Inf
            , wt.residual
            , auto.residual
            , esrd.model= c( "threshold"
                             ,"piecewise.exponential"
                             , "Weibull"
                             ,"lognormal"
                            )

            , esrd.threshold.low
            , esrd.threshold.up
            , lambda.c0 = 0
            , lambda.c1 = 0
            , esrd.weibull.shape = 1
            , mean.log.gamma = NULL
            , esrd.lambda.b0 = 0
            , esrd.lambda.b1 = 0
            , esrd.lambda.b2 = 0
            , lambda.fu
            , lambda.b0
            , lambda.b1
            , lambda.b2 = 0
            , lambda.b3 = 0
            , p.missing = 0
            , repeat.measure = FALSE
            , rate.drop.trt = 0
            , ...) {
    #=========================
    # Parameter Checking
    #=========================
    dots <- list(...)
    if (is.null(mean.log.gamma) && !is.null(dots$log.gamma.loc)) {
      mean.log.gamma <- dots$log.gamma.loc + dots$log.gamma.scale * digamma(log.gamma.shape)
    }
    if (is.null(sd.log.gamma) && !is.null(dots$log.gamma.scale)) {
      sd.log.gamma <- abs(dots$log.gamma.scale) * sqrt(trigamma(log.gamma.shape))
    }
    if (is.null(mean.log.gamma)) mean.log.gamma <- 0
    if (is.null(sd.log.gamma)) sd.log.gamma <- 1
    esrd.model <- match.arg(esrd.model)
    
    # data.title
    if(inherits(data.title, 'factor')) data.title <- as.character(data.title)
    stopifnot( length(data.title) == 1
               , inherits(data.title, 'character'))
    # add.base.measure
    stopifnot(length(add.base.measure) == 1
              , all.equal(add.base.measure, as.integer(add.base.measure))
              , add.base.measure >= 0)
    
    #early.measure
    if (!is.null(early.measure)) {
      if (any(early.measure >= (freq)) || any(early.measure <= 0)) {
        stop("Argument for `early.measure` has invalid value. 
             The `early.measure` should be set to be between ",
             0, " and ", freq, ".")
      }
      stopifnot(length(early.measure) == 1)
    }
    
    #int.low & int.up
    stopifnot (int.low < int.up)
    
    #slope.model
    slope.model <- str_extract(match.arg(slope.model), regex('^.*?(?=:)') )
    #slope.model  <- str_extract(match.arg(slope.model), regex('^.*?(?=:)'))
    
    # if slope model is normal mixture
    if (slope.model == "nm") {
      stopifnot( length(p.fast.progressors) == 1 
                 , length(mean.slope.fast)    == 1 
                 , length(sd.slope.fast)      == 1
                 , length(mean.slope.general) == 1
                 , length(sd.slope.general)   == 1
                 , length(corr.slope.int) == 1
                 , 0 <= p.fast.progressors && p.fast.progressors <= 1)
    }
    
    # if slope model is log gamma distributed
    if (slope.model == "glg") {
      stopifnot( length(mean.log.gamma  ) == 1 
                 , length(sd.log.gamma) == 1
                 , length(log.gamma.shape) == 1
                 , length(corr.slope.int ) == 1  
                 , sd.log.gamma >= 0 
      )
    }
    
    # if slope model is using intercept to generate log gamma distributed slope
    if (slope.model == "normalglg") {
      stopifnot( length(intglg.b0      ) == 1 
                 , length(intglg.b1      ) == 1
                 , length(sd.log.gamma) == 1
                 , length(log.gamma.shape) == 1
                 , sd.log.gamma >= 0 
      )
    }
    
    # if slope model uses uniform intercept to generate log gamma distributed slope
    if (slope.model == "uniformglg") {
      stopifnot( length(intglg.b0      ) == 1 
                 , length(intglg.b1      ) == 1
                 , length(sd.log.gamma) == 1
                 , length(log.gamma.shape) == 1
                 , length(int.uniform.lower) == 1
                 , length(int.uniform.upper) == 1
                 , sd.log.gamma >= 0
                 , int.uniform.lower < int.uniform.upper
      )
    }
    
    # if the proportional long-term effect type
    stopifnot( 0 <= pro.long.term.effect && pro.long.term.effect <= 1
               , length(add.long.term.effect) == 1
               , length(pro.long.term.effect) == 1
    )
    
    #acute.model
    acute.model <- as.character(acute.model)
    stopifnot(length(acute.model) == 1)
    
    # acute.ratio
    stopifnot(acute.ratio >= 0 & acute.ratio <= 1)
    
    #var.residual.a0, var.residual.a1, auto.residual, t.df.residual, wt.residual
    #lambda.b0, lambda.b1, lambda.b2, lambda.b3
    stopifnot(length(var.residual.a0) == 1
              , length(var.residual.a1) == 1
              , length(auto.residual) == 1
              , length(t.df.residual) == 1
              , length(wt.residual) == 1
              , (wt.residual >= 0 & wt.residual <= 1)
              , length(lambda.b0) == 1
              , length(lambda.b1) == 1
              , length(lambda.b2) == 1
              , length(lambda.b3) == 1
              , length(repeat.measure) == 1)
    
    # esrd.threshold.low and esrd.threshold.up
    if(esrd.threshold.low >= esrd.threshold.up) {
      stop("invalid trigger for ESRD:esrd.threshold greater or equal 
           to esrd.threshold.up")
    }
    
    #repeat.measure
    stopifnot(is.logical(repeat.measure))
    
    #==========================
    # Start programe simulation
    #==========================
    
    {  # Define the maximun set for possible eGFR measured time points in entire study
      max.obs.time <- DefineMaxObsTime(accrual, followup, freq, add.base.measure, early.measure)
      # Number of maximun observation points
      n.max.obs <- length(max.obs.time)
    }
    
    {  # Generate person.id and group.id for patients
      person.id <- seq(1, 2 * n)
      group.id <- c(rep(0, n), rep(1, n))
    }
    
    {  # Define treatment indication vectors for control and experimental groups
      cont.trt.ind <- rep(0, n.max.obs)
      expt.trt.ind <- c(rep(0, add.base.measure + 1)
                        , rep(1, n.max.obs - (add.base.measure + 1)))
      
      # on 2/27/2018 Jian added code below to allow patients to drop treatment 
      if (rate.drop.trt==0){ time.drop.trt <- rep(100000000,length(group.id) )}else{
        time.drop.trt <- rexp(length(group.id),rate.drop.trt)
      }
      # end jian's addition
      
      trt.ind      <- list(ConTxStatus = cont.trt.ind, ExpTxStatus = expt.trt.ind)
    }
    
    { all <- mlply(data.frame(Group = group.id,time.drop.trt=time.drop.trt) #jian added time.drop.trt
                   , PatientInfo
                   , trt.ind
                   , max.obs.time
                   , corr.slope.int
                   , slope.model 
                   , mean.int
                   , sd.int  
                   , int.low
                   , int.up
                   , p.fast.progressors  
                   , mean.slope.fast
                   , sd.slope.fast
                   , mean.slope.general
                   , sd.slope.general
                   , int.uniform.lower #new parameter added on 4/3/2025 by Jian
                   , int.uniform.upper #new parameter added on 4/3/2025 by Jian
                   , sd.log.gamma #new parameter added on 4/3/2025 by Jian
                   , mean.log.gamma 
                   # , log.gamma.loc #not needed anymore
                   # , log.gamma.scale #not needed anymore
                   , log.gamma.shape
                   , intglg.b0  #Jian repurposed this parameter. May need to give a new name. Now it is the intercept of the linear function that relates the intercept to the mean slope instead of location parameter, it is parameterized such that 
                   # it is the mean of the slope when the intercept is equal to its mean (mean.int or (int.uniform.lower+int.uniform.upper)/2 depends on its distribution)
                   , intglg.b1  ##Jian repurposed this parameter. May need to give a new name. Now it is the slope of the linear function that relates the intercept to the mean slope instead of location parameter
                   , add.long.term.effect 
                   , pro.long.term.effect 
                   , acute.model
                   , acute.A0
                   , acute.SigA
                   , acute.ratio
                   , auto.residual
                   , var.residual.a0
                   , var.residual.a1
                   , var.residual.POM
                   , t.df.residual = t.df.residual
                   , wt.residual
                     )
    }
    
    base.coef  <- ldply(sapply(all,"[", "Base"))
    tegfr      <- sapply(all,"[", "TrueEGFR")
    egfr       <- sapply(all,"[", "ObservedEGFR")
    residual.z <- sapply(all,"[", "ResidualZ")
    tegfr.bio  <- sapply(all,"[", "TrueEGFRBio")
    
    base.simple.info <- data.frame(PersonID = person.id
                                   , Group = group.id
                                   , base.coef[, c("BaseIntercept", "BaseSlope", "LongTermTxSlope")]
                                   ,time.drop.trt=time.drop.trt  #jian added
    )
    
    {  # Patients base file : Combined control and experimental groups' 
      # patients base file and time frame file  
      base <- data.frame(base.simple.info
                         ,  DefineTimeFrame(base.simple.info
                                            , trt.ind
                                            , max.obs.time
                                            , teGFR = tegfr
                                            , eGFR  = egfr
                                            , accrual
                                            , followup
                                            , esrd.model
                                            , esrd.threshold.low
                                            , esrd.threshold.up
                                            , lambda.c0
                                            , lambda.c1
                                            , esrd.weibull.shape
                                            , mean.log.gamma
                                            , esrd.lambda.b0
                                            , esrd.lambda.b1
                                            , esrd.lambda.b2
                                            , lambda.fu
                                            , lambda.b0
                                            , lambda.b1
                                            , lambda.b2
                                            , lambda.b3
                         )
      )
      rownames(base) <- NULL
    }
    
    {  # Construct patient's logitudinal observed eGFR records without extra measurement
      egfr.record.temp <- CreateLongitudinalData(  base
                                                   , teGFR = tegfr
                                                   , eGFR = egfr
                                                   , residual.z
                                                   , trt.ind = trt.ind
                                                   , max.obs.time
                                                   , p.missing)
    }
    
    {  # Find egfr.record including repeating measurement for time-to-event analysis 
      # and fixed time analysis if repeat.measure is TRUE.
      egfr.record   <- IncRepEGFRRecord(  egfr.record.temp
                                          , repeat.measure
                                          , var.residual.a0
                                          , var.residual.a1
                                          , var.residual.POM
                                          , t.df.residual
                                          , wt.residual)
      rownames(egfr.record) <- NULL
    }
    #jian added below code to change the TxStatus to be 0 when subjects drop treatment
    time.drop.trt1=base[,c("PersonID","time.drop.trt")]
    egfr.record=merge(egfr.record,time.drop.trt1)
    egfr.record$TxStatus= egfr.record$TxStatus*(egfr.record$Time<egfr.record$time.drop.trt)
    if (repeat.measure==TRUE){
      egfr.record=egfr.record[,c("PersonID","Group", "Time" , "TxStatus","ObservedEGFR",  "RepeatMeasure")]
    }else{
      egfr.record=egfr.record[,c("PersonID","Group", "Time" , "TxStatus","ObservedEGFR")]
      egfr.record$RepeatMeasure=0
    }
    
    #end jian's addition
    
    
    #jian drop time.drop.trt from output to make the output consistent with the earlier version
    drop="time.drop.trt"
    base=base[,!names(base)%in%drop]
    list(eGFRRecords = egfr.record, BaseFile = base, DataTitle= data.title)
    }


CKDsim.version=function(){
  print("On 10/17/2017, Jian modified the code so that 1)esrd.trigger is added to the output. 2)ESRD is only triggered by true eGFR to be lower than esrd.trigger. 3)eGFR data is not censored by ESRD events. ")
}