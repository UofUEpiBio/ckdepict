#' Probability above and below a clinical benefit threshold
#'
#' Uses posterior meta-regression draws and an estimated surrogate treatment
#' effect to predict the true clinical treatment effect in a new trial.
#'
#' @param fn.csv CSV file path or data frame containing columns `alpha`, `beta`,
#'   and `sigSqClinonSur`.
#' @param gamma.s Estimated treatment effect on the surrogate endpoint.
#' @param SE.gamma Standard error of `gamma.s`.
#' @param k Clinical benefit threshold on the clinical-effect scale.
#' @param seed Optional nonnegative integer used to reproduce the simulation.
#'
#' @return A list containing the predictive draws and both probability sides.
#' @export
ProbBen <- function(fn.csv, gamma.s, SE.gamma, k = 0, seed = NULL) {
  .checkNumber(k, "k")

  prediction <- .simulateTheta(
    fn.csv = fn.csv,
    gamma.s = gamma.s,
    SE.gamma = SE.gamma,
    seed = seed
  )

  theta <- prediction$thetaDraws
  probabilityGreater <- mean(theta > k)

  # Report the complementary side explicitly for readers who prefer to see
  # both probabilities. Under this continuous model Pr(theta = k) is zero.
  probabilityLessOrEqual <- 1 - probabilityGreater

  result <- list(
    thetaDraws = theta,
    probabilityGreaterThanK = probabilityGreater,
    probabilityLessThanOrEqualToK = probabilityLessOrEqual,
    k = k,
    gamma.s = gamma.s,
    SE.gamma = SE.gamma,
    nDraws = prediction$nDraws
  )

  class(result) <- c("CKDEPIProbBen", "CKDEPIprediction")
  result
}
