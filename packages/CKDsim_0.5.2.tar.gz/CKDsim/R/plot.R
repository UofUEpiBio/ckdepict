###############################################################################
# Copyright 2012 University of Utah Study Design and Biostatistics Center
# This file constitutes portions of ongoing research and collaboration.
# 
# PROJECT INFO
# Principal Investigator: Tome Greene
# Project Name:  FDA CKDsim simulation
# SDBC Consultant: Andrew Redd, Jenny Teng, Tom Greene
# File Author: Andrew Redd
# Date: 11/6/2012
# 
# last updated: 11/19/2012
################################################################################


# vars.tte <- .('log(HR)' = MeanEST, SE, 'Z-Ratio'=zratio, Power) #Jian commentated this out on 4/18/2025 due to error message. Not sure about the effect. 

#' Helper functions for plotting
#' 
#' @param data The data from a simulation see \link{HPC_create_sim}
#' @param mean the value to test against
#' @param est the estimated value
#' @param se the standard error
#' 
#' @export
zratio <- function(data, mean=0, est=data$MeanEST, se=data$SE){est/se}

#' Compute the required sample size from the simulation
#' 
#' @param data The data from a simulation see \link{HPC_create_sim}
#' @param power the power desired
#' @param fpr the false positive rate, aka alpha
#' @param npg number per group used to simulate
#' @param .zratio the zratio of the parameter
#' 
#' @export
required_sample_size <- function(data, power=.8, fpr=0.05
                                , npg=data$Nsim
                                , .zratio=zratio(data)){
    za2 <- qnorm(1-fpr/2)
    zb  <- qnorm(power)
    zab2<- (za2 + zb)^2
    ceiling(2*(zab2 * npg)/(.zratio)^2)
}
if(F){
    head(zratio(summary.all))
    head(required_sample_size(summary.all))
}
#' Plot a performance plot for a simulation
#' 
#' @param data the subsetted data from the simulation
#' @param vars the variable to use.  For convenience 
#'        variables can be renamed with the .() syntax.  See the Example.
#'        
#' @return a ggplot object representing the plots for performance.
#' @seealso ggplot
#'        
#' @examples
#' \dontrun{
#' summary.all <- mutate(summary.all
#'                      , zratio=MeanEST/SE
#'                      , N.req = required_sample_size(data=summary.all))
#' PerformancePlot(summary.all, .('log(HR)' = MeanEST, SE, 'Z-Ratio'=zratio, Power))
#' PerformancePlot(summary.all, .('log(HR)' = MeanEST, SE, 'Z-Ratio'=zratio, N.req))
#' PerformancePlot(summary.all, .(N.req)) + scale_y_log10()
#' }
#' @importFrom reshape2 melt
#' @export 
PerformancePlot <- 
local({
types <- {c( "solid"
            , "13"
            , "44"
            , "88"
)}
lt_pal <- function(n){
    types[seq_len(n)]
}
sz_map <- function(l){
    ifelse(l == 'FALSE', 1, 2)
}
function(data, vars){
    stopifnot(requireNamespace('ggplot2'))
    fmap = structure(names(vars), names=as.character(vars))
    md <- melt(data, measure.vars=as.character(vars))
    md$variable <- factor(fmap[as.character(md$variable)], levels=fmap)
    pdata <- subset(md, md$parameters.DropPct<99)
    clinical <- subset(md, md$parameters.DropPct>=99)
    
    slt <- ggplot2::discrete_scale("linetype", "linetype_d", lt_pal, name='Confirmed')
    ssz <- ggplot2::continuous_scale("size"  , "size_c"    , sz_map, guide='none')    
    
    ggplot2::ggplot(data=pdata, ggplot2::aes_string(x='parameters.DropPct', y='value'
               , color    = 'factor(parameters.Truc.Time)'
               , linetype = 'parameters.Confirmed'
               , size = '(parameters.Confirmed != "FALSE")'
                           )) + 
         ggplot2::geom_line() + 
         ggplot2::scale_x_reverse() +
         ggplot2::facet_wrap(~variable, scales='free') +
         ggplot2::geom_rug(ggplot2::aes(NULL), data=clinical, sides = 'lr') + 
         ggplot2::geom_hline( ggplot2::aes_string(yintercept = 'value'
                   , color    = 'factor(parameters.Truc.Time)'
                   , linetype = '"Clinical"'
                   , size     = '"TRUE"'), data=clinical) + 
         ggplot2::scale_colour_discrete(name='Truncation Time') + 
         slt + 
         ggplot2::scale_size_discrete(range=c(.5,1.25), guide='none') + 
         ggplot2::labs(x=NULL, y=NULL, linetype='Confirmed') + 
         ggplot2::theme(legend.position='bottom')
}
})


