#' Generate baseline intercept, baseline slope, long-tearm treatment slope 
#' for an individual
#' 
#' @inheritParams PatientInfoMayOutbound
#'  
#' @return         
#' A numeric string with \code{BaseIntercept}, \code{BaseSlope},
#' \code{LongTermTxSlope}.
#'
#' @importFrom VGAM qlgamma
#' @importFrom VGAM rlgamma
#' @keywords internal
GenerateBaseCoef <- 
function(slope.model
        ,corr.slope.int
        , mean.int
        , sd.int
        , p.fast.progressors  
        , mean.slope.fast
        , sd.slope.fast
        , mean.slope.general
        , sd.slope.general
        , int.uniform.lower #new parameter added on 4/3/2025 by Jian
        , int.uniform.upper #new parameter added on 4/3/2025 by Jian
        , mean.log.gamma #new parameter added on 4/3/2025 by Jian
        , sd.log.gamma #new parameter added on 4/3/2025 by Jian
        # , log.gamma.loc #not needed anymore
        # , log.gamma.scale #not needed anymore
        , log.gamma.shape
        , intglg.b0  #Jian repurposed this parameter. May need to give a new name. Now it is the intercept of the linear function that relates the intercept to the mean slope instead of location parameter, it is parameterized such that 
        # it is the mean of the slope when the intercept is equal to its mean (mean.int or (int.uniform.lower+int.uniform.upper)/2 depends on its distribution)
        , intglg.b1 ##Jian repurposed this parameter. May need to give a new name. Now it is the slope of the linear function that relates the intercept to the mean slope instead of location parameter
        , add.long.term.effect 
        , pro.long.term.effect 
        , ...) {
  if (slope.model == "nm") {
    is.pf                 <- runif(1) < p.fast.progressors
    var.int               <- sd.int * sd.int
    var.slope.fast        <- sd.slope.fast * sd.slope.fast
    var.slope.general     <- sd.slope.general * sd.slope.general
    cov.slope.int.fast    <- corr.slope.int * sd.slope.fast * sd.int
    cov.slope.int.general <- corr.slope.int * sd.slope.general * sd.int
    
    bvecs1 <- GenerateSlopeInt( 
                  mean.int      = mean.int
                , var.int       = var.int
                , mean.slope    = ifelse(is.pf, mean.slope.fast   , mean.slope.general)
                , var.slope     = ifelse(is.pf, var.slope.fast    , var.slope.general )
                , cov.slope.int = ifelse(is.pf, cov.slope.int.fast, cov.slope.int.general))
  } else 
  if (slope.model == "glg") {
    # log.gamma.scale <- sqrt((log.gamma.scale ^ 2) / trigamma(log.gamma.shape))
    # log.gamma.loc   <- log.gamma.loc - (log.gamma.scale * digamma(log.gamma.shape))
    
    bvecs1 <- GenerateSlopeInt(
                   mean.int      = mean.int
                 , var.int       = sd.int * sd.int
                 , mean.slope    = 0
                 , var.slope     = 1 #this is right. don't change it to sd.log.gamma^2 -Jian
                 , cov.slope.int = corr.slope.int * sd.int * 1) # this is right.  -Jian
    
    # bvecs1[[2]] <- qlgamma(pnorm(bvecs1[[2]])
    #                              , location = log.gamma.loc
    #                              , scale    = log.gamma.scale
    #                              , shape    = log.gamma.shape) #jian rewrote this part as below
    m=mean.log.gamma 
    v=sd.log.gamma^2
    k=log.gamma.shape
    #then we have
    b=sqrt(v/trigamma(k))
    a=m-b*digamma(k)
    #convert the slope from normal distribution to log gamma distribution
    bvecs1[[2]] <- qlgamma(pnorm(bvecs1[[2]])
                                 , location = a
                                 , scale    = b
                                 , shape    = k)
    
  } else 
  if (slope.model == "normalglg") {
      intercept <- rnorm(1, mean=mean.int, sd=sd.int)#intercept follows normal distribution
      m=mean.log.gamma  <- intglg.b0 + intglg.b1 * ( intercept -  mean.int )#conditional mean slope is a linear function of intercept
      v=sd.log.gamma^2
      k=log.gamma.shape
      #then we have
      b=sqrt(v/trigamma(k))
      a=m-b*digamma(k)
      #generate a slope from the log gamma distribution
      slope     <- rlgamma(1, location = a
                           , scale    = b
                           , shape    = k)
      
      
      bvecs1 <- c(intercept, slope)
      
      
      bvecs1 <- c(intercept, slope)
  }  else 
    if (slope.model == "uniformglg") {
      intercept <- runif(1, int.uniform.lower, int.uniform.upper) #intercept follows uniform distribution
      m=mean.log.gamma  <- intglg.b0 + intglg.b1 * ( intercept -  (int.uniform.lower+int.uniform.upper)/2 )#conditional mean slope is a linear function of intercept
      v=sd.log.gamma^2
      k=log.gamma.shape
      #then we have
      b=sqrt(v/trigamma(k))
      a=m-b*digamma(k)
      #generate a slope from the log gamma distribution
      slope     <- rlgamma(1, location = a
                           , scale    = b
                           , shape    = k)
      
      
      bvecs1 <- c(intercept, slope)
    } else
  stop(sprintf("slope.model='%s' is not implimented.", slope.model))
  
  trted.slope <- ifelse(  bvecs1[[2]] >= 0
                       ,  bvecs1[[2]] + add.long.term.effect
                       , (bvecs1[[2]] * pro.long.term.effect) + add.long.term.effect)

  c( BaseIntercept = bvecs1[[1]]
   , BaseSlope = bvecs1[[2]]
   , LongTermTxSlope = trted.slope
   )
}
