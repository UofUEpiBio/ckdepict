library(testthat)
library(CKDsim)

context("SimulateCKD design implementation")

base_coef <- function(...) {
  args <- modifyList(list(
    slope.model = "nm",
    corr.slope.int = 0,
    mean.int = 40,
    sd.int = 1e-6,
    p.fast.progressors = 0,
    mean.slope.fast = -8,
    sd.slope.fast = 1,
    mean.slope.general = -3,
    sd.slope.general = 1e-6,
    int.uniform.lower = 20,
    int.uniform.upper = 60,
    mean.log.gamma = -3,
    sd.log.gamma = 1,
    log.gamma.shape = 3,
    intglg.b0 = -3,
    intglg.b1 = -0.1,
    add.long.term.effect = 0.5,
    pro.long.term.effect = 0.7
  ), list(...))
  do.call(CKDsim:::GenerateBaseCoef, args)
}

test_that("slope model applies the documented long-term treatment slope", {
  set.seed(10)
  neg <- base_coef(
    slope.model = "nm",
    mean.slope.general = -3,
    sd.slope.general = 0
  )
  expect_equal(unname(neg["BaseSlope"]), 
               -3, 
               tolerance = 1e-6)
  expect_equal(
    unname(neg["LongTermTxSlope"]),
    unname(neg["BaseSlope"] * 0.7 + 0.5),
    tolerance = 1e-12
  )

})

test_that("slope models generate intercepts and slopes from the requested designs", {
  set.seed(20)
  nm <- replicate(
    400,
    base_coef(
      slope.model = "nm",
      p.fast.progressors = 1,
      mean.slope.fast = -8,
      sd.slope.fast = 0.2,
      sd.int = 0.2
    )
  )
  expect_equal(mean(nm["BaseSlope", ]), -8, tolerance = 0.08)

  set.seed(21)
  glg <- replicate(
    10000,
    base_coef(
      slope.model = "glg",
      mean.log.gamma = -2,
      sd.log.gamma = 0.7,
      log.gamma.shape = 3
    )
  )
  expect_equal(mean(glg["BaseSlope", ]), -2, tolerance = 0.02)
  expect_equal(sd(glg["BaseSlope", ]), 0.7, tolerance = 0.02)

  set.seed(22)
  uniform_glg <- replicate(
    10000,
    base_coef(
      slope.model = "uniformglg",
      int.uniform.lower = 25,
      int.uniform.upper = 55
    )
  )
  expect_true(all(uniform_glg["BaseIntercept", ] >= 25))
  expect_true(all(uniform_glg["BaseIntercept", ] <= 55))
  expect_equal( mean(uniform_glg["BaseSlope", ]), 
               -3, 
               tolerance = 1e-2)
})

test_that("residual model uses documented variance, weighting, t scaling, and floor at zero", {
  te_gfr <- c(50, 40, 30)
  wt <- 0.6
  df <- 12
  a0 <- 1.5
  a1 <- 0.05
  pom <- 2
  variance <- a0 + a1 * te_gfr^pom

  set.seed(30)
  z <- rnorm(length(te_gfr))
  w <- rt(length(te_gfr), df = df) * sqrt((df - 2) / df)
  expected_residual <- (wt * z + sqrt(1 - wt^2) * w) * sqrt(variance)

  set.seed(30)
  observed <- CKDsim:::FindOnePersonEGFR(
    teGFR1 = te_gfr,
    Group = 0,
    bvecs = c(BaseIntercept = 50, BaseSlope = -10, LongTermTxSlope = -10),
    auto.residual = 0,
    var.residual.a0 = a0,
    var.residual.a1 = a1,
    var.residual.POM = pom,
    t.df.residual = df,
    wt.residual = wt
  )

  expect_equal(observed$ResidualZ, z, tolerance = 1e-12)
  expect_equal(observed$Residual, expected_residual, tolerance = 1e-12)
  expect_equal(observed$ObservedEGFR, pmax(te_gfr + expected_residual, 0), tolerance = 1e-12)
  expect_true(all(observed$ObservedEGFR >= 0))
})

test_that("threshold ESRD is triggered by true eGFR crossing, not observed eGFR", {
  max_obs_time <- c(0, 1, 2, 3)
  true_egfr <- c(40, 35, 25, 15)
  observed_egfr <- c(40, 5, 5, 5)
  trigger <- 20

  esrd_time <- CKDsim:::FindESRDTime(
    teGFR1 = true_egfr,
    eGFR1 = observed_egfr,
    esrd.trigger = trigger,
    max.obs.time = max_obs_time
  )

  expect_equal(esrd_time, 2.5, tolerance = 1e-12)
})

test_that("SimulateCKD base file exposes ESRD triggers and does not censor eGFR records at ESRD", {
  set.seed(40)
  sim <- SimulateCKD(
    data.title = "design test",
    n = 30,
    accrual = 0,
    followup = 5,
    freq = 1,
    add.base.measure = 0,
    early.measure = NULL,
    corr.slope.int = 0,
    slope.model = "nm",
    mean.int = 25,
    sd.int = 0.01,
    int.low = 20,
    int.up = 30,
    p.fast.progressors = 0,
    mean.slope.fast = -6,
    sd.slope.fast = 0.01,
    mean.slope.general = -6,
    sd.slope.general = 0.01,
    log.gamma.shape = 3,
    add.long.term.effect = 0,
    pro.long.term.effect = 1,
    acute.model = "ratio",
    acute.A0 = 0,
    acute.SigA = 0,
    acute.ratio = 0,
    var.residual.a0 = 0,
    var.residual.a1 = 0,
    var.residual.POM = 1,
    t.df.residual = Inf,
    wt.residual = 0,
    auto.residual = 0,
    esrd.model = "threshold",
    esrd.threshold.low = 18,
    esrd.threshold.up = 18.1,
    lambda.fu = 1e-12,
    lambda.b0 = 0,
    lambda.b1 = 0,
    lambda.b2 = 0,
    lambda.b3 = 0,
    p.missing = 0,
    repeat.measure = FALSE
  )

  expect_true("esrd.trigger" %in% names(sim$BaseFile))
  expect_true(all(sim$BaseFile$esrd.trigger >= 18 & sim$BaseFile$esrd.trigger <= 18.1))

  has_post_esrd_record <- vapply(
    sim$BaseFile$PersonID[!is.na(sim$BaseFile$ESRD)],
    function(id) {
      person_esrd <- sim$BaseFile$ESRD[sim$BaseFile$PersonID == id]
      any(sim$eGFRRecords$PersonID == id & sim$eGFRRecords$Time > person_esrd)
    },
    logical(1)
  )
  expect_true(any(has_post_esrd_record))
})
