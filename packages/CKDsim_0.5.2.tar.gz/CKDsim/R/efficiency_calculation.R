#' Calculate the efficiency between different method
#' @param data     The summary data
#' @param select   The selection for standard error for target group
#' @param Ref.Mean The mean value for reference group
#' @param Ref.SE   The standard error for reference group
#' @param ...      Discarded
#' @return A data frame with \code{SPEC}, \code{MeanEST}, \code{SE}, \code{SEM}
#'         , and \code{Efficiency}.
#' @export
FindEfficiency <- function(data,  select="SE", Ref.Mean, Ref.SE, ...){
  stopifnot(select %in% c("SE", "SEM"))

  combination <- data.frame(select, Ref.Mean, Ref.SE)
  out <- mdply(combination, RunMultiLevel, data)
}  

#' Calculate the efficiency between different method
#' @param data     The summary data
#' @param select   The selection for standard error for target group
#' @param Ref.Mean The mean value for reference group
#' @param Ref.SE   The standard error for reference group
#' @param ...      Discarded
#' @return A data frame with \code{SPEC}, \code{MeanEST}, \code{SE}, \code{SEM}
#'         , and \code{Efficiency}.
#' @keywords internal
RunMultiLevel <- function(select, Ref.Mean, Ref.SE, data, ...){
  efficiency <- if(select =="SE") {
                   ((Ref.SE * data$MeanEST)/(Ref.Mean * data$SE))^2
                } else {
                   ((Ref.SE * data$MeanEST)/(Ref.Mean * data$SEM))^2
                }
  out <- data.frame(data[, c("SPEC", "MeanEST", "SE", "SEM")], Efficiency = efficiency)
  unique(out)
}
