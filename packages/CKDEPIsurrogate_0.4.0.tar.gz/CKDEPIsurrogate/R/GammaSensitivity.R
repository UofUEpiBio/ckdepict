#' Explore predictions across surrogate treatment effects
#'
#' Calculates probability of benefit, a prediction interval, and optionally
#' probability of success over a user-supplied range of surrogate treatment
#' effects. The standard error of the surrogate estimate is held constant.
#'
#' Common random draws are used at every value of `gamma.s`, so changes along
#' the curves reflect changes in the surrogate effect rather than unrelated
#' Monte Carlo noise.
#'
#' @param fn.csv CSV file path or data frame containing columns `alpha`, `beta`,
#'   and `sigSqClinonSur`.
#' @param gamma.s Numeric vector of surrogate treatment-effect values to
#'   evaluate. At least two distinct values are required.
#' @param SE.gamma Standard error applied to every value of `gamma.s`.
#' @param k Clinical benefit threshold on the clinical-effect scale.
#' @param level Probability covered by the two-sided prediction interval.
#' @param SE.theta Optional projected standard error of the clinical-effect
#'   estimate in an independent future phase 3 trial. If supplied, probability
#'   of success is calculated at every value of `gamma.s`.
#' @param alpha Two-sided type I error level used when `SE.theta` is supplied.
#' @param seed Optional nonnegative integer used to reproduce the simulation.
#'
#' @return An object with a `results` data frame containing one row per value of
#'   `gamma.s` and the inputs used in the calculation.
#' @export
GammaSensitivity <- function(
    fn.csv,
    gamma.s,
    SE.gamma,
    k = 0,
    level = 0.95,
    SE.theta = NULL,
    alpha = 0.05,
    seed = NULL) {
  if (!is.numeric(gamma.s) || length(gamma.s) < 2L ||
      any(!is.finite(gamma.s))) {
    stop(
      "gamma.s must contain at least two finite numeric values",
      call. = FALSE
    )
  }

  gamma.s <- sort(unique(gamma.s))
  if (length(gamma.s) < 2L) {
    stop("gamma.s must contain at least two distinct values", call. = FALSE)
  }

  .checkNumber(SE.gamma, "SE.gamma", lower = 0)
  .checkNumber(k, "k")
  .checkProbability(level, "level")
  .checkProbability(alpha, "alpha")

  if (!is.null(SE.theta)) {
    .checkNumber(SE.theta, "SE.theta")
    if (SE.theta <= 0) {
      stop("SE.theta must be greater than 0", call. = FALSE)
    }
  }

  .setSeed(seed)
  myMCMC <- .readMCMCDraws(fn.csv)
  M <- nrow(myMCMC)

  # Use the same sampling-error and residual draws for every gamma value. This
  # common-random-number approach makes the sensitivity curves much smoother
  # and easier to compare than rerunning an unrelated simulation at each point.
  delta <- stats::rnorm(M, mean = 0, sd = SE.gamma)
  omega <- sqrt(myMCMC$sigSqClinonSur) * stats::rnorm(M)
  thetaWithoutGamma <- myMCMC$alpha + myMCMC$beta * delta + omega

  tailProbability <- (1 - level) / 2
  criticalValue <- stats::qnorm(1 - alpha / 2)

  calculateOne <- function(myGamma) {
    theta <- thetaWithoutGamma + myMCMC$beta * myGamma
    myInterval <- stats::quantile(
      theta,
      probs = c(tailProbability, 1 - tailProbability),
      names = FALSE,
      type = 7
    )

    myResult <- c(
      meanClinicalEffect = mean(theta),
      probabilityGreaterThanK = mean(theta > k),
      probabilityLessThanOrEqualToK = mean(theta <= k),
      predictionLower = myInterval[1],
      predictionUpper = myInterval[2]
    )

    if (!is.null(SE.theta)) {
      myResult <- c(
        myResult,
        probabilityOfSuccess = mean(
          stats::pnorm(theta / SE.theta - criticalValue)
        )
      )
    }

    myResult
  }

  summaries <- t(vapply(
    gamma.s,
    calculateOne,
    numeric(if (is.null(SE.theta)) 5L else 6L)
  ))

  results <- data.frame(
    gamma.s = gamma.s,
    summaries,
    row.names = NULL,
    check.names = FALSE
  )

  result <- list(
    results = results,
    gamma.s = gamma.s,
    SE.gamma = SE.gamma,
    k = k,
    level = level,
    SE.theta = SE.theta,
    alpha = alpha,
    nDraws = M
  )

  class(result) <- "CKDEPIGammaSensitivity"
  result
}

#' @export
print.CKDEPIGammaSensitivity <- function(x, ...) {
  print(x$results, ...)
  invisible(x)
}
