#' Generate Bivariate Normal distribution (slope, intercept) which meet the boundary for intercept
#' 
#' @param mean.slope        mean for slope
#' @param mean.int          mean for intercept
#' @param var.slope         variance for slope
#' @param var.int           variance for intercept
#' @param cov.slope.int     covariance for slope and intercept
#'
#' @return
#' A \code{string} with \code{BaseIntercept} and \code{BaseSlope} for one patient.
#' @importFrom MASS mvrnorm
#' @keywords internal
GenerateSlopeInt <- 
function(mean.int, var.int, mean.slope, var.slope, cov.slope.int) {
    vmat = matrix(c(var.int, cov.slope.int, cov.slope.int, var.slope), 2, 2)
    int.slope <- mvrnorm(1, c(mean.int, mean.slope), Sigma = vmat)
    int.slope
}
