#' Create patients longitudinal data
#'
#' @param base            A \code{data.frame} for patients' (by rows) information
#'                        with columns \code{PatientID}, \code{Group}, 
#'                        \code{AdminCen}, \code{LossFU}, \code{ESRD}, and 
#'                        \code{Death}, ...
#'                        treated slope, group, intercept information.
#' @param teGFR           A teGFR list for patients (by objects). 
#' @param eGFR            A eGFR list for patients (by objects).
#' @param residual.z      A residual list for Z for patients (by objects).
#' @param trt.ind         A list with logical for two groups if treated.
#' @param max.obs.time    A maximun set for possible eGFR measured time points
#'                        in entire study.
#' @param p.missing       Missing probability for follow-up measurement. 
#'                        The default value is 0.
#' 
#' @details
#' \enumerate{
#'    \item{
#'    Assume eGFR values are missing with binomial probability p.missing for each  
#'    follow-up measuremtn while the patient remains in the study.
#'    }
#'    \item{
#'    Assuming this haphazard missingness is independent between patients and within
#'    patients at different times.
#'    }
#' }
#'
#' @return 
#' A \code{\link{data.frame}} with columns \code{PersonID}, \code{GroupID},
#'  \code{Time}, \code{TxStatus}, \code{TrueEGFR}, \code{ObservedEGFR}, 
#'  \code{ResidualZ}.A record per row.
#' 
#' @keywords internal
CreateLongitudinalData <- function(base, teGFR, eGFR, residual.z
                                   , trt.ind, max.obs.time, p.missing = 0) {
  stopifnot(inherits(base, 'data.frame')
            , inherits(teGFR, 'list')
            , inherits(eGFR, 'list')
            , inherits(trt.ind, 'list')
            , inherits(residual.z, 'list')
            , inherits(max.obs.time, 'numeric')
            , nrow(base) == length(teGFR)
            , all(dim(teGFR) == dim(eGFR))
            , all(dim(teGFR) == dim(residual.z)))
  
  stopifnot(c("PersonID", "Group", "AdminCen", "LossFU", "ESRD", "Death") 
            %in% colnames(base))
  
  #min.time  <- pmin(base$AdminCen, base$LossFU, base$ESRD, base$Death, na.rm = T)  ##on 10/17/2017, Jian made this change so that eGFR measurement is not censored by ESRD events, but is still cencored by death etc.
  min.time  <- pmin(base$AdminCen, base$LossFU,  base$Death, na.rm = T)
  
  obs.time  <- llply(min.time, FindKeptObsTime
                    , p.missing=p.missing, max.obs.time=max.obs.time)
  person.id <- llply(base$PersonID, function(x) rep(x, length(max.obs.time)))
  group     <- llply(base$Group, function(x) rep(x, length(max.obs.time)))
  tx.status <- llply(base$Group, function(x) if(x == 0) trt.ind[[1]] else trt.ind[[2]])
  stopifnot(all(dim(teGFR) == dim(obs.time))
            , all(dim(teGFR) == dim(person.id))
            , all(dim(teGFR) == dim(group))
            , all(dim(teGFR) == dim(tx.status)))                
  all.long.data <- data.frame(  PersonID     = unlist(person.id)
                              , Group        = unlist(group)
                              , Time         = unlist(obs.time)
                              , TxStatus     = unlist(tx.status)
                              , TrueEGFR     = unlist(teGFR)
                              , ObservedEGFR = unlist(eGFR)
                              , ResidualZ    = unlist(residual.z))
  na.omit(all.long.data)
}

#' Finds the non-missing observational time points for each individual
#' 
#' @param min            The minimun time between \code{AdminCen}, \code{LossFU},
#'                       \code{ESRD} and \code{Death} for an individual.
#' @param p.missing       Missing probability for follow-up measurement.
#' @param max.obs.time   A maximun set of observational time points for an individual.
#' 
#' @return The times for non-missing data for an individual.
#' @keywords internal
FindKeptObsTime <- function(min, p.missing, max.obs.time) {
  is.missing    <- runif(length(max.obs.time)) <= p.missing
  obs.time      <- ifelse(max.obs.time > min, NA
                         , ifelse(max.obs.time != 0 & is.missing == 1
                                  , NA, max.obs.time))
}
