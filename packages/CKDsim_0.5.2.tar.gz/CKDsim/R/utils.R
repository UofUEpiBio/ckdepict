{###############################################################################
# utils.R 
# Andrew Redd
# 9/21/2012
# 
# DESCRIPTION
# ===========
# Utilities for checking values and printing values.
# 
# LICENSE
# ========
# lint is free software: you can redistribute it and/or modify it under the
# terms of the GNU General Public License as published by the Free Software 
# Foundation, either version 3 of the License, or (at your option) any later 
# version.
# 
# dostats is distributed in the hope that it will be useful, but WITHOUT ANY 
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License along with 
# this program. If not, see http://www.gnu.org/licenses/.
# 
}###############################################################################

BaseFile.cnames <- c("PersonID", "Group", "AdminCen", "LossFU", "ESRD", "Death") 
#' Check if an object is a valid BaseFile
#' 
#' @param BaseFile object to check.
#' 
#' @keywords internal
isValidBaseFile <- function(BaseFile){
    if( is.data.frame(BaseFile)
    && BaseFile.cnames %in% colnames(BaseFile)) return(TRUE)    
    FALSE
}

BaselineEGFR <- function(eGFRRecords){
    if ("RepeatMeasure" %in% names(eGFRRecords)) {
        keep0data <- eGFRRecords[eGFRRecords$RepeatMeasure != 1 & eGFRRecords$Time == 0, ]
    } else {
        keep0data <- eGFRRecords[eGFRRecords$Time == 0, ]
    }

    avg0data  <- tapply(keep0data$ObservedEGFR, keep0data$PersonID, mean)
    data.frame(PersonID = row.names(avg0data), BaselineEGFR = avg0data)
}


.edf <- structure(list(), row.names='empty', class='data.frame')

