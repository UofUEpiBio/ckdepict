
TTEParams <- function(IncDeath, TruncateTime, Confirmed, DropPct, DropValue, DropTo, ...) {
    structure(list( method = "Time to Event"
                  , parameters = list( Death      = IncDeath
                                     , Truc.Time  = TruncateTime
                                     , Confirmed  = Confirmed
                                     , DropPct    = DropPct
                                     , DropValue  = DropValue
                                     , DropTo     = DropTo
                                     ))
              , class = c("ckd_analysis_method.tte", "ckd_analysis_method"))
}

FTParams <- function(IncDeath, FixedTime, Confirmed
                     , DropPct, DropValue, DropTo, ...) {
    structure(list( method = "Fixed Time"
                  , parameters = list(Death      = IncDeath
                                     , Time      = FixedTime
                                     , Confirmed = Confirmed
                                     , DropPct   = DropPct
                                     , DropValue = DropValue
                                     , DropTo    = DropTo
                                     ))
              , class = c("ckd_analysis_method.ft", "ckd_analysis_method"))
}

MixSParams <- function(Trunc.Time, Total.Time, Knot.Point, Inc.Group, ... ){
    structure(list(method = "Mixed Slope"
              , parameters = list(  TruncT.ime = Trunc.Time
                                  , Total.Time = Total.Time
                                  , KnotPoint  = Knot.Point
                                  , IncGroup   = Inc.Group )
        )    
    , class = c("ckd_analysis_method.mixed_slope", "ckd_analysis_method"))
}

UnwgtParams <- function(Trunc.Time, Total.Time, Knot.Point, Min.FU.Time)
{
    structure(list(method = "Unweighted of Mean Slope"
                   , Parameters = list(  TruncT.ime  = Trunc.Time
                                       , Total.Time  = Total.Time
                                       , KnotPoint   = Knot.Point
                                       , Min.FU.Time = Min.FU.Time)
    )
    , class = c("ckd_analysis_method.unweighted_slope", "ckd_analysis_method"))
}


.formatParamsL <- function(p){
    names <- names(p)
    ina <- sapply(p, is.na)
    paste(names[!ina], p[!ina], sep='=', collapse=', ')
}
.formatParams <- function(...){
    p <- list(...)
    names <- as.character(substitute(c(...)))[-1]
    ina <- sapply(p, is.na)
    paste(names[!ina], p[!ina], sep='=', collapse=', ')
}

#' @export
format.ckd_analysis_method <- function(x, ...) {
    if(  is.null(names(x)) 
      && inherits(x[[1]], 'ckd_analysis_method')) {
        return(sapply(x, format.ckd_analysis_method))
    }
    if(is.null(x$parameters))
        x$method
    else
        sprintf("%s(%s)", x$method
                        , .formatParamsL(x$parameters))
}

#' @export
print.ckd_analysis_method <- function(x, ...) {
    cat(format(x), "\n")
    invisible(x)
}

AnalysisMethod <- function(...) {
    structure(list(...), class=c('ckd_analysis_method'))
}

#' @export
as.data.frame.ckd_analysis_method <- function(x, ...){
    structure(list(AnalysisMethod(x)), class='data.frame', row.names='1')
}


fixSpecClass <- function(z, name='SPEC'){
    stopifnot(is.list(z) && name %in% names(z))
    attr(z[[name]], 'class') <- 'ckd_analysis_method'
    z
}

if(F){
    a <- tte.analysis[[1]][1, ]
    a <- ft.analysis[[1]][1,]
    (x <- splat(TTEParams)(a, Death=T))
    str(as.data.frame(x))
    AnalysisMethod(x)

    e <- f <- data.frame(SPEC=x, b=1)
    str(z <- rbind.fill(e,f))
    z <- fixSpecClass(z)
    z
    
    
    
    
    
}


