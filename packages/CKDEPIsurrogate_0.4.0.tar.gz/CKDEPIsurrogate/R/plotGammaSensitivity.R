#' Plot predictions across surrogate treatment effects
#'
#' @param x Result returned by [GammaSensitivity()].
#' @param main Optional character vector of panel titles.
#' @param xlab Horizontal-axis label shared by all panels.
#' @param ... Additional graphical arguments passed to the individual base R
#'   plots. Do not supply `main`, `xlab`, or `ylab` through `...`.
#'
#' @return The input object, invisibly.
#' @export
plot.CKDEPIGammaSensitivity <- function(
    x,
    main = NULL,
    xlab = "Estimated surrogate treatment effect (gamma.s)",
    ...) {
  myResults <- x$results
  hasPOS <- "probabilityOfSuccess" %in% names(myResults)
  nPanels <- if (hasPOS) 3L else 2L

  defaultMain <- c(
    "Probability of clinical benefit",
    "Predicted true clinical effect",
    "Probability of phase 3 success"
  )[seq_len(nPanels)]
  if (is.null(main)) {
    main <- defaultMain
  } else {
    main <- rep_len(main, nPanels)
  }

  myColors <- .plotColors()
  oldPar <- graphics::par(no.readonly = TRUE)
  on.exit(graphics::par(oldPar), add = TRUE)
  graphics::par(mfrow = c(nPanels, 1L), mar = c(4.1, 4.3, 2.4, 1.1))

  graphics::plot(
    myResults$gamma.s,
    myResults$probabilityGreaterThanK,
    type = "l",
    ylim = c(0, 1),
    lwd = 2,
    col = "#0072B2",
    main = main[1],
    xlab = xlab,
    ylab = "Probability",
    ...
  )
  graphics::lines(
    myResults$gamma.s,
    myResults$probabilityLessThanOrEqualToK,
    lwd = 2,
    col = "#D55E00",
    lty = 2
  )
  graphics::abline(h = 0.5, col = "#777777", lty = 3)
  graphics::legend(
    "topleft",
    legend = c("Pr(theta > k)", "Pr(theta <= k)"),
    col = c("#0072B2", "#D55E00"),
    lty = c(1, 2),
    lwd = 2,
    bty = "n"
  )

  yRange <- range(
    myResults$predictionLower,
    myResults$predictionUpper,
    x$k
  )
  graphics::plot(
    myResults$gamma.s,
    myResults$meanClinicalEffect,
    type = "n",
    ylim = yRange,
    main = main[2],
    xlab = xlab,
    ylab = "True clinical effect",
    ...
  )
  graphics::polygon(
    c(myResults$gamma.s, rev(myResults$gamma.s)),
    c(myResults$predictionLower, rev(myResults$predictionUpper)),
    col = myColors$interval,
    border = NA
  )
  graphics::lines(
    myResults$gamma.s,
    myResults$meanClinicalEffect,
    col = "#0072B2",
    lwd = 2
  )
  graphics::abline(h = x$k, col = myColors$line, lty = 2)
  graphics::legend(
    "topleft",
    legend = c(
      "Mean predicted effect",
      paste0(formatC(100 * x$level, format = "fg"), "% prediction interval"),
      "Clinical threshold k"
    ),
    col = c("#0072B2", NA, myColors$line),
    lty = c(1, NA, 2),
    lwd = c(2, NA, 1),
    fill = c(NA, myColors$interval, NA),
    border = NA,
    bty = "n"
  )

  if (hasPOS) {
    graphics::plot(
      myResults$gamma.s,
      myResults$probabilityOfSuccess,
      type = "l",
      ylim = c(0, 1),
      lwd = 2,
      col = "#0072B2",
      main = main[3],
      xlab = xlab,
      ylab = "Probability of success",
      ...
    )
    graphics::abline(h = 0.5, col = "#777777", lty = 3)
  }

  invisible(x)
}
