# Internal checks and data-reading functions.
#
# These functions are intentionally short and use base R so that the package is
# easy to review and does not require rstan, cmdstanr, or another R package.

.checkNumber <- function(x, name, lower = -Inf, upper = Inf) {
  if (!is.numeric(x) || length(x) != 1L || !is.finite(x)) {
    stop(name, " must be one finite numeric value", call. = FALSE)
  }

  if (x < lower || x > upper) {
    stop(
      name, " must be between ", lower, " and ", upper,
      call. = FALSE
    )
  }

  invisible(TRUE)
}

.checkProbability <- function(x, name) {
  .checkNumber(x, name)

  if (x <= 0 || x >= 1) {
    stop(name, " must be greater than 0 and less than 1", call. = FALSE)
  }

  invisible(TRUE)
}

.readMCMCDraws <- function(fn.csv) {
  # A data frame is accepted as a convenience for testing and interactive use.
  if (is.data.frame(fn.csv)) {
    myDraws <- fn.csv
  } else {
    if (!is.character(fn.csv) || length(fn.csv) != 1L || is.na(fn.csv)) {
      stop("fn.csv must be a CSV file path or a data frame", call. = FALSE)
    }
    if (!file.exists(fn.csv)) {
      stop("The MCMC file does not exist: ", fn.csv, call. = FALSE)
    }

    myDraws <- utils::read.csv(
      fn.csv,
      header = TRUE,
      check.names = FALSE,
      stringsAsFactors = FALSE
    )
  }

  requiredNames <- c("alpha", "beta", "sigSqClinonSur")
  missingNames <- setdiff(requiredNames, names(myDraws))

  if (length(missingNames) > 0L) {
    stop(
      "The MCMC file is missing: ",
      paste(missingNames, collapse = ", "),
      call. = FALSE
    )
  }
  if (nrow(myDraws) < 1L) {
    stop("The MCMC file must contain at least one posterior draw", call. = FALSE)
  }

  for (myName in requiredNames) {
    if (!is.numeric(myDraws[[myName]]) ||
        any(!is.finite(myDraws[[myName]]))) {
      stop(
        "Column '", myName, "' must contain only finite numeric values",
        call. = FALSE
      )
    }
  }
  if (any(myDraws$sigSqClinonSur < 0)) {
    stop("sigSqClinonSur cannot contain negative values", call. = FALSE)
  }

  myDraws[, requiredNames, drop = FALSE]
}

.setSeed <- function(seed) {
  if (is.null(seed)) {
    return(invisible(TRUE))
  }

  .checkNumber(seed, "seed")
  if (seed %% 1 != 0 || seed < 0) {
    stop("seed must be NULL or a nonnegative integer", call. = FALSE)
  }

  set.seed(seed)
  invisible(TRUE)
}

