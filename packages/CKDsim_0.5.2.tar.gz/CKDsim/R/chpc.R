{##############################################################################
# chpc.R
#
# Copyright 2012 University of Utah Study Design and Biostatistics Center
# This file constitutes portions of ongoing research and collaboration.
# NOT FOR EXTERNAL DISTRIBUTION
#
# PROJECT INFO
# Principal Investigator: Tome Greene
# Project Name:  FDA CKDsim simulation
# SDBC Consultant: Andrew Redd, Jenny Teng, Tom Greene
# File Author: Andrew Redd
# Date: 11/6/2012
#
# Description
# This houses files for use with a High Performacen Cluster Setup
# The functions will Automatically Spawn Jobs using Moab resource managers.
#
#
# last updated: 11/19/2012
}###############################################################################
as_args <- function(...){
    x <- list(...)
    n <- names(x)
    paste(n, x, sep='=', collapse=', ')
}




get_domain <- function(){
    getOption("domain", {
        d <- system("domainname", intern=TRUE)
        if(d!='(none)')d else NULL
    })
}
get_user <- function(){
    getOption("user", Sys.info()['user'])
}
get_email <- function(){
    getOption("email", {
        d <- get_domain()
        if(!is.null(d)) sprintf("%s@%s", get_user(), get_domain())
        else NULL
    })
}


#' Infer the HPC batch sumbission system in use.
#' @export
infer_batch_system <- function(){
    if(Sys.which("sbatch") != '') return("slurm") else
    if(Sys.which("qsub"  ) != '') return("PBS") else
    if(Sys.which("msub"  ) != '') return("Moab") else
    stop("Could not infer HPC batch submission system.")
}

get_processor_speed <- function(){
    as.numeric(system('lscpu | grep -P "CPU MHz:" | grep -Po "[\\d.]+$"', intern=T))
}

#' @importFrom parallel detectCores
HPC_parallel_setup <- function(){
    requireNamespace('doParallel', quietly=TRUE)
    doParallel::registerDoParallel(detectCores())
    options(harvestr.parallel=T)
}
HPC_get_N <- function(){
    if(exists('N', envir=globalenv())) {
        return(get('N', envir=globalenv()))
    } else if(length(commandArgs(T))>=2) {
        as.numeric(commandArgs(T)[2])
    } else if(interactive()) {
        warning("Detected running in interactive mode.  N assumed to be 3.")
        return(3)
    } else {
        message("Using default value of N=1000.")
        1000
    }
}
HPC_get_setnum <- function(){
    if(exists('setnum', envir=globalenv())) return(get('setnum', envir=globalenv()))
    if(length(commandArgs(TRUE)) >= 1){
        message("Reading set number from command line")
        as.numeric(commandArgs(TRUE)[1])
    } else if(length(commandArgs(FALSE)) >= 3) {
        message("Interpreting set number from file name.")
        ca <- grep('^-', commandArgs(FALSE), value=TRUE, invert=TRUE)
        cat('CommandArgs: ', commandArgs(FALSE), '\n', sep=' ')
        name = basename(tail(ca, 1))
        sn <- as.numeric(gsub('.*(\\d+).*', '\\1', name, perl=TRUE))
        if(length(sn)==1 && all(!is.na(sn))) return(sn) else
            stop("problem reading number.")
    } else if(interactive()) {
        warning("Detected running in interactive mode.  setnum assumed to be 1.")
        return(1)
    } else stop('cannot determine set number.')
}

format_ppn <- function(ppn){
    if(is.null(ppn)) return('')
    sprintf(",ppn=%d", ppn)
}

#' Spawn an HPC batch job
HPC_spawn <-
function( ...
        , sys = getOption("HPC::batch_system", infer_batch_system())
        ) {
#' @param sys the batch system to use.
#' @param ... passed on to system specific spawn methods.
    if(tolower(sys) == "slurm")              SLURM_spawn(...) else
    if(tolower(sys) %in% c('pbs', 'torque')) PBS_spawn(...) else
    if(tolower(sys) == "moab") stop("Moab batch system not implimented.") else
    stop("Unknown batch submission system.")
}


#' Run a simulation on a HPC cluster
#'
#' @param N             the nubmer of simulations to run
#' @param setnum        the number of the set to run
#' @param param.file    the file containing the \code{p.grid} and \code{analyses}
#'                      objects.  See Details
#' @param parallel      Should the dataset be run in parallel
#' @param load.global   Should the .RData file be loaded into global 
#'                      namespace for definitions?
#'
#' This function is part of the infrastructure for running jobs on
#' hig performance clusters.  It generates the data and performs the
#' specified analyses.
#'
#' It assumes that the \code{p.grid} and \code{analyses} are defined
#' if a file specified by params.file.  The \code{p.grid} object should
#' be a data.frame with the parameters for simulating the data.
#' The \code{analyses} object is a list of lists of functions.
#' The functions should be named analysis and summary.  The analysis
#' function is applied to each generated dataset.  The summary is applied
#' to the list of outputs form the analysis calls. and should produce a
#' single table as a result.  Multiple analyses can be defined and named.
#' The summary function should expect to take a single argument with the
#' list of analysis results.  The analysis function will be given named
#' arguments corresponding to the names in the list of generated data.
#' @importFrom dostats %.%
#' @export
HPC_simulate <- 
function( N             = HPC_get_N()
        , setnum        = HPC_get_setnum()
        , param.file    = "parameters.RData"
        , parallel      = !interactive()
        , load.global   = TRUE
        ){
{ ### SETUP: ###
    time <- timer()
    on.exit(time$cummsg("Simulation took", format="%1$s %2$s total.\n"), add=TRUE)
    suppressPackageStartupMessages( {
        requireNamespace("harvestr", quietly=TRUE)
    } )
    opar <- options(stringsAsFactors=FALSE)
    on.exit(options(opar), add=TRUE)
    if (load.global && file.exists(".RData")) 
        load(".RData", .GlobalEnv, verbose=FALSE)
    time$lapmsg("setup")
} # SETUP
{ # Load parameters
    parameters <- new.env(TRUE, emptyenv())
    load(param.file, parameters)
    stopifnot(  exists('lparams' , envir=parameters, inherits=FALSE))
    cat('running set number ', setnum, '\n')
    p.base <- parameters$lparams[[setnum]]
    time$lapmsg("Parameter setup")
} # Load Parameters
if(parallel) {
    HPC_parallel_setup()
    time$lapmsg("Parallel setup")
}
{ # Simulate datasets
    cat('creating ', N, ' datasets...')
    datasets <- 
        harvestr::harvest( harvestr::graft(p.base, N), dostats::compose(plyr::splat(SimulateCKD), as.list)
                         , .parallel=getOption('harvestr.parallel', FALSE)
                         , .progress=if(interactive())'text' else 'none'
                         )
    time$lapmsg()
} # Simulate datasets
{ # Perform Analysis
    attach(parameters$xtras)
    on.exit(detach(parameters$xtras), add=TRUE)
    summaries <-
    llply(add_names(parameters$analyses), function(L, X){
        t <- timer()
        cat(sprintf('analysis(%s)...', attr(L, 'name')))
        A <- harvestr::harvest(X, splat(L$analysis), .parallel=getOption('harvestr.parallel', FALSE))
        cat('summarizing...')
        on.exit(t$lapmsg(''), TRUE)
        L$summary(A)
    }, datasets)
    time$lapmsg("analyses")
} # Perform Analysis
{ # Save Results
    cat('Saving results...')
    save( list  = names(summaries)
    , envir = as.environment(summaries)
    , file  = sprintf('%d.RData', setnum))
    time$lapmsg()
} # Save Results
}

#' Spawn simulation portion of a job.
HPC_spawn_sim <-
function( wd = getwd()              
        , nparams = 1               
        , N  = quote(HPC_get_N())
        , param.file = "parameters.RData"
        , ...) {                    
#' @inheritParams HPC_create_sim
#' @param ... passed onto \code{\link{HPC_spawn}}    if(!file.exists(wd))dir.create(wd)
#' @param wd working directory of the simulation.
#' @param nparams number of parameter sets to run.
    args <- as_args( N = N
                   , setnum ="$ARRAYID_VAR"  # will be replaced according to the system used.
                   , param.file=shQuote(param.file, 'sh'))
    cmd <- sprintf('cd %s;Rscript -e "library(CKDsim);HPC_simulate(%s)"', shQuote(wd, 'sh'), (args))
    HPC_spawn(cmd, array=seq_len(nparams), ...)
}

#' Collect results of a simulation into a single data frame.
#'
#' @param param.file the location of the parameters
#' @param final.file the location to save collected results to.
#'
#' @export
HPC_collect <- function(param.file = "parameters.RData", final.file="all.RData"){
{ # Setup
    time <- timer()
    on.exit(time$cummsg("Collecing took", format="%1$s %2$s total.\n"), add=TRUE)
    opar <- options(stringsAsFactors=FALSE)
    on.exit(options(opar), add=TRUE)
    time$lapmsg('Setup')
} # Setup
{ # Load parameters
    parameters <- new.env(parent=emptyenv())
    load(param.file, parameters)
    stopifnot(exists('p.grid', envir=parameters, inherits=FALSE))
    parameters$p.grid <- data.frame(.id=seq_along(parameters$p.grid[[1]])
                                   , parameters$p.grid)
    time$lapmsg('Loading parameters')
} # Load parameters
{ # Collect from environments
    cat('collecting from environments...')
    envs <- mlply(parameters$p.grid, function(.id, ...){
        env <- new.env()
        filei <- sprintf('%d.RData', .id)
        if(file.exists(filei))
            load(filei, env)
        else warning(gettextf("could not find file '%s'.", filei))
        env
    })
    time$lapmsg()
} # Collect from environments
{ # Recombine
    cat('Recombine...')
    summary.all <- rename( replace=c(X1='analysis'), x= {
        adply(names(parameters$analyses), 1, function(name){
            item <- ldply(envs, `[[`, name)
            data.frame(item, ldply(item$SPEC, splat(data.frame)))
        })
    })
    time$lapmsg()
} # Recombine
{ # Join to parameters
    cat('joining to parameters...')
    summary.all <- join(parameters$p.grid, summary.all, by='.id')
    time$lapmsg()
} # Join to parameters
{ # Saving
    save(summary.all, file=final.file)
    time$lapmsg("Saving")
} # Saving
}

#' spawn the collection job
HPC_spawn_collect <-
function( wd=getwd()
        , sim_jid=NULL
        , param.file = "parameters.RData"
        , final.file="all.RData"
        , ...){
#' @inheritParams HPC_create_sim
#' @param sim_jid simulation job id to use for waiting.
    if(!file.exists(wd))dir.create(wd)
    args <- as_args( param.file=shQuote(param.file, 'sh')
                   , final.file=shQuote(final.file, 'sh'))
    HPC_spawn( sprintf('cd %s;Rscript -e "library(CKDsim);HPC_collect(%s)"', shQuote(wd, 'sh'), (args))
             , time="0:05:00"
             , depend.array=sim_jid, ...)
}


HPC_save_lparams <- 
function( p.grid
        , analyses
        , extra.objects   = list()
        , wd              = getwd()
        , param.file      = file.path(wd, "parameters.RData")
        , seed            = NULL
        , ...  #< ignored
        ){
    lparams <- harvestr::plant( mlply(p.grid, data.frame)
                              , seeds = harvestr::gather(nrow(p.grid), seed=if(!is.null(seed)) seed)
                              )
    save.env          <- new.env(parent=emptyenv())
    save.env$p.grid   <- p.grid
    save.env$lparams  <- lparams
    save.env$analyses <- analyses
    save.env$xtras    <- as.environment(extra.objects)
    save( list=ls(save.env)
        , file=param.file
        , envir=save.env
        , precheck=FALSE
        )
}



#' Create a simulation on a HPC cluster
#'
#' @param p.grid          the data.frame of parameters
#' @param analyses        the analyses to run
#' @param N               the number of datasets to generate
#' @param sim.time        the time required for simulating datasets and performing
#'                        analyses.
#' @param param.file      where to store the parameters for reuse accross simulations
#' @param final.file      where to store file with all results
#' @param wd              the working directory to use.
#' @param sim.jobname     the name of the job for simulating datasets and analyses.
#' @param collect.jobname the name of the job for collecting results together.
#' @param nworkers        the number of cores on machines that should be requested.
#'                        ussually 4, 8, or 16 (rare).  Can be provided to approximate
#'                        the time required.
#' @param seed            the seed that should be used for simulating datasets for
#'                        perfect replicability.
#' @param ...             passed on to \link[=HPC_spawn]{spawn} functions for
#'                        additional parameters.  The most usefull are the
#'                        \code{email} and \code{account} options.
#' @param extra.objects   extra objects needed to perform calculations.
#' @param save.global     whether to save objects from the global environment.
#'
#' This creates the jobs to run on a high performance computing cluster.
#' @export
HPC_create_sim <-
function( p.grid, analyses
        , N = 1000
        , sim.time        = formatTime(ceiling(N * (4 + length(analyses)*1.5)/nworkers))
        , ...
        , wd              = getwd()
        , param.file      = file.path(wd, "parameters.RData")
        , final.file      = file.path(wd, "all.RData")
        , nworkers        = detectCores()
        , sim.jobname     = format(Sys.time(), sprintf("%s_sim_%%Y-%%m-%%d", get_user()))
        , collect.jobname = format(Sys.time(), sprintf("%s_collect_%%Y-%%m-%%d", get_user()))
        , extra.objects   = list()
        , save.global     = TRUE
        , seed            = NULL
){
    stopifnot(requireNamespace('harvestr'))
    if(save.global) save.image()
    
#~     extra.objects <- 
#~         structure( list(...)
#~                  , names=as.character(substitute(list(...)))[-1L]
#~                  )
    HPC_save_lparams( p.grid=p.grid, analyses=analyses
                    , extra.objects=extra.objects
                    , wd=wd, param.file=param.file
                    , seed=seed
                    )
    simulate_jid <-
        HPC_spawn_sim( wd=wd, nparams=nrow(p.grid)
                     , N=N, param.file=param.file
                     , name = sim.jobname, time=sim.time
                     , ...
                     )
    if(is.null(simulate_jid)) stop("could not start simulation job.")
    cat(sim.jobname, " started as ", simulate_jid, '\n')
    collect_jid <-
        HPC_spawn_collect( wd=wd
                         , sim_jid= if(length(simulate_jid)) simulate_jid else ''
                         , param.file=param.file, final.file=final.file
                         , name = collect.jobname
                         , ...
                         )
    if(!is.null(collect_jid))
        cat(collect.jobname, " started as ", collect_jid, '\n')
}

#' Create a template analysis file
#'
#' @param to where should the analysis.R file be created
#' @param ... passed onto \code{\link{file.copy}}
#'
#' @export
HPC_template <- function(to='.', ...){
    file.copy(system.file("sims/spawn/analysis.R", package='CKDsim'), to, ...)
}


