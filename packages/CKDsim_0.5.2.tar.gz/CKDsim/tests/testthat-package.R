library(testthat)
library(CKDsim)

test_package("CKDsim")
