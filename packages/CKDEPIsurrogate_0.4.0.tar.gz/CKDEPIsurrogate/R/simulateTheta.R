# Generate posterior predictive draws for the true clinical treatment effect.

.simulateTheta <- function(fn.csv, gamma.s, SE.gamma, seed = NULL) {
  .checkNumber(gamma.s, "gamma.s")
  .checkNumber(SE.gamma, "SE.gamma", lower = 0)
  .setSeed(seed)

  myMCMC <- .readMCMCDraws(fn.csv)
  M <- nrow(myMCMC)

  # Account for sampling error in the estimated surrogate treatment effect.
  delta <- stats::rnorm(M, mean = 0, sd = SE.gamma)
  trueSurrogate <- gamma.s + delta

  # sigSqClinonSur is a variance, so its square root is the residual SD.
  nu <- stats::rnorm(M, mean = 0, sd = 1)
  omega <- sqrt(myMCMC$sigSqClinonSur) * nu

  # For each MCMC row, predict the true clinical effect in a new trial.
  theta <- myMCMC$alpha + myMCMC$beta * trueSurrogate + omega

  list(
    thetaDraws = theta,
    surrogateDraws = trueSurrogate,
    nDraws = M
  )
}

