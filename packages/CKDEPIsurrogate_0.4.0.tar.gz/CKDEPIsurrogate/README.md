# CKDEPIsurrogate

`CKDEPIsurrogate` predicts a true clinical-endpoint treatment effect using:

1. posterior draws from a trial-level surrogate meta-regression; and
2. an estimated surrogate-endpoint treatment effect and its standard error.

The package contains the three functions requested for the CKD-EPI work:

- `ProbBen()` reports the probability above **and** below a clinical-benefit
  threshold;
- `PredInt()` reports a two-sided posterior prediction interval; and
- `POS()` reports the probability of success in an independent future phase 3
  trial.

It also contains `GammaSensitivity()`, which evaluates those summaries over an
explicit range of surrogate treatment effects while holding `SE.gamma`
constant.

The code uses base R and does not depend on RStan or CmdStanR. The input is a
CSV of posterior draws, so the upstream model may be fitted with either Stan
interface without changing this package.

## Installation

Install the checked source archive from the directory containing it:

```r
install.packages(
  "CKDEPIsurrogate_0.4.0.tar.gz",
  repos = NULL,
  type = "source"
)
```

Package developers can install directly from the source directory at a command
prompt:

```text
R CMD INSTALL CKDEPIsurrogate
```

After installation, load the package with:

```r
library(CKDEPIsurrogate)
```

## Required MCMC file

The CSV must have one row per posterior draw and the following columns:

| Column | Meaning |
|---|---|
| `alpha` | Meta-regression intercept |
| `beta` | Meta-regression slope |
| `sigSqClinonSur` | Residual variance for the clinical effect conditional on the surrogate effect |

Additional CSV columns are allowed and ignored. For interactive work and unit
testing, the `fn.csv` argument may also be a data frame with these columns.

## Common posterior-prediction calculation

Let `gamma.s` be the estimated surrogate effect and `SE.gamma` its standard
error. For M posterior meta-regression draws, the package calculates:

```text
delta[i] ~ Normal(0, SE.gamma^2)
trueSurrogate[i] = gamma.s + delta[i]
omega[i] = sqrt(sigSqClinonSur[i]) * nu[i],  nu[i] ~ Normal(0, 1)
theta[i] = alpha[i] + beta[i] * trueSurrogate[i] + omega[i]
```

Thus, each `theta[i]` incorporates uncertainty in the surrogate estimate,
uncertainty in the fitted meta-regression, and residual uncertainty when
predicting the clinical effect for a new trial.

## Examples

The following creates a small example CSV. Real analyses should use the full
posterior file supplied by the meta-regression analysis.

```r
set.seed(101)
M <- 50000

exampleMCMC <- data.frame(
  alpha = rnorm(M, 0.10, 0.03),
  beta = rnorm(M, 1.20, 0.15),
  sigSqClinonSur = exp(rnorm(M, log(0.12), 0.10))
)

fn <- tempfile(fileext = ".csv")
write.csv(exampleMCMC, fn, row.names = FALSE)
```

### Probability of benefit

```r
benefit <- ProbBen(
  fn.csv = fn,
  gamma.s = 0.30,
  SE.gamma = 0.08,
  k = 0,
  seed = 123
)

benefit$probabilityGreaterThanK
benefit$probabilityLessThanOrEqualToK
```

### Prediction interval

```r
interval <- PredInt(
  fn.csv = fn,
  gamma.s = 0.30,
  SE.gamma = 0.08,
  level = 0.95,
  seed = 123
)

interval$predictionInterval
```

### Probability of success

```r
success <- POS(
  fn.csv = fn,
  gamma.s = 0.30,
  SE.gamma = 0.08,
  SE.theta = 0.20,
  alpha = 0.05,
  seed = 123
)

success$probabilityOfSuccess
```

### Sensitivity analysis across surrogate effects

The existing functions deliberately continue to require one observed
`gamma.s`. Omitting that argument would make both the intended scale and the
return type ambiguous. Use `GammaSensitivity()` when the scientific question
concerns a range:

```r
gammaRange <- GammaSensitivity(
  fn.csv = fn,
  gamma.s = seq(-0.20, 0.80, by = 0.02),
  SE.gamma = 0.08,
  k = 0,
  level = 0.95,
  SE.theta = 0.20,
  alpha = 0.05,
  seed = 123
)

gammaRange$results
plot(gammaRange)
```

`SE.theta` is optional. If it is omitted, the results and plot contain only
probability of benefit and the prediction interval. If it is supplied, POS is
also calculated. The same simulation components are used at each `gamma.s` to
reduce unrelated Monte Carlo noise between adjacent points.

## Visualizing the calculations

Each analysis result has a base R `plot()` method:

```r
plot(benefit)
plot(interval)
plot(success)
```

The probability-of-benefit plot shows the posterior predictive density of the
true clinical effect. The areas below and above `k` are shaded separately and
the two probabilities are printed in the legend.

The prediction-interval plot shades the requested central interval and the two
outside tails.

The POS plot shows the posterior predictive density of the **future observed
phase 3 treatment-effect estimate**, not merely the density of the unknown true
effect. The region above the beneficial-side rejection boundary is shaded as
success. The displayed POS remains the analytic calculation returned by
`POS()`; the figure adds no plot-only random simulation.

Plot titles and axis labels can be changed in the usual base R style:

```r
plot(
  benefit,
  main = "Probability that the GFR-slope effect exceeds 0",
  xlab = "True treatment effect on GFR slope"
)
```

A short worked example is installed and registered as an R vignette:

```r
vignette(
  "CKDEPIsurrogate-introduction",
  package = "CKDEPIsurrogate"
)
```

The quoted string is the vignette topic. A full path returned by
`system.file()` should not be passed to `vignette()`.

## Decisions in this draft

These decisions are explicit so that the implementation can be reviewed and
changed without guessing what the code assumes.

### 1. Both sides of probability of benefit are reported

The scientific definition is `Pr(theta > k)`. To make the result easier to
interpret, `ProbBen()` returns both:

- `probabilityGreaterThanK`; and
- `probabilityLessThanOrEqualToK`.

They are exact complements. Under the continuous predictive model,
`Pr(theta = k) = 0`, so the latter is also the lower side of the distribution.

### 2. `sigSqClinonSur` is treated as a variance

The residual prediction error is generated with standard deviation
`sqrt(sigSqClinonSur)`. The square root is required because the input column is
defined as a variance.

### 3. Surrogate sampling error is inside the regression

The simulated true surrogate effect is `gamma.s + delta`. It is then multiplied
by the corresponding posterior draw of `beta`. This preserves the scale of the
meta-regression:

```text
theta = alpha + beta * (gamma.s + delta) + omega
```

### 4. Larger clinical effects represent benefit

The initial package is written for GFR slope, where larger treatment effects are
beneficial. `POS()` therefore counts only rejection in the positive direction,
even though the planned test is two-sided.

### 5. Scope of the initial POS calculation

`POS()` applies when:

1. the surrogate effect is estimated in a preliminary phase 2 trial; and
2. an independent, new phase 3 trial will estimate the definitive endpoint.

`ProbBen()` and `PredInt()` can also be used when the surrogate estimate comes
from an interim analysis of the phase 3 trial. The initial `POS()` calculation
must **not** be interpreted as interim-phase-3 conditional power or predictive
power. That extension requires additional information about overlap and the
joint distribution of interim and final estimates and is intentionally deferred.

### 6. Two-sided alpha and beneficial-side success

For each predictive draw, `POS()` calculates:

```text
Pr(success | theta[i]) =
  Phi(theta[i] / SE.theta - z[1 - alpha / 2])
```

The package averages these conditional probabilities over all M predictive
draws.

### 7. Prediction interval convention

`PredInt()` uses equal-tailed empirical quantiles and base R's default quantile
algorithm (`type = 7`). For a 95% interval it returns the 2.5th and 97.5th
percentiles.

### 8. Reproducibility

All analysis functions have an optional `seed` argument. If supplied, the same
inputs and seed reproduce the same predictive draws. The default is `NULL`, so
normal R random-number behavior is used when no seed is requested.

## Function outputs

Each primary single-value function returns a named list containing the M
posterior predictive draws
in `thetaDraws`, the requested summary, the supplied analysis inputs, and the
number of draws. Returning the draws makes it possible to verify calculations,
create plots, or compute additional summaries without rerunning the simulation.

`GammaSensitivity()` instead returns a compact `results` data frame with one
row per supplied gamma value. It does not retain a potentially very large
draw-by-gamma matrix.

## Current limitations and planned extensions

- Add the more complex POS calculation for a surrogate measured at an interim
  analysis of the same phase 3 trial only after the required joint model is
  specified.
- Extend the package to time-to-event endpoints expressed as hazard ratios.
- Replace the placeholder maintainer email in `DESCRIPTION` before distributing
  the package outside the project team.

## Quality-control approach

The package includes base-R tests for deterministic special cases, input
validation, complementary benefit probabilities, reproducible simulation,
prediction-interval behavior, analytically known POS values, gamma-range
summaries, plotting, and installed-vignette registration. The package
should be run through both:

```text
R CMD build --no-build-vignettes CKDEPIsurrogate
R CMD check --no-build-vignettes CKDEPIsurrogate_<version>.tar.gz
```

before each tagged release.

Version 0.4.0 passed `R CMD check --no-build-vignettes --no-manual` under R
4.5.1 on Windows on August 21, 2026, with no errors, warnings, or notes. The
prebuilt HTML is deliberately retained because it is self-contained and does
not require `knitr`, `rmarkdown`, or LaTeX at installation time.
