################################################################################
# Copyright 2012 University of Utah Study Design and Biostatistics Center
# This file constitutes portions of ongoing research and collaboration.
# Distributed under the GPL >= 2.0 License.
#
# PROJECT INFO
# Principal Investigator: Tome Greene
# Project Name:  FDA CKDsim simulation
# SDBC Consultant: Jian Ying, Andrew Redd, Jenny Teng, Tom Greene
# File Author: Jian Ying
# Date: 06/26/2026
#
# Description of File:
# Tests slope models.
# 
# last updated: 06/26/2026


library(testthat)
library(CKDsim)

context("SimulateCKD slope model")

simulate_for_slope <- function(...) {
  args <- modifyList(list(
    data.title = "slope model test",
    n = 600,
    accrual = 0,
    followup = 2,
    freq = 1,
    add.base.measure = 0,
    early.measure = NULL,
    corr.slope.int = 0,
    slope.model = "nm",
    mean.int = 40,
    sd.int = 0.01,
    int.low = 10,
    int.up = 80,
    p.fast.progressors = 0,
    mean.slope.fast = -8,
    sd.slope.fast = 0.01,
    mean.slope.general = -2,
    sd.slope.general = 0.01,
    int.uniform.lower = 25,
    int.uniform.upper = 55,
    mean.log.gamma = -2,
    sd.log.gamma = 0.5,
    log.gamma.shape = 3,
    intglg.b0 = -2,
    intglg.b1 = -0.10,
    add.long.term.effect = 0,
    pro.long.term.effect = 1,
    acute.model = "ratio",
    acute.A0 = 0,
    acute.SigA = 0,
    acute.ratio = 0,
    var.residual.a0 = 0,
    var.residual.a1 = 0,
    var.residual.POM = 1,
    t.df.residual = Inf,
    wt.residual = 0,
    auto.residual = 0,
    esrd.model = "threshold",
    esrd.threshold.low = 1,
    esrd.threshold.up = 2,
    lambda.fu = 1e-12,
    lambda.b0 = 0,
    lambda.b1 = 0,
    lambda.b2 = 0,
    lambda.b3 = 0,
    p.missing = 0,
    repeat.measure = FALSE,
    rate.drop.trt = 0
  ), list(...))
  do.call(SimulateCKD, args)
}

test_that("normal mixture slope model uses the selected component parameters", {
  set.seed(101)
  general <- simulate_for_slope(
    slope.model = "nm",
    p.fast.progressors = 0,
    mean.slope.general = -2,
    sd.slope.general = 0.01
  )
  expect_equal(mean(general$BaseFile$BaseSlope), -2, tolerance = 0.01)
  expect_equal(sd(general$BaseFile$BaseSlope), 0.01, tolerance = 0.003)

  set.seed(102)
  fast <- simulate_for_slope(
    slope.model = "nm",
    p.fast.progressors = 1,
    mean.slope.fast = -8,
    sd.slope.fast = 0.01
  )
  expect_equal(mean(fast$BaseFile$BaseSlope), -8, tolerance = 0.01)
  expect_equal(sd(fast$BaseFile$BaseSlope), 0.01, tolerance = 0.003)
})

test_that("generalized log gamma slope model has requested marginal mean and SD", {
  set.seed(201)
  sim <- simulate_for_slope(
    n = 2000,
    slope.model = "glg",
    mean.log.gamma = -2.5,
    sd.log.gamma = 0.6,
    log.gamma.shape = 3
  )

  expect_equal(mean(sim$BaseFile$BaseSlope), -2.5, tolerance = 0.04)
  expect_equal(sd(sim$BaseFile$BaseSlope), 0.6, tolerance = 0.04)
})

test_that("normalglg slope mean depends linearly on the normal intercept", {
  set.seed(301)
  sim <- simulate_for_slope(
    n = 2000,
    slope.model = "normalglg",
    mean.int = 40,
    sd.int = 6,
    int.low = 10,
    int.up = 80,
    intglg.b0 = -2,
    intglg.b1 = -0.15,
    sd.log.gamma = 0.05,
    log.gamma.shape = 3
  )

  fit <- lm(BaseSlope ~ I(BaseIntercept - 40), data = sim$BaseFile)
  expect_equal(unname(coef(fit)[1]), -2, tolerance = 0.02)
  expect_equal(unname(coef(fit)[2]), -0.15, tolerance = 0.01)
})

test_that("uniformglg uses uniform intercept bounds and centered linear slope mean", {
  set.seed(401)
  sim <- simulate_for_slope(
    n = 2000,
    slope.model = "uniformglg",
    int.uniform.lower = 25,
    int.uniform.upper = 55,
    intglg.b0 = -3,
    intglg.b1 = -0.12,
    sd.log.gamma = 0.05,
    log.gamma.shape = 3
  )

  expect_true(all(sim$BaseFile$BaseIntercept >= 25))
  expect_true(all(sim$BaseFile$BaseIntercept <= 55))

  fit <- lm(BaseSlope ~ I(BaseIntercept - 40), data = sim$BaseFile)
  expect_equal(unname(coef(fit)[1]), -3, tolerance = 0.02)
  expect_equal(unname(coef(fit)[2]), -0.12, tolerance = 0.01)
})

test_that("SimulateCKD applies the long-term treatment slope formula in BaseFile", {
  set.seed(501)
  sim <- simulate_for_slope(
    slope.model = "nm",
    p.fast.progressors = 0,
    mean.slope.general = -2,
    sd.slope.general = 0.01,
    add.long.term.effect = 0.5,
    pro.long.term.effect = 0.7
  )

  expected <- ifelse(
    sim$BaseFile$BaseSlope >= 0,
    sim$BaseFile$BaseSlope + 0.5,
    sim$BaseFile$BaseSlope * 0.7 + 0.5
  )
  expect_equal(sim$BaseFile$LongTermTxSlope, expected, tolerance = 1e-12)
})

test_that("SimulateCKD uses the first slope model when slope.model is omitted", {
  set.seed(801)
  sim <- SimulateCKD(
    data.title = "default slope model test",
    n = 4,
    accrual = 0,
    followup = 1,
    freq = 1,
    add.base.measure = 0,
    early.measure = NULL,
    corr.slope.int = 0,
    mean.int = 40,
    sd.int = 0.001,
    int.low = 30,
    int.up = 50,
    p.fast.progressors = 0,
    mean.slope.fast = -8,
    sd.slope.fast = 0.001,
    mean.slope.general = -2,
    sd.slope.general = 0.001,
    mean.log.gamma = -2,
    sd.log.gamma = 0.5,
    log.gamma.shape = 3,
    add.long.term.effect = 0,
    pro.long.term.effect = 1,
    acute.model = "ratio",
    acute.A0 = 0,
    acute.SigA = 0,
    acute.ratio = 0,
    var.residual.a0 = 0,
    var.residual.a1 = 0,
    var.residual.POM = 1,
    t.df.residual = Inf,
    wt.residual = 0,
    auto.residual = 0,
    esrd.model = "threshold",
    esrd.threshold.low = 1,
    esrd.threshold.up = 2,
    lambda.fu = 1e-12,
    lambda.b0 = 0,
    lambda.b1 = 0,
    lambda.b2 = 0,
    lambda.b3 = 0,
    p.missing = 0,
    repeat.measure = FALSE,
    rate.drop.trt = 0
  )

  expect_s3_class(sim$BaseFile, "data.frame")
  expect_equal(mean(sim$BaseFile$BaseSlope), -2, tolerance = 0.01)
})

test_that("SimulateCKD validates uniformglg intercept bounds", {
  expect_error(
    simulate_for_slope(
      slope.model = "uniformglg",
      int.uniform.lower = 55,
      int.uniform.upper = 25
    )
  )
})
